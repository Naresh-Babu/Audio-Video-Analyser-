<?php
require_once "/home/trendsep/public_html/sih2018/algorithms/source_json_seperator.php";
require_once "/home/trendsep/public_html/sih2018/algorithms/trancript.php";
function search_match($json,$search_data,$file_name) {
	$res=array();
  $topic=topic_getter($json);

	$json=json_decode($json,True);
	$json=$json["summarizedInsights"];
	foreach($search_data as $cur_word) {
		$res[$cur_word]=array();
		foreach($json["faces"] as $face) {
			if($cur_word==$face["title"]) {
				foreach($face["appearances"] as $cur) {
					$res[$cur_word][]=array($cur["startTime"],$cur["endTime"]);
				}
				break;
			}
		}
    foreach($topic as $cur_top) {
      if($cur_top==$cur_word)
        $res[$cur_word][]="topic";
    }
		foreach($json["annotations"] as $objects) {
			if($objects["name"]==$cur_word) {
				foreach($objects["appearances"] as $cur) {
					$res[$cur_word][]=array($cur["startTime"],$cur["endTime"]);
				}
				break;
			}
		}
		$lines=trans($file_name);
		foreach($lines as $line) {
			if(in_array($cur_word,explode(" ", trim($line[2])))) {
				$res[$cur_word][]=array($line[0],$line[1]);

			}
		}

	}
	
	return $res;

}



    $json=<<<eoa
{
"accountId": "a76ef345-7cef-4367-9599-5c0eca019523",
"id": "86a059e4d2",
"partition": null,
"name": "jayalalitha",
"description": null,
"userName": "muhamed salih",
"createTime": "2018-03-17T07:49:29.4005734+00:00",
"organization": "",
"privacyMode": "Public",
"state": "Processed",
"isOwned": true,
"isEditable": false,
"isBase": true,
"durationInSeconds": 397,
"summarizedInsights": {
"name": "jayalalitha",
"shortId": "86a059e4d2",
"privacyMode": 2,
"duration": {
"time": "00:06:37",
"seconds": 397.0
},
"thumbnailUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/16e9c0b8-aa3c-40b7-a157-9d3c2bbe473d",
"faces": [{
"id": 19617,
"shortId": "86a059e4d2",
"bingId": "fc09d25c-0c7c-13c0-e4cd-1f5f7d125b36",
"confidence": 0.99999797344207764,
"name": "Jayalalithaa",
"description": "Jayaram Jayalalithaa was an Indian actress and politician who served six terms as the Chief Minister of Tamil Nadu for over fourteen years between 1991 and 2016.",
"title": "Indian Politician",
"thumbnailId": "7281c9e6-7c94-438a-8c78-58c7261e4662",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/7281c9e6-7c94-438a-8c78-58c7261e4662",
"appearances": [{
"startTime": "00:00:00.0670000",
"endTime": "00:00:05.0660000",
"startSeconds": 0.1,
"endSeconds": 5.1
}, {
"startTime": "00:00:22.7660000",
"endTime": "00:02:52.0660000",
"startSeconds": 22.8,
"endSeconds": 172.1
}, {
"startTime": "00:03:05.7990000",
"endTime": "00:03:15.9330000",
"startSeconds": 185.8,
"endSeconds": 195.9
}, {
"startTime": "00:03:36.0330000",
"endTime": "00:03:40.8660000",
"startSeconds": 216.0,
"endSeconds": 220.9
}, {
"startTime": "00:03:55.8660000",
"endTime": "00:05:38.7870000",
"startSeconds": 235.9,
"endSeconds": 338.8
}],
"seenDuration": 272.2,
"seenDurationRatio": 0.68564231738035264
}, {
"id": 9114,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #44",
"description": null,
"title": null,
"thumbnailId": "6a83dd78-f856-4772-9281-30e62f08db7a",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/6a83dd78-f856-4772-9281-30e62f08db7a",
"appearances": [{
"startTime": "00:00:20.0990000",
"endTime": "00:00:24.8660000",
"startSeconds": 20.1,
"endSeconds": 24.9
}, {
"startTime": "00:02:18.4660000",
"endTime": "00:02:50.1330000",
"startSeconds": 138.5,
"endSeconds": 170.1
}, {
"startTime": "00:03:17.3990000",
"endTime": "00:03:30.0330000",
"startSeconds": 197.4,
"endSeconds": 210.0
}, {
"startTime": "00:03:46.5330000",
"endTime": "00:03:53.0660000",
"startSeconds": 226.5,
"endSeconds": 233.1
}, {
"startTime": "00:04:06.0660000",
"endTime": "00:04:13.7660000",
"startSeconds": 246.1,
"endSeconds": 253.8
}, {
"startTime": "00:04:31.1660000",
"endTime": "00:04:34.5660000",
"startSeconds": 271.2,
"endSeconds": 274.6
}, {
"startTime": "00:04:46.4330000",
"endTime": "00:04:53.2330000",
"startSeconds": 286.4,
"endSeconds": 293.2
}],
"seenDuration": 73.500000000000043,
"seenDurationRatio": 0.18513853904282127
}, {
"id": 5733,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #41",
"description": null,
"title": null,
"thumbnailId": "011b137b-c5df-48ef-b99c-46ea9c78ee3b",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/011b137b-c5df-48ef-b99c-46ea9c78ee3b",
"appearances": [{
"startTime": "00:02:01.2330000",
"endTime": "00:02:12.2660000",
"startSeconds": 121.2,
"endSeconds": 132.3
}, {
"startTime": "00:02:27.5660000",
"endTime": "00:02:38.3990000",
"startSeconds": 147.6,
"endSeconds": 158.4
}],
"seenDuration": 21.90000000000002,
"seenDurationRatio": 0.055163727959697782
}, {
"id": 16450,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #4",
"description": null,
"title": null,
"thumbnailId": "84708501-fcbe-49c3-ab04-7025427e4b48",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/84708501-fcbe-49c3-ab04-7025427e4b48",
"appearances": [{
"startTime": "00:04:28.1990000",
"endTime": "00:04:49.7990000",
"startSeconds": 268.2,
"endSeconds": 289.8
}],
"seenDuration": 21.600000000000023,
"seenDurationRatio": 0.054408060453400561
}, {
"id": 10128,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #28",
"description": null,
"title": null,
"thumbnailId": "35b3c32c-18ba-4791-9249-4e7f6235b89f",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/35b3c32c-18ba-4791-9249-4e7f6235b89f",
"appearances": [{
"startTime": "00:02:34.9330000",
"endTime": "00:02:44.8990000",
"startSeconds": 154.9,
"endSeconds": 164.9
}, {
"startTime": "00:02:57.4660000",
"endTime": "00:03:08.3990000",
"startSeconds": 177.5,
"endSeconds": 188.4
}],
"seenDuration": 20.900000000000006,
"seenDurationRatio": 0.052644836272040314
}, {
"id": 4442,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #43",
"description": null,
"title": null,
"thumbnailId": "159937fc-bd86-4a64-a589-eeb161105c98",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/159937fc-bd86-4a64-a589-eeb161105c98",
"appearances": [{
"startTime": "00:01:31.6660000",
"endTime": "00:01:36.8660000",
"startSeconds": 91.7,
"endSeconds": 96.9
}, {
"startTime": "00:01:50.1990000",
"endTime": "00:02:02.8990000",
"startSeconds": 110.2,
"endSeconds": 122.9
}],
"seenDuration": 17.900000000000006,
"seenDurationRatio": 0.045088161209068021
}, {
"id": 4663,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #2",
"description": null,
"title": null,
"thumbnailId": "1c0d4b79-688f-4b80-b99e-43d2e991e92e",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/1c0d4b79-688f-4b80-b99e-43d2e991e92e",
"appearances": [{
"startTime": "00:00:32.5660000",
"endTime": "00:00:38.0990000",
"startSeconds": 32.6,
"endSeconds": 38.1
}, {
"startTime": "00:01:42.6990000",
"endTime": "00:01:49.6990000",
"startSeconds": 102.7,
"endSeconds": 109.7
}],
"seenDuration": 12.5,
"seenDurationRatio": 0.031486146095717885
}, {
"id": 1286,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #29",
"description": null,
"title": null,
"thumbnailId": "107105f4-95a3-4196-bf4b-6711bfd29df2",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/107105f4-95a3-4196-bf4b-6711bfd29df2",
"appearances": [{
"startTime": "00:00:09.4990000",
"endTime": "00:00:14.8990000",
"startSeconds": 9.5,
"endSeconds": 14.9
}, {
"startTime": "00:00:26.3990000",
"endTime": "00:00:32.5660000",
"startSeconds": 26.4,
"endSeconds": 32.6
}],
"seenDuration": 11.600000000000003,
"seenDurationRatio": 0.029219143576826204
}, {
"id": 9049,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #45",
"description": null,
"title": null,
"thumbnailId": "8b840acc-133a-472a-a346-6769e18ecf4a",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/8b840acc-133a-472a-a346-6769e18ecf4a",
"appearances": [{
"startTime": "00:02:34.8660000",
"endTime": "00:02:46.2660000",
"startSeconds": 154.9,
"endSeconds": 166.3
}],
"seenDuration": 11.400000000000006,
"seenDurationRatio": 0.028715365239294726
}, {
"id": 8299,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #34",
"description": null,
"title": null,
"thumbnailId": "3b70c604-2ffc-4bf9-8096-fdbb1bcf4a5a",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/3b70c604-2ffc-4bf9-8096-fdbb1bcf4a5a",
"appearances": [{
"startTime": "00:02:34.9990000",
"endTime": "00:02:46.2330000",
"startSeconds": 155.0,
"endSeconds": 166.2
}],
"seenDuration": 11.199999999999989,
"seenDurationRatio": 0.028211586901763196
}, {
"id": 7229,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #17",
"description": null,
"title": null,
"thumbnailId": "bf41907d-c72b-4fcd-a6fb-d8f112c6459b",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/bf41907d-c72b-4fcd-a6fb-d8f112c6459b",
"appearances": [{
"startTime": "00:02:27.4660000",
"endTime": "00:02:38.4330000",
"startSeconds": 147.5,
"endSeconds": 158.4
}],
"seenDuration": 10.900000000000006,
"seenDurationRatio": 0.027455919395466009
}, {
"id": 13391,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #24",
"description": null,
"title": null,
"thumbnailId": "3c07fb28-8dd2-4444-94af-9ec5218aec5b",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/3c07fb28-8dd2-4444-94af-9ec5218aec5b",
"appearances": [{
"startTime": "00:03:50.0330000",
"endTime": "00:04:00.8330000",
"startSeconds": 230.0,
"endSeconds": 240.8
}],
"seenDuration": 10.800000000000011,
"seenDurationRatio": 0.027204030226700281
}, {
"id": 10253,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #27",
"description": null,
"title": null,
"thumbnailId": "eef635d8-601f-4184-9b49-8c0f8c83b170",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/eef635d8-601f-4184-9b49-8c0f8c83b170",
"appearances": [{
"startTime": "00:02:57.8330000",
"endTime": "00:03:08.3660000",
"startSeconds": 177.8,
"endSeconds": 188.4
}],
"seenDuration": 10.599999999999994,
"seenDurationRatio": 0.02670025188916875
}, {
"id": 1398,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #35",
"description": null,
"title": null,
"thumbnailId": "7aae3ce5-67e9-40a4-b92c-e35061dcbafe",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/7aae3ce5-67e9-40a4-b92c-e35061dcbafe",
"appearances": [{
"startTime": "00:00:11.8990000",
"endTime": "00:00:22.3660000",
"startSeconds": 11.9,
"endSeconds": 22.4
}],
"seenDuration": 10.499999999999998,
"seenDurationRatio": 0.026448362720403018
}, {
"id": 7224,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #26",
"description": null,
"title": null,
"thumbnailId": "f5d5d843-e7cb-48a9-ae07-5c4dd2797601",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/f5d5d843-e7cb-48a9-ae07-5c4dd2797601",
"appearances": [{
"startTime": "00:02:27.7330000",
"endTime": "00:02:38.0330000",
"startSeconds": 147.7,
"endSeconds": 158.0
}],
"seenDuration": 10.300000000000011,
"seenDurationRatio": 0.025944584382871564
}, {
"id": 8213,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #38",
"description": null,
"title": null,
"thumbnailId": "f2e1e9c1-802d-4ad0-8ecd-680071a3fc25",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/f2e1e9c1-802d-4ad0-8ecd-680071a3fc25",
"appearances": [{
"startTime": "00:02:34.7330000",
"endTime": "00:02:44.8990000",
"startSeconds": 154.7,
"endSeconds": 164.9
}],
"seenDuration": 10.200000000000017,
"seenDurationRatio": 0.025692695214105835
}, {
"id": 13832,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #47",
"description": null,
"title": null,
"thumbnailId": "caae8ed2-2039-4459-aab3-f6d3ec2419c8",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/caae8ed2-2039-4459-aab3-f6d3ec2419c8",
"appearances": [{
"startTime": "00:03:57.4990000",
"endTime": "00:04:07.7330000",
"startSeconds": 237.5,
"endSeconds": 247.7
}],
"seenDuration": 10.199999999999989,
"seenDurationRatio": 0.025692695214105766
}, {
"id": 9881,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #39",
"description": null,
"title": null,
"thumbnailId": "32c3cb06-1457-4530-8d60-834927ac340c",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/32c3cb06-1457-4530-8d60-834927ac340c",
"appearances": [{
"startTime": "00:02:51.3660000",
"endTime": "00:03:01.3330000",
"startSeconds": 171.4,
"endSeconds": 181.3
}],
"seenDuration": 9.9000000000000057,
"seenDurationRatio": 0.02493702770780858
}, {
"id": 16482,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #5",
"description": null,
"title": null,
"thumbnailId": "a4a2ee7c-40dd-4dff-8c7f-cb830250cb92",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/a4a2ee7c-40dd-4dff-8c7f-cb830250cb92",
"appearances": [{
"startTime": "00:04:38.5330000",
"endTime": "00:04:48.1330000",
"startSeconds": 278.5,
"endSeconds": 288.1
}],
"seenDuration": 9.6000000000000227,
"seenDurationRatio": 0.024181360201511393
}, {
"id": 10108,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #37",
"description": null,
"title": null,
"thumbnailId": "22250d7d-0ac5-43e4-9f14-ea593ec964d7",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/22250d7d-0ac5-43e4-9f14-ea593ec964d7",
"appearances": [{
"startTime": "00:02:58.9990000",
"endTime": "00:03:08.3990000",
"startSeconds": 179.0,
"endSeconds": 188.4
}],
"seenDuration": 9.4000000000000057,
"seenDurationRatio": 0.023677581863979863
}, {
"id": 13872,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #25",
"description": null,
"title": null,
"thumbnailId": "3baf7405-f976-480f-b75d-ee3e659dbb8e",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/3baf7405-f976-480f-b75d-ee3e659dbb8e",
"appearances": [{
"startTime": "00:03:57.6660000",
"endTime": "00:04:04.7660000",
"startSeconds": 237.7,
"endSeconds": 244.8
}],
"seenDuration": 7.1000000000000227,
"seenDurationRatio": 0.017884130982367817
}, {
"id": 15807,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #14",
"description": null,
"title": null,
"thumbnailId": "3cb58225-aac3-4168-8f42-8f7fc2aa7854",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/3cb58225-aac3-4168-8f42-8f7fc2aa7854",
"appearances": [{
"startTime": "00:04:31.3990000",
"endTime": "00:04:38.4990000",
"startSeconds": 271.4,
"endSeconds": 278.5
}],
"seenDuration": 7.1000000000000227,
"seenDurationRatio": 0.017884130982367817
}, {
"id": 2635,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #42",
"description": null,
"title": null,
"thumbnailId": "2776eb6b-52d6-4d6e-99a4-03925fcb78cb",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/2776eb6b-52d6-4d6e-99a4-03925fcb78cb",
"appearances": [{
"startTime": "00:00:39.0990000",
"endTime": "00:00:46.1660000",
"startSeconds": 39.1,
"endSeconds": 46.2
}],
"seenDuration": 7.1000000000000014,
"seenDurationRatio": 0.017884130982367762
}, {
"id": 6647,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #40",
"description": null,
"title": null,
"thumbnailId": "b3732958-e287-4d8d-8147-3478f33aa5f4",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/b3732958-e287-4d8d-8147-3478f33aa5f4",
"appearances": [{
"startTime": "00:02:20.0660000",
"endTime": "00:02:27.0990000",
"startSeconds": 140.1,
"endSeconds": 147.1
}],
"seenDuration": 7.0,
"seenDurationRatio": 0.017632241813602016
}, {
"id": 6663,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #53",
"description": null,
"title": null,
"thumbnailId": "d40806e9-92c5-4764-a2f9-27c6762f6f33",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/d40806e9-92c5-4764-a2f9-27c6762f6f33",
"appearances": [{
"startTime": "00:02:20.1660000",
"endTime": "00:02:27.1990000",
"startSeconds": 140.2,
"endSeconds": 147.2
}],
"seenDuration": 7.0,
"seenDurationRatio": 0.017632241813602016
}, {
"id": 6693,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #36",
"description": null,
"title": null,
"thumbnailId": "3f696b87-775a-4c43-93f5-b2f922eb64f0",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/3f696b87-775a-4c43-93f5-b2f922eb64f0",
"appearances": [{
"startTime": "00:02:20.3660000",
"endTime": "00:02:27.3990000",
"startSeconds": 140.4,
"endSeconds": 147.4
}],
"seenDuration": 7.0,
"seenDurationRatio": 0.017632241813602016
}, {
"id": 13110,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #8",
"description": null,
"title": null,
"thumbnailId": "9c66b205-2691-41ac-b987-fe64d0fceea9",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/9c66b205-2691-41ac-b987-fe64d0fceea9",
"appearances": [{
"startTime": "00:03:46.3990000",
"endTime": "00:03:53.4330000",
"startSeconds": 226.4,
"endSeconds": 233.4
}],
"seenDuration": 7.0,
"seenDurationRatio": 0.017632241813602016
}, {
"id": 14691,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #46",
"description": null,
"title": null,
"thumbnailId": "dd8db656-3c92-4536-9e7d-d974c7d89851",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/dd8db656-3c92-4536-9e7d-d974c7d89851",
"appearances": [{
"startTime": "00:04:08.8660000",
"endTime": "00:04:15.8660000",
"startSeconds": 248.9,
"endSeconds": 255.9
}],
"seenDuration": 7.0,
"seenDurationRatio": 0.017632241813602016
}, {
"id": 18677,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #3",
"description": null,
"title": null,
"thumbnailId": "ce10ab05-260d-475c-8f44-ae5e299f5e68",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/ce10ab05-260d-475c-8f44-ae5e299f5e68",
"appearances": [{
"startTime": "00:05:01.5540000",
"endTime": "00:05:08.6200000",
"startSeconds": 301.6,
"endSeconds": 308.6
}],
"seenDuration": 7.0,
"seenDurationRatio": 0.017632241813602016
}, {
"id": 15122,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #10",
"description": null,
"title": null,
"thumbnailId": "853b59a5-ff26-4e29-8074-979f42a9bc29",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/853b59a5-ff26-4e29-8074-979f42a9bc29",
"appearances": [{
"startTime": "00:04:16.3990000",
"endTime": "00:04:23.3500000",
"startSeconds": 256.4,
"endSeconds": 263.3
}],
"seenDuration": 6.9000000000000341,
"seenDurationRatio": 0.01738035264483636
}, {
"id": 15308,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #33",
"description": null,
"title": null,
"thumbnailId": "6f2854c1-dbc2-47b4-bd16-5ac9c7f6a681",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/6f2854c1-dbc2-47b4-bd16-5ac9c7f6a681",
"appearances": [{
"startTime": "00:04:20.5660000",
"endTime": "00:04:27.4990000",
"startSeconds": 260.6,
"endSeconds": 267.5
}],
"seenDuration": 6.8999999999999773,
"seenDurationRatio": 0.017380352644836214
}, {
"id": 16827,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #12",
"description": null,
"title": null,
"thumbnailId": "ce1c96fd-595f-4346-85a3-bea10af31435",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/ce1c96fd-595f-4346-85a3-bea10af31435",
"appearances": [{
"startTime": "00:04:46.6990000",
"endTime": "00:04:53.3990000",
"startSeconds": 286.7,
"endSeconds": 293.4
}],
"seenDuration": 6.6999999999999886,
"seenDurationRatio": 0.016876574307304756
}, {
"id": 5312,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #13",
"description": null,
"title": null,
"thumbnailId": "579f032c-faf1-4a09-93c4-c37fd8928af8",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/579f032c-faf1-4a09-93c4-c37fd8928af8",
"appearances": [{
"startTime": "00:01:54.0990000",
"endTime": "00:02:00.6990000",
"startSeconds": 114.1,
"endSeconds": 120.7
}],
"seenDuration": 6.6000000000000085,
"seenDurationRatio": 0.016624685138539066
}, {
"id": 6758,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #15",
"description": null,
"title": null,
"thumbnailId": "fd29ce4f-0733-40a1-a81c-664b3939e50a",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/fd29ce4f-0733-40a1-a81c-664b3939e50a",
"appearances": [{
"startTime": "00:02:20.9330000",
"endTime": "00:02:27.3990000",
"startSeconds": 140.9,
"endSeconds": 147.4
}],
"seenDuration": 6.5,
"seenDurationRatio": 0.0163727959697733
}, {
"id": 14920,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #51",
"description": null,
"title": null,
"thumbnailId": "b9efc854-ef3b-45c0-b3d3-40a1478016ea",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/b9efc854-ef3b-45c0-b3d3-40a1478016ea",
"appearances": [{
"startTime": "00:04:12.9990000",
"endTime": "00:04:19.4660000",
"startSeconds": 253.0,
"endSeconds": 259.5
}],
"seenDuration": 6.5,
"seenDurationRatio": 0.0163727959697733
}, {
"id": 15514,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #21",
"description": null,
"title": null,
"thumbnailId": "9365a9d3-440a-43e7-b4d5-427cf94b99c7",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/9365a9d3-440a-43e7-b4d5-427cf94b99c7",
"appearances": [{
"startTime": "00:04:28.2660000",
"endTime": "00:04:34.8330000",
"startSeconds": 268.3,
"endSeconds": 274.8
}],
"seenDuration": 6.5,
"seenDurationRatio": 0.0163727959697733
}, {
"id": 5321,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #11",
"description": null,
"title": null,
"thumbnailId": "a540dff4-3de4-49c5-bd7e-4a09899f4869",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/a540dff4-3de4-49c5-bd7e-4a09899f4869",
"appearances": [{
"startTime": "00:01:54.2660000",
"endTime": "00:02:00.7330000",
"startSeconds": 114.3,
"endSeconds": 120.7
}],
"seenDuration": 6.4000000000000057,
"seenDurationRatio": 0.01612090680100757
}, {
"id": 1755,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #49",
"description": null,
"title": null,
"thumbnailId": "bac0cf66-dded-48bb-8563-154e1592a138",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/bac0cf66-dded-48bb-8563-154e1592a138",
"appearances": [{
"startTime": "00:00:19.7330000",
"endTime": "00:00:25.6990000",
"startSeconds": 19.7,
"endSeconds": 25.7
}],
"seenDuration": 6.0,
"seenDurationRatio": 0.015113350125944584
}, {
"id": 1611,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #48",
"description": null,
"title": null,
"thumbnailId": "01831910-a74e-4feb-9c83-45a601063fb8",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/01831910-a74e-4feb-9c83-45a601063fb8",
"appearances": [{
"startTime": "00:00:20.0990000",
"endTime": "00:00:25.9990000",
"startSeconds": 20.1,
"endSeconds": 26.0
}],
"seenDuration": 5.8999999999999986,
"seenDurationRatio": 0.014861460957178838
}, {
"id": 17504,
"shortId": "86a059e4d2",
"bingId": "d6973c1f-14df-4d61-ed88-9733dd5e8122",
"confidence": 0.99418288469314575,
"name": "Mamata Banerjee",
"description": "Mamata Banerjee is a poet, painter, miscellanist and an Indian politician who has been the 8th Chief Minister of West Bengal since 2011. She is the first woman to hold the office. She founded the party All India Trinamool Congress in 1997 after separating from the Indian National Congress, and …",
"title": "Former Minister of Railways",
"thumbnailId": "c4c71204-cf63-45a4-9aa1-4f52e1a5467a",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/c4c71204-cf63-45a4-9aa1-4f52e1a5467a",
"appearances": [{
"startTime": "00:04:54.2990000",
"endTime": "00:05:00.0660000",
"startSeconds": 294.3,
"endSeconds": 300.1
}],
"seenDuration": 5.8000000000000114,
"seenDurationRatio": 0.014609571788413126
}, {
"id": 16794,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #18",
"description": null,
"title": null,
"thumbnailId": "a671a626-9043-40fd-ae8c-c5ebe8a1522b",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/a671a626-9043-40fd-ae8c-c5ebe8a1522b",
"appearances": [{
"startTime": "00:04:46.5660000",
"endTime": "00:04:52.3330000",
"startSeconds": 286.6,
"endSeconds": 292.3
}],
"seenDuration": 5.6999999999999886,
"seenDurationRatio": 0.014357682619647327
}, {
"id": 12225,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #20",
"description": null,
"title": null,
"thumbnailId": "662e5490-99ab-4ea3-9300-2755f41e9e28",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/662e5490-99ab-4ea3-9300-2755f41e9e28",
"appearances": [{
"startTime": "00:03:24.4400000",
"endTime": "00:03:30.0330000",
"startSeconds": 204.4,
"endSeconds": 210.0
}],
"seenDuration": 5.5999999999999943,
"seenDurationRatio": 0.014105793450881598
}, {
"id": 16116,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #22",
"description": null,
"title": null,
"thumbnailId": "7c020844-a4c3-49ec-8e10-8caee5134f98",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/7c020844-a4c3-49ec-8e10-8caee5134f98",
"appearances": [{
"startTime": "00:04:38.8330000",
"endTime": "00:04:44.3660000",
"startSeconds": 278.8,
"endSeconds": 284.4
}],
"seenDuration": 5.5999999999999659,
"seenDurationRatio": 0.014105793450881527
}, {
"id": 18696,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #30",
"description": null,
"title": null,
"thumbnailId": "30ac80a2-c980-40b4-b5ad-3cb49771f2b3",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/30ac80a2-c980-40b4-b5ad-3cb49771f2b3",
"appearances": [{
"startTime": "00:05:01.8210000",
"endTime": "00:05:07.4200000",
"startSeconds": 301.8,
"endSeconds": 307.4
}],
"seenDuration": 5.5999999999999659,
"seenDurationRatio": 0.014105793450881527
}, {
"id": 6186,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #32",
"description": null,
"title": null,
"thumbnailId": "205b99f7-9eb6-4872-a57f-e516423d2f6e",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/205b99f7-9eb6-4872-a57f-e516423d2f6e",
"appearances": [{
"startTime": "00:02:08.7990000",
"endTime": "00:02:14.2660000",
"startSeconds": 128.8,
"endSeconds": 134.3
}],
"seenDuration": 5.5,
"seenDurationRatio": 0.013853904282115869
}, {
"id": 12197,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #52",
"description": null,
"title": null,
"thumbnailId": "2a2cf3bd-b6d7-45ca-a0cd-28a6c9641e6f",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/2a2cf3bd-b6d7-45ca-a0cd-28a6c9641e6f",
"appearances": [{
"startTime": "00:03:24.5330000",
"endTime": "00:03:29.9990000",
"startSeconds": 204.5,
"endSeconds": 210.0
}],
"seenDuration": 5.5,
"seenDurationRatio": 0.013853904282115869
}, {
"id": 14393,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #16",
"description": null,
"title": null,
"thumbnailId": "32cd4be6-ef89-4f1a-b68a-c317576e8dcd",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/32cd4be6-ef89-4f1a-b68a-c317576e8dcd",
"appearances": [{
"startTime": "00:04:05.3330000",
"endTime": "00:04:10.8330000",
"startSeconds": 245.3,
"endSeconds": 250.8
}],
"seenDuration": 5.5,
"seenDurationRatio": 0.013853904282115869
}, {
"id": 16786,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #7",
"description": null,
"title": null,
"thumbnailId": "3617a8c1-4a38-44e6-897e-3b029790166c",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/3617a8c1-4a38-44e6-897e-3b029790166c",
"appearances": [{
"startTime": "00:04:47.9660000",
"endTime": "00:04:53.0660000",
"startSeconds": 288.0,
"endSeconds": 293.1
}],
"seenDuration": 5.1000000000000227,
"seenDurationRatio": 0.012846347607052954
}, {
"id": 9068,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #31",
"description": null,
"title": null,
"thumbnailId": "723fb77e-8024-4a6d-910e-d4f1272e789c",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/723fb77e-8024-4a6d-910e-d4f1272e789c",
"appearances": [{
"startTime": "00:02:43.3990000",
"endTime": "00:02:48.2330000",
"startSeconds": 163.4,
"endSeconds": 168.2
}],
"seenDuration": 4.7999999999999829,
"seenDurationRatio": 0.012090680100755624
}, {
"id": 18514,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #19",
"description": null,
"title": null,
"thumbnailId": "4dd81afb-6b9a-406b-8f10-c6b733a73963",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/4dd81afb-6b9a-406b-8f10-c6b733a73963",
"appearances": [{
"startTime": "00:05:00.1210000",
"endTime": "00:05:04.8200000",
"startSeconds": 300.1,
"endSeconds": 304.8
}],
"seenDuration": 4.6999999999999886,
"seenDurationRatio": 0.011838790931989895
}, {
"id": 20054,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #9",
"description": null,
"title": null,
"thumbnailId": "aa889671-f640-4ab4-ba5a-d09aac16b13f",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/aa889671-f640-4ab4-ba5a-d09aac16b13f",
"appearances": [{
"startTime": "00:05:36.6870000",
"endTime": "00:05:41.3530000",
"startSeconds": 336.7,
"endSeconds": 341.4
}],
"seenDuration": 4.6999999999999886,
"seenDurationRatio": 0.011838790931989895
}, {
"id": 1150,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #54",
"description": null,
"title": null,
"thumbnailId": "6c651c22-5503-4766-9647-9152891bce74",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/6c651c22-5503-4766-9647-9152891bce74",
"appearances": [{
"startTime": "00:00:05.0660000",
"endTime": "00:00:09.4990000",
"startSeconds": 5.1,
"endSeconds": 9.5
}],
"seenDuration": 4.4,
"seenDurationRatio": 0.011083123425692697
}, {
"id": 1960,
"shortId": "86a059e4d2",
"bingId": null,
"confidence": 0.0,
"name": "Unknown #23",
"description": null,
"title": null,
"thumbnailId": "f9a9e1c0-20a4-4656-933b-a96e122b2ad5",
"thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/f9a9e1c0-20a4-4656-933b-a96e122b2ad5",
"appearances": [{
"startTime": "00:00:21.3990000",
"endTime": "00:00:24.6990000",
"startSeconds": 21.4,
"endSeconds": 24.7
}],
"seenDuration": 3.3000000000000007,
"seenDurationRatio": 0.0083123425692695225
}],
"topics": [{
"name": "phone number",
"appearances": [{
"startTime": "00:01:02.7100000",
"endTime": "00:01:05.1000000",
"startSeconds": 62.7,
"endSeconds": 65.1
}],
"isTranscript": true,
"id": 0
}, {
"name": "double room",
"appearances": [{
"startTime": "00:04:46.2100000",
"endTime": "00:04:54.1200000",
"startSeconds": 286.2,
"endSeconds": 294.1
}, {
"startTime": "00:05:04.2840000",
"endTime": "00:05:07.4440000",
"startSeconds": 304.3,
"endSeconds": 307.4
}],
"isTranscript": true,
"id": 1
}, {
"name": "room",
"appearances": [{
"startTime": "00:02:26.2900000",
"endTime": "00:02:29.9700000",
"startSeconds": 146.3,
"endSeconds": 150.0
}, {
"startTime": "00:04:46.2100000",
"endTime": "00:04:54.1200000",
"startSeconds": 286.2,
"endSeconds": 294.1
}, {
"startTime": "00:04:54.1200000",
"endTime": "00:05:00.0940000",
"startSeconds": 294.1,
"endSeconds": 300.1
}, {
"startTime": "00:05:04.2840000",
"endTime": "00:05:07.4440000",
"startSeconds": 304.3,
"endSeconds": 307.4
}, {
"startTime": "00:06:12.6840000",
"endTime": "00:06:17.7640000",
"startSeconds": 372.7,
"endSeconds": 377.8
}],
"isTranscript": true,
"id": 2
}, {
"name": "money",
"appearances": [{
"startTime": "00:00:11.1600000",
"endTime": "00:00:15.0200000",
"startSeconds": 11.2,
"endSeconds": 15.0
}, {
"startTime": "00:00:51.2500000",
"endTime": "00:00:54.2200000",
"startSeconds": 51.2,
"endSeconds": 54.2
}, {
"startTime": "00:03:58.4600000",
"endTime": "00:04:03.6200000",
"startSeconds": 238.5,
"endSeconds": 243.6
}, {
"startTime": "00:06:06.4840000",
"endTime": "00:06:09.8040000",
"startSeconds": 366.5,
"endSeconds": 369.8
}, {
"startTime": "00:06:23.4840000",
"endTime": "00:06:24.2140000",
"startSeconds": 383.5,
"endSeconds": 384.2
}],
"isTranscript": true,
"id": 3
}],
"sentiments": [{
"sentimentKey": "Positive",
"appearances": [{
"startTime": "00:00:00",
"endTime": "00:00:07.2500000",
"startSeconds": 0.0,
"endSeconds": 7.2
}, {
"startTime": "00:01:18.8600000",
"endTime": "00:01:19.2600000",
"startSeconds": 78.9,
"endSeconds": 79.3
}, {
"startTime": "00:01:19.2600000",
"endTime": "00:01:20.0700000",
"startSeconds": 79.3,
"endSeconds": 80.1
}, {
"startTime": "00:01:20.0700000",
"endTime": "00:01:22.7200000",
"startSeconds": 80.1,
"endSeconds": 82.7
}, {
"startTime": "00:01:47.6200000",
"endTime": "00:01:53.1500000",
"startSeconds": 107.6,
"endSeconds": 113.2
}, {
"startTime": "00:02:52.3500000",
"endTime": "00:03:00.1500000",
"startSeconds": 172.4,
"endSeconds": 180.2
}, {
"startTime": "00:05:30.4640000",
"endTime": "00:05:59.9340000",
"startSeconds": 330.5,
"endSeconds": 359.9
}, {
"startTime": "00:06:02.3540000",
"endTime": "00:06:04.3240000",
"startSeconds": 362.4,
"endSeconds": 364.3
}],
"seenDurationRatio": 0.14075566750629723
}, {
"sentimentKey": "Neutral",
"appearances": [{
"startTime": "00:00:07.2500000",
"endTime": "00:00:11.1600000",
"startSeconds": 7.2,
"endSeconds": 11.2
}, {
"startTime": "00:00:11.1600000",
"endTime": "00:00:16.6700000",
"startSeconds": 11.2,
"endSeconds": 16.7
}, {
"startTime": "00:00:16.6700000",
"endTime": "00:00:34.7300000",
"startSeconds": 16.7,
"endSeconds": 34.7
}, {
"startTime": "00:00:34.7300000",
"endTime": "00:00:44.2600000",
"startSeconds": 34.7,
"endSeconds": 44.3
}, {
"startTime": "00:00:44.2600000",
"endTime": "00:00:46.9600000",
"startSeconds": 44.3,
"endSeconds": 47.0
}, {
"startTime": "00:00:46.9600000",
"endTime": "00:00:54.2200000",
"startSeconds": 47.0,
"endSeconds": 54.2
}, {
"startTime": "00:00:54.2200000",
"endTime": "00:00:57.0700000",
"startSeconds": 54.2,
"endSeconds": 57.1
}, {
"startTime": "00:01:05.1000000",
"endTime": "00:01:07.7600000",
"startSeconds": 65.1,
"endSeconds": 67.8
}, {
"startTime": "00:01:07.7600000",
"endTime": "00:01:11.6200000",
"startSeconds": 67.8,
"endSeconds": 71.6
}, {
"startTime": "00:01:11.6200000",
"endTime": "00:01:15.0200000",
"startSeconds": 71.6,
"endSeconds": 75.0
}, {
"startTime": "00:01:15.0200000",
"endTime": "00:01:15.8900000",
"startSeconds": 75.0,
"endSeconds": 75.9
}, {
"startTime": "00:01:15.8900000",
"endTime": "00:01:18.8600000",
"startSeconds": 75.9,
"endSeconds": 78.9
}, {
"startTime": "00:01:22.7200000",
"endTime": "00:01:46.8400000",
"startSeconds": 82.7,
"endSeconds": 106.8
}, {
"startTime": "00:01:46.8400000",
"endTime": "00:01:47.6200000",
"startSeconds": 106.8,
"endSeconds": 107.6
}, {
"startTime": "00:01:53.1500000",
"endTime": "00:01:55.3100000",
"startSeconds": 113.2,
"endSeconds": 115.3
}, {
"startTime": "00:02:09.4700000",
"endTime": "00:02:12.1500000",
"startSeconds": 129.5,
"endSeconds": 132.2
}, {
"startTime": "00:03:00.1500000",
"endTime": "00:03:19.6300000",
"startSeconds": 180.2,
"endSeconds": 199.6
}, {
"startTime": "00:03:19.6300000",
"endTime": "00:03:24.4400000",
"startSeconds": 199.6,
"endSeconds": 204.4
}, {
"startTime": "00:03:24.4400000",
"endTime": "00:03:27.4300000",
"startSeconds": 204.4,
"endSeconds": 207.4
}, {
"startTime": "00:03:27.4300000",
"endTime": "00:03:41.0600000",
"startSeconds": 207.4,
"endSeconds": 221.1
}, {
"startTime": "00:03:41.0600000",
"endTime": "00:03:44.1400000",
"startSeconds": 221.1,
"endSeconds": 224.1
}, {
"startTime": "00:03:44.1400000",
"endTime": "00:03:49.0300000",
"startSeconds": 224.1,
"endSeconds": 229.0
}, {
"startTime": "00:03:49.0300000",
"endTime": "00:03:52.5100000",
"startSeconds": 229.0,
"endSeconds": 232.5
}, {
"startTime": "00:03:52.5100000",
"endTime": "00:03:55.3800000",
"startSeconds": 232.5,
"endSeconds": 235.4
}, {
"startTime": "00:03:55.3800000",
"endTime": "00:03:58.4600000",
"startSeconds": 235.4,
"endSeconds": 238.5
}, {
"startTime": "00:03:58.4600000",
"endTime": "00:04:23.3500000",
"startSeconds": 238.5,
"endSeconds": 263.3
}, {
"startTime": "00:04:23.3500000",
"endTime": "00:04:32.8200000",
"startSeconds": 263.3,
"endSeconds": 272.8
}, {
"startTime": "00:04:32.8200000",
"endTime": "00:04:46.2100000",
"startSeconds": 272.8,
"endSeconds": 286.2
}, {
"startTime": "00:04:46.2100000",
"endTime": "00:05:16.8040000",
"startSeconds": 286.2,
"endSeconds": 316.8
}, {
"startTime": "00:05:16.8040000",
"endTime": "00:05:18.9140000",
"startSeconds": 316.8,
"endSeconds": 318.9
}, {
"startTime": "00:05:18.9140000",
"endTime": "00:05:22.1140000",
"startSeconds": 318.9,
"endSeconds": 322.1
}, {
"startTime": "00:05:22.1140000",
"endTime": "00:05:27.0940000",
"startSeconds": 322.1,
"endSeconds": 327.1
}, {
"startTime": "00:05:27.7540000",
"endTime": "00:05:30.4640000",
"startSeconds": 327.8,
"endSeconds": 330.5
}, {
"startTime": "00:05:59.9340000",
"endTime": "00:06:02.3540000",
"startSeconds": 359.9,
"endSeconds": 362.4
}, {
"startTime": "00:06:04.3240000",
"endTime": "00:06:06.4840000",
"startSeconds": 364.3,
"endSeconds": 366.5
}, {
"startTime": "00:06:06.4840000",
"endTime": "00:06:20.3340000",
"startSeconds": 366.5,
"endSeconds": 380.3
}, {
"startTime": "00:06:24.2140000",
"endTime": "00:06:27.1840000",
"startSeconds": 384.2,
"endSeconds": 387.2
}, {
"startTime": "00:06:27.1840000",
"endTime": "00:06:28.6640000",
"startSeconds": 387.2,
"endSeconds": 388.7
}, {
"startTime": "00:06:28.6640000",
"endTime": "00:06:31.6540000",
"startSeconds": 388.7,
"endSeconds": 391.7
}],
"seenDurationRatio": 0.67718891687657434
}, {
"sentimentKey": "Negative",
"appearances": [{
"startTime": "00:00:57.0700000",
"endTime": "00:01:05.1000000",
"startSeconds": 57.1,
"endSeconds": 65.1
}, {
"startTime": "00:01:55.3100000",
"endTime": "00:02:09.4700000",
"startSeconds": 115.3,
"endSeconds": 129.5
}, {
"startTime": "00:02:12.1500000",
"endTime": "00:02:52.3500000",
"startSeconds": 132.2,
"endSeconds": 172.4
}, {
"startTime": "00:05:27.0940000",
"endTime": "00:05:27.7540000",
"startSeconds": 327.1,
"endSeconds": 327.8
}, {
"startTime": "00:06:20.3340000",
"endTime": "00:06:24.2140000",
"startSeconds": 380.3,
"endSeconds": 384.2
}, {
"startTime": "00:06:31.6540000",
"endTime": "00:06:37",
"startSeconds": 391.7,
"endSeconds": 397.0
}],
"seenDurationRatio": 0.18205541561712846
}],
"audioEffects": [{
"audioEffectKey": "Speech",
"appearances": [{
"startTime": "00:00:01.3600000",
"endTime": "00:00:16.6700000",
"startSeconds": 1.4,
"endSeconds": 16.7
}, {
"startTime": "00:00:34.7300000",
"endTime": "00:01:22.7200000",
"startSeconds": 34.7,
"endSeconds": 82.7
}, {
"startTime": "00:01:46.8400000",
"endTime": "00:03:00.1500000",
"startSeconds": 106.8,
"endSeconds": 180.2
}, {
"startTime": "00:03:19.6300000",
"endTime": "00:04:32.8200000",
"startSeconds": 199.6,
"endSeconds": 272.8
}, {
"startTime": "00:04:46.2100000",
"endTime": "00:06:34.8440000",
"startSeconds": 286.2,
"endSeconds": 394.8
}],
"seenDurationRatio": 0.80226700251889171,
"seenDuration": 318.5
}],
"annotations": [{
"id": 1,
"name": "person",
"appearances": [{
"startTime": "00:00:00.0660000",
"endTime": "00:00:05.4000000",
"startSeconds": 0.1,
"endSeconds": 5.4
}, {
"startTime": "00:00:13.9330000",
"endTime": "00:00:17.1330000",
"startSeconds": 13.9,
"endSeconds": 17.1
}, {
"startTime": "00:00:21.3990000",
"endTime": "00:00:25.6660000",
"startSeconds": 21.4,
"endSeconds": 25.7
}, {
"startTime": "00:00:28.8660000",
"endTime": "00:00:40.6000000",
"startSeconds": 28.9,
"endSeconds": 40.6
}, {
"startTime": "00:00:49.1330000",
"endTime": "00:01:04.0660000",
"startSeconds": 49.1,
"endSeconds": 64.1
}, {
"startTime": "00:01:07.2660000",
"endTime": "00:01:26.4660000",
"startSeconds": 67.3,
"endSeconds": 86.5
}, {
"startTime": "00:01:33.9330000",
"endTime": "00:02:23",
"startSeconds": 93.9,
"endSeconds": 143.0
}, {
"startTime": "00:02:30.4660000",
"endTime": "00:02:36.8660000",
"startSeconds": 150.5,
"endSeconds": 156.9
}, {
"startTime": "00:02:45.3990000",
"endTime": "00:03:36.6000000",
"startSeconds": 165.4,
"endSeconds": 216.6
}, {
"startTime": "00:03:41.9330000",
"endTime": "00:04:26.7330000",
"startSeconds": 221.9,
"endSeconds": 266.7
}, {
"startTime": "00:04:29.9330000",
"endTime": "00:05:37.4540000",
"startSeconds": 269.9,
"endSeconds": 337.5
}]
}, {
"id": 6,
"name": "indoor",
"appearances": [{
"startTime": "00:00:25.6660000",
"endTime": "00:00:27.8000000",
"startSeconds": 25.7,
"endSeconds": 27.8
}, {
"startTime": "00:00:59.7990000",
"endTime": "00:01:00.8660000",
"startSeconds": 59.8,
"endSeconds": 60.9
}, {
"startTime": "00:01:47.7990000",
"endTime": "00:01:48.8660000",
"startSeconds": 107.8,
"endSeconds": 108.9
}, {
"startTime": "00:02:03.7990000",
"endTime": "00:02:07",
"startSeconds": 123.8,
"endSeconds": 127.0
}, {
"startTime": "00:03:14.1990000",
"endTime": "00:03:19.5330000",
"startSeconds": 194.2,
"endSeconds": 199.5
}, {
"startTime": "00:03:26.9990000",
"endTime": "00:03:28.0660000",
"startSeconds": 207.0,
"endSeconds": 208.1
}, {
"startTime": "00:04:04.3330000",
"endTime": "00:04:07.5330000",
"startSeconds": 244.3,
"endSeconds": 247.5
}, {
"startTime": "00:04:22.4660000",
"endTime": "00:04:26.7330000",
"startSeconds": 262.5,
"endSeconds": 266.7
}, {
"startTime": "00:04:29.9330000",
"endTime": "00:04:33.1330000",
"startSeconds": 269.9,
"endSeconds": 273.1
}, {
"startTime": "00:04:41.6660000",
"endTime": "00:04:52.3330000",
"startSeconds": 281.7,
"endSeconds": 292.3
}, {
"startTime": "00:05:04.3870000",
"endTime": "00:05:15.0540000",
"startSeconds": 304.4,
"endSeconds": 315.1
}, {
"startTime": "00:05:19.3200000",
"endTime": "00:05:21.4540000",
"startSeconds": 319.3,
"endSeconds": 321.5
}, {
"startTime": "00:05:24.6530000",
"endTime": "00:05:37.4540000",
"startSeconds": 324.7,
"endSeconds": 337.5
}]
}, {
"id": 5,
"name": "standing",
"appearances": [{
"startTime": "00:00:22.4660000",
"endTime": "00:00:24.6000000",
"startSeconds": 22.5,
"endSeconds": 24.6
}, {
"startTime": "00:00:28.8660000",
"endTime": "00:00:37.4000000",
"startSeconds": 28.9,
"endSeconds": 37.4
}, {
"startTime": "00:01:56.3330000",
"endTime": "00:01:59.5330000",
"startSeconds": 116.3,
"endSeconds": 119.5
}, {
"startTime": "00:02:08.0660000",
"endTime": "00:02:11.2660000",
"startSeconds": 128.1,
"endSeconds": 131.3
}, {
"startTime": "00:02:30.4660000",
"endTime": "00:02:36.8660000",
"startSeconds": 150.5,
"endSeconds": 156.9
}, {
"startTime": "00:02:51.7990000",
"endTime": "00:02:59.2660000",
"startSeconds": 171.8,
"endSeconds": 179.3
}, {
"startTime": "00:03:30.1990000",
"endTime": "00:03:33.4000000",
"startSeconds": 210.2,
"endSeconds": 213.4
}, {
"startTime": "00:04:00.0660000",
"endTime": "00:04:03.2660000",
"startSeconds": 240.1,
"endSeconds": 243.3
}, {
"startTime": "00:04:07.5330000",
"endTime": "00:04:10.7330000",
"startSeconds": 247.5,
"endSeconds": 250.7
}, {
"startTime": "00:04:22.4660000",
"endTime": "00:04:25.6660000",
"startSeconds": 262.5,
"endSeconds": 265.7
}, {
"startTime": "00:04:53.3990000",
"endTime": "00:04:55.5330000",
"startSeconds": 293.4,
"endSeconds": 295.5
}, {
"startTime": "00:05:00.1200000",
"endTime": "00:05:03.3200000",
"startSeconds": 300.1,
"endSeconds": 303.3
}, {
"startTime": "00:05:23.5870000",
"endTime": "00:05:28.9200000",
"startSeconds": 323.6,
"endSeconds": 328.9
}, {
"startTime": "00:05:32.1200000",
"endTime": "00:05:37.4540000",
"startSeconds": 332.1,
"endSeconds": 337.5
}]
}, {
"id": 3,
"name": "posing",
"appearances": [{
"startTime": "00:00:00.0660000",
"endTime": "00:00:05.4000000",
"startSeconds": 0.1,
"endSeconds": 5.4
}, {
"startTime": "00:00:21.3990000",
"endTime": "00:00:24.6000000",
"startSeconds": 21.4,
"endSeconds": 24.6
}, {
"startTime": "00:01:01.9330000",
"endTime": "00:01:03",
"startSeconds": 61.9,
"endSeconds": 63.0
}, {
"startTime": "00:01:54.1990000",
"endTime": "00:01:59.5330000",
"startSeconds": 114.2,
"endSeconds": 119.5
}, {
"startTime": "00:02:08.0660000",
"endTime": "00:02:14.4660000",
"startSeconds": 128.1,
"endSeconds": 134.5
}, {
"startTime": "00:02:30.4660000",
"endTime": "00:02:36.8660000",
"startSeconds": 150.5,
"endSeconds": 156.9
}, {
"startTime": "00:02:45.3990000",
"endTime": "00:02:48.6000000",
"startSeconds": 165.4,
"endSeconds": 168.6
}, {
"startTime": "00:02:52.8660000",
"endTime": "00:02:59.2660000",
"startSeconds": 172.9,
"endSeconds": 179.3
}, {
"startTime": "00:03:26.9990000",
"endTime": "00:03:29.1330000",
"startSeconds": 207.0,
"endSeconds": 209.1
}, {
"startTime": "00:04:07.5330000",
"endTime": "00:04:10.7330000",
"startSeconds": 247.5,
"endSeconds": 250.7
}, {
"startTime": "00:04:14.9990000",
"endTime": "00:04:18.2000000",
"startSeconds": 255.0,
"endSeconds": 258.2
}, {
"startTime": "00:05:24.6530000",
"endTime": "00:05:25.7200000",
"startSeconds": 324.7,
"endSeconds": 325.7
}, {
"startTime": "00:05:34.2530000",
"endTime": "00:05:37.4540000",
"startSeconds": 334.3,
"endSeconds": 337.5
}]
}, {
"id": 15,
"name": "man",
"appearances": [{
"startTime": "00:02:48.5990000",
"endTime": "00:02:59.2660000",
"startSeconds": 168.6,
"endSeconds": 179.3
}, {
"startTime": "00:03:30.1990000",
"endTime": "00:03:33.4000000",
"startSeconds": 210.2,
"endSeconds": 213.4
}, {
"startTime": "00:04:00.0660000",
"endTime": "00:04:03.2660000",
"startSeconds": 240.1,
"endSeconds": 243.3
}, {
"startTime": "00:04:33.1330000",
"endTime": "00:04:34.2000000",
"startSeconds": 273.1,
"endSeconds": 274.2
}, {
"startTime": "00:05:08.6530000",
"endTime": "00:05:10.7870000",
"startSeconds": 308.7,
"endSeconds": 310.8
}]
}, {
"id": 10,
"name": "outdoor",
"appearances": [{
"startTime": "00:01:14.7330000",
"endTime": "00:01:15.8000000",
"startSeconds": 74.7,
"endSeconds": 75.8
}, {
"startTime": "00:01:33.9330000",
"endTime": "00:01:37.1330000",
"startSeconds": 93.9,
"endSeconds": 97.1
}, {
"startTime": "00:01:48.8660000",
"endTime": "00:01:53.1330000",
"startSeconds": 108.9,
"endSeconds": 113.1
}, {
"startTime": "00:02:00.5990000",
"endTime": "00:02:03.8000000",
"startSeconds": 120.6,
"endSeconds": 123.8
}, {
"startTime": "00:02:08.0660000",
"endTime": "00:02:11.2660000",
"startSeconds": 128.1,
"endSeconds": 131.3
}]
}, {
"id": 4,
"name": "group",
"appearances": [{
"startTime": "00:00:21.3990000",
"endTime": "00:00:24.6000000",
"startSeconds": 21.4,
"endSeconds": 24.6
}, {
"startTime": "00:02:45.3990000",
"endTime": "00:02:48.6000000",
"startSeconds": 165.4,
"endSeconds": 168.6
}, {
"startTime": "00:02:59.2660000",
"endTime": "00:03:00.3330000",
"startSeconds": 179.3,
"endSeconds": 180.3
}, {
"startTime": "00:03:06.7330000",
"endTime": "00:03:07.8000000",
"startSeconds": 186.7,
"endSeconds": 187.8
}, {
"startTime": "00:03:26.9990000",
"endTime": "00:03:29.1330000",
"startSeconds": 207.0,
"endSeconds": 209.1
}, {
"startTime": "00:04:08.5990000",
"endTime": "00:04:10.7330000",
"startSeconds": 248.6,
"endSeconds": 250.7
}, {
"startTime": "00:05:21.4530000",
"endTime": "00:05:22.5200000",
"startSeconds": 321.5,
"endSeconds": 322.5
}]
}, {
"id": 7,
"name": "wall",
"appearances": [{
"startTime": "00:00:37.3990000",
"endTime": "00:00:40.6000000",
"startSeconds": 37.4,
"endSeconds": 40.6
}, {
"startTime": "00:02:45.3990000",
"endTime": "00:02:48.6000000",
"startSeconds": 165.4,
"endSeconds": 168.6
}, {
"startTime": "00:03:26.9990000",
"endTime": "00:03:29.1330000",
"startSeconds": 207.0,
"endSeconds": 209.1
}, {
"startTime": "00:04:01.1330000",
"endTime": "00:04:03.2660000",
"startSeconds": 241.1,
"endSeconds": 243.3
}, {
"startTime": "00:04:53.3990000",
"endTime": "00:04:55.5330000",
"startSeconds": 293.4,
"endSeconds": 295.5
}]
}, {
"id": 8,
"name": "woman",
"appearances": [{
"startTime": "00:01:00.8660000",
"endTime": "00:01:03",
"startSeconds": 60.9,
"endSeconds": 63.0
}, {
"startTime": "00:01:33.9330000",
"endTime": "00:01:37.1330000",
"startSeconds": 93.9,
"endSeconds": 97.1
}, {
"startTime": "00:02:02.7330000",
"endTime": "00:02:03.8000000",
"startSeconds": 122.7,
"endSeconds": 123.8
}, {
"startTime": "00:03:08.8660000",
"endTime": "00:03:11",
"startSeconds": 188.9,
"endSeconds": 191.0
}, {
"startTime": "00:04:03.2660000",
"endTime": "00:04:07.5330000",
"startSeconds": 243.3,
"endSeconds": 247.5
}]
}, {
"id": 16,
"name": "ceiling",
"appearances": [{
"startTime": "00:03:26.9990000",
"endTime": "00:03:28.0660000",
"startSeconds": 207.0,
"endSeconds": 208.1
}, {
"startTime": "00:04:23.5330000",
"endTime": "00:04:24.6000000",
"startSeconds": 263.5,
"endSeconds": 264.6
}, {
"startTime": "00:05:03.3200000",
"endTime": "00:05:07.5870000",
"startSeconds": 303.3,
"endSeconds": 307.6
}]
}, {
"id": 2,
"name": "holding",
"appearances": [{
"startTime": "00:00:00.0660000",
"endTime": "00:00:05.4000000",
"startSeconds": 0.1,
"endSeconds": 5.4
}, {
"startTime": "00:03:34.4660000",
"endTime": "00:03:35.5330000",
"startSeconds": 214.5,
"endSeconds": 215.5
}]
}, {
"id": 9,
"name": "clothing",
"appearances": [{
"startTime": "00:01:07.2660000",
"endTime": "00:01:08.3330000",
"startSeconds": 67.3,
"endSeconds": 68.3
}, {
"startTime": "00:01:23.2660000",
"endTime": "00:01:26.4660000",
"startSeconds": 83.3,
"endSeconds": 86.5
}, {
"startTime": "00:05:22.5200000",
"endTime": "00:05:23.5870000",
"startSeconds": 322.5,
"endSeconds": 323.6
}]
}, {
"id": 14,
"name": "people",
"appearances": [{
"startTime": "00:02:47.5330000",
"endTime": "00:02:48.6000000",
"startSeconds": 167.5,
"endSeconds": 168.6
}, {
"startTime": "00:03:06.7330000",
"endTime": "00:03:07.8000000",
"startSeconds": 186.7,
"endSeconds": 187.8
}, {
"startTime": "00:03:49.3990000",
"endTime": "00:03:51.5330000",
"startSeconds": 229.4,
"endSeconds": 231.5
}]
}, {
"id": 21,
"name": "crowd",
"appearances": [{
"startTime": "00:05:15.0530000",
"endTime": "00:05:19.3200000",
"startSeconds": 315.1,
"endSeconds": 319.3
}]
}, {
"id": 11,
"name": "tree",
"appearances": [{
"startTime": "00:02:08.0660000",
"endTime": "00:02:11.2660000",
"startSeconds": 128.1,
"endSeconds": 131.3
}]
}, {
"id": 17,
"name": "text",
"appearances": [{
"startTime": "00:03:52.5990000",
"endTime": "00:03:55.8000000",
"startSeconds": 232.6,
"endSeconds": 235.8
}]
}, {
"id": 20,
"name": "cake",
"appearances": [{
"startTime": "00:04:30.9990000",
"endTime": "00:04:33.1330000",
"startSeconds": 271.0,
"endSeconds": 273.1
}]
}, {
"id": 22,
"name": "young",
"appearances": [{
"startTime": "00:05:33.1870000",
"endTime": "00:05:34.2540000",
"startSeconds": 333.2,
"endSeconds": 334.3
}]
}, {
"id": 13,
"name": "bed",
"appearances": [{
"startTime": "00:02:25.1330000",
"endTime": "00:02:26.2000000",
"startSeconds": 145.1,
"endSeconds": 146.2
}]
}, {
"id": 12,
"name": "white",
"appearances": [{
"startTime": "00:02:11.2660000",
"endTime": "00:02:12.3330000",
"startSeconds": 131.3,
"endSeconds": 132.3
}]
}, {
"id": 18,
"name": "black",
"appearances": [{
"startTime": "00:03:56.8660000",
"endTime": "00:03:57.9330000",
"startSeconds": 236.9,
"endSeconds": 237.9
}]
}, {
"id": 19,
"name": "wedding",
"appearances": [{
"startTime": "00:04:03.2660000",
"endTime": "00:04:04.3330000",
"startSeconds": 243.3,
"endSeconds": 244.3
}]
}, {
"id": 0,
"name": "Black Frames",
"appearances": [{
"startTime": "00:01:40.6000000",
"endTime": "00:01:40.6330000",
"startSeconds": 100.6,
"endSeconds": 100.6
}, {
"startTime": "00:05:41.2330000",
"endTime": "00:06:37.2330000",
"startSeconds": 341.2,
"endSeconds": 397.2
}]
}],
"brands": [{
"id": 1,
"name": "Google",
"wikiId": "Google",
"wikiUrl": "http://en.wikipedia.org/wiki/Google",
"confidence": 0.564,
"description": "Google is an American multinational technology company specializing in Internet-related services and products. These include online advertising technologies, search, cloud computing, and software. Most of its profits are derived from AdWords, an online advertising service that places advertising near the list of search results.",
"appearances": [{
"startTime": "00:05:30.5040000",
"endTime": "00:05:40.8240000",
"startSeconds": 330.5,
"endSeconds": 340.8
}],
"seenDuration": 10.300000000000011
}],
"statistics": {
"correspondenceCount": 11,
"speakerTalkToListenRatio": {
"1": 0.001,
"2": 0.586,
"3": 0.001,
"4": 0.052,
"5": 0.026
},
"speakerLongestMonolog": {
"1": 0,
"2": 94,
"3": 0,
"4": 9,
"5": 16
},
"speakerNumberOfFragments": {
"1": 1,
"2": 21,
"3": 1,
"4": 4,
"5": 3
},
"speakerWordCount": {
"1": 1,
"2": 494,
"3": 2,
"4": 41,
"5": 21
}
}
},
"breakdowns": [{
"accountId": "a76ef345-7cef-4367-9599-5c0eca019523",
"id": "86a059e4d2",
"state": "Processed",
"processingProgress": "100%",
"failureCode": "General",
"failureMessage": "",
"externalId": null,
"externalUrl": null,
"metadata": null,
"insights": {
"transcriptBlocks": [{
"id": 0,
"lines": [{
"id": 0,
"timeRange": {
"start": "00:00:00",
"end": "00:00:04.6200000"
},
"adjustedTimeRange": {
"start": "00:00:00",
"end": "00:00:04.6200000"
},
"participantId": 2,
"text": "Thank God I'm Hey",
"isIncluded": true,
"confidence": 0.4251497
}, {
"id": 1,
"timeRange": {
"start": "00:00:04.6200000",
"end": "00:00:05.7700000"
},
"adjustedTimeRange": {
"start": "00:00:04.6200000",
"end": "00:00:05.7700000"
},
"participantId": 2,
"text": "but",
"isIncluded": true,
"confidence": 0.6347305
}, {
"id": 2,
"timeRange": {
"start": "00:00:05.7700000",
"end": "00:00:07.0100000"
},
"adjustedTimeRange": {
"start": "00:00:05.7700000",
"end": "00:00:07.0100000"
},
"participantId": 2,
"text": "it never did tell",
"isIncluded": true,
"confidence": 0.66443485
}, {
"id": 3,
"timeRange": {
"start": "00:00:07.0100000",
"end": "00:00:07.2500000"
},
"adjustedTimeRange": {
"start": "00:00:07.0100000",
"end": "00:00:07.2500000"
},
"participantId": 2,
"text": "us.",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.945013762,
"faces": [{
"id": 19617,
"thumbnailId": "f7aa1f74-a636-40f6-9cbc-aae70d5214f3",
"ranges": [{
"timeRange": {
"start": "00:00:00.0670000",
"end": "00:00:05.0660000"
},
"adjustedTimeRange": {
"start": "00:00:00.0670000",
"end": "00:00:05.0660000"
}
}]
}, {
"id": 1150,
"thumbnailId": "45f8e11f-e7c1-4f21-a6f1-2e0ad7c99ef0",
"ranges": [{
"timeRange": {
"start": "00:00:05.0660000",
"end": "00:00:07.2500000"
},
"adjustedTimeRange": {
"start": "00:00:05.0660000",
"end": "00:00:07.2500000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:00:01.3600000",
"end": "00:00:07.2500000"
}
}]
}],
"scenes": [{
"id": 0,
"timeRange": {
"start": "00:00:00",
"end": "00:00:05.0660000"
},
"keyFrame": "00:00:00.2000000",
"keyFrameThumbnailId": "cf66be09-f8fa-436a-bc7d-44f12cc83eeb",
"shots": [{
"id": 0,
"timeRange": {
"start": "00:00:00",
"end": "00:00:05.0660000"
},
"keyFrame": "00:00:00.2000000",
"keyFrameThumbnailId": "fce7b713-31da-4406-ac0c-588b0b08c67b"
}]
}, {
"id": 1,
"timeRange": {
"start": "00:00:05.0660000",
"end": "00:00:07.2500000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "5c6fd721-c691-4727-8ee7-cbb79ed0bc64",
"shots": [{
"id": 1,
"timeRange": {
"start": "00:00:05.0660000",
"end": "00:00:07.2500000"
},
"keyFrame": "00:00:17.0670000",
"keyFrameThumbnailId": "93cf1512-4e6d-4084-b8fc-de59afa51d99"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:00:00.0660000",
"end": "00:00:05.4000000"
}],
"adjustedTimeRanges": [{
"start": "00:00:00.0660000",
"end": "00:00:05.4000000"
}]
}, {
"id": 2,
"name": "holding",
"timeRanges": [{
"start": "00:00:00.0660000",
"end": "00:00:05.4000000"
}],
"adjustedTimeRanges": [{
"start": "00:00:00.0660000",
"end": "00:00:05.4000000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:00:00.0660000",
"end": "00:00:05.4000000"
}],
"adjustedTimeRanges": [{
"start": "00:00:00.0660000",
"end": "00:00:05.4000000"
}]
}]
}, {
"id": 1,
"lines": [{
"id": 4,
"timeRange": {
"start": "00:00:07.2500000",
"end": "00:00:11.1600000"
},
"adjustedTimeRange": {
"start": "00:00:07.2500000",
"end": "00:00:11.1600000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 1286,
"thumbnailId": "7a8da2af-1dc9-42a5-b03a-d00b468d5716",
"ranges": [{
"timeRange": {
"start": "00:00:09.4990000",
"end": "00:00:11.1600000"
},
"adjustedTimeRange": {
"start": "00:00:09.4990000",
"end": "00:00:11.1600000"
}
}]
}, {
"id": 1150,
"thumbnailId": "ea70801b-6686-44fb-a21b-123fc35e41bf",
"ranges": [{
"timeRange": {
"start": "00:00:07.2500000",
"end": "00:00:09.4990000"
},
"adjustedTimeRange": {
"start": "00:00:07.2500000",
"end": "00:00:09.4990000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:00:07.2500000",
"end": "00:00:07.2500000"
}
}]
}],
"scenes": [{
"id": 1,
"timeRange": {
"start": "00:00:07.2500000",
"end": "00:00:11.1600000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "5c6fd721-c691-4727-8ee7-cbb79ed0bc64",
"shots": [{
"id": 1,
"timeRange": {
"start": "00:00:07.2500000",
"end": "00:00:11.1600000"
},
"keyFrame": "00:00:17.0670000",
"keyFrameThumbnailId": "93cf1512-4e6d-4084-b8fc-de59afa51d99"
}]
}],
"annotations": []
}, {
"id": 2,
"lines": [{
"id": 5,
"timeRange": {
"start": "00:00:11.1600000",
"end": "00:00:15.0200000"
},
"adjustedTimeRange": {
"start": "00:00:11.1600000",
"end": "00:00:15.0200000"
},
"participantId": 2,
"text": "Now I'm going money Mayweather yay",
"isIncluded": true,
"confidence": 0.49169382500000003
}, {
"id": 6,
"timeRange": {
"start": "00:00:15.0200000",
"end": "00:00:15.7500000"
},
"adjustedTimeRange": {
"start": "00:00:15.0200000",
"end": "00:00:15.7500000"
},
"participantId": 2,
"text": "my",
"isIncluded": true,
"confidence": 1.0
}, {
"id": 7,
"timeRange": {
"start": "00:00:15.7500000",
"end": "00:00:16.6700000"
},
"adjustedTimeRange": {
"start": "00:00:15.7500000",
"end": "00:00:16.6700000"
},
"participantId": 2,
"text": "recovery.",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.822141051,
"faces": [{
"id": 1286,
"thumbnailId": "80065d16-d41b-4ea0-b7c9-afca5ce36a56",
"ranges": [{
"timeRange": {
"start": "00:00:11.1600000",
"end": "00:00:14.8990000"
},
"adjustedTimeRange": {
"start": "00:00:11.1600000",
"end": "00:00:14.8990000"
}
}]
}, {
"id": 1398,
"thumbnailId": "1db7d6b5-0c6b-47f2-9450-616e0acea9f8",
"ranges": [{
"timeRange": {
"start": "00:00:11.8990000",
"end": "00:00:16.6700000"
},
"adjustedTimeRange": {
"start": "00:00:11.8990000",
"end": "00:00:16.6700000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:00:11.1600000",
"end": "00:00:16.6700000"
}
}]
}],
"scenes": [{
"id": 1,
"timeRange": {
"start": "00:00:11.1600000",
"end": "00:00:16.6700000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "5c6fd721-c691-4727-8ee7-cbb79ed0bc64",
"shots": [{
"id": 1,
"timeRange": {
"start": "00:00:11.1600000",
"end": "00:00:16.6700000"
},
"keyFrame": "00:00:17.0670000",
"keyFrameThumbnailId": "93cf1512-4e6d-4084-b8fc-de59afa51d99"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:00:13.9330000",
"end": "00:00:16.6700000"
}],
"adjustedTimeRanges": [{
"start": "00:00:13.9330000",
"end": "00:00:16.6700000"
}]
}]
}, {
"id": 3,
"lines": [{
"id": 8,
"timeRange": {
"start": "00:00:16.6700000",
"end": "00:00:34.7300000"
},
"adjustedTimeRange": {
"start": "00:00:16.6700000",
"end": "00:00:34.7300000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "aef2c49e-1672-402a-9f97-188281fbb55e",
"ranges": [{
"timeRange": {
"start": "00:00:22.7660000",
"end": "00:00:29.8330000"
},
"adjustedTimeRange": {
"start": "00:00:22.7660000",
"end": "00:00:29.8330000"
}
}]
}, {
"id": 4663,
"thumbnailId": "1c0d4b79-688f-4b80-b99e-43d2e991e92e",
"ranges": [{
"timeRange": {
"start": "00:00:32.5660000",
"end": "00:00:34.7300000"
},
"adjustedTimeRange": {
"start": "00:00:32.5660000",
"end": "00:00:34.7300000"
}
}]
}, {
"id": 1960,
"thumbnailId": "b8c021f5-5a1e-44ab-840f-9b209940235f",
"ranges": [{
"timeRange": {
"start": "00:00:21.3990000",
"end": "00:00:24.6990000"
},
"adjustedTimeRange": {
"start": "00:00:21.3990000",
"end": "00:00:24.6990000"
}
}]
}, {
"id": 1286,
"thumbnailId": "6ed0a2b5-bf53-409f-b2e1-ea604b4635f5",
"ranges": [{
"timeRange": {
"start": "00:00:26.3990000",
"end": "00:00:32.5660000"
},
"adjustedTimeRange": {
"start": "00:00:26.3990000",
"end": "00:00:32.5660000"
}
}]
}, {
"id": 1398,
"thumbnailId": "875845bf-efe5-442f-ac41-315b6d77d258",
"ranges": [{
"timeRange": {
"start": "00:00:16.6700000",
"end": "00:00:22.3660000"
},
"adjustedTimeRange": {
"start": "00:00:16.6700000",
"end": "00:00:22.3660000"
}
}]
}, {
"id": 9114,
"thumbnailId": "b94c9872-1af5-4ee4-991e-c2fe311d3cd7",
"ranges": [{
"timeRange": {
"start": "00:00:20.0990000",
"end": "00:00:24.8660000"
},
"adjustedTimeRange": {
"start": "00:00:20.0990000",
"end": "00:00:24.8660000"
}
}]
}, {
"id": 1611,
"thumbnailId": "6a86fa03-fb53-43e0-8aa8-050cbd997bd6",
"ranges": [{
"timeRange": {
"start": "00:00:20.0990000",
"end": "00:00:25.9990000"
},
"adjustedTimeRange": {
"start": "00:00:20.0990000",
"end": "00:00:25.9990000"
}
}]
}, {
"id": 1755,
"thumbnailId": "bac0cf66-dded-48bb-8563-154e1592a138",
"ranges": [{
"timeRange": {
"start": "00:00:19.7330000",
"end": "00:00:25.6990000"
},
"adjustedTimeRange": {
"start": "00:00:19.7330000",
"end": "00:00:25.6990000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:00:16.6700000",
"end": "00:00:16.6700000"
}
}]
}],
"scenes": [{
"id": 1,
"timeRange": {
"start": "00:00:16.6700000",
"end": "00:00:34.7300000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "5c6fd721-c691-4727-8ee7-cbb79ed0bc64",
"shots": [{
"id": 1,
"timeRange": {
"start": "00:00:16.6700000",
"end": "00:00:32.5660000"
},
"keyFrame": "00:00:17.0670000",
"keyFrameThumbnailId": "93cf1512-4e6d-4084-b8fc-de59afa51d99"
}, {
"id": 2,
"timeRange": {
"start": "00:00:32.5660000",
"end": "00:00:34.7300000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "02794dc8-3c49-4eba-be9d-f8229eccf9cd"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:00:16.6700000",
"end": "00:00:17.1330000"
}, {
"start": "00:00:21.3990000",
"end": "00:00:25.6660000"
}, {
"start": "00:00:28.8660000",
"end": "00:00:34.7300000"
}],
"adjustedTimeRanges": [{
"start": "00:00:16.6700000",
"end": "00:00:17.1330000"
}, {
"start": "00:00:21.3990000",
"end": "00:00:25.6660000"
}, {
"start": "00:00:28.8660000",
"end": "00:00:34.7300000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:00:21.3990000",
"end": "00:00:24.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:00:21.3990000",
"end": "00:00:24.6000000"
}]
}, {
"id": 4,
"name": "group",
"timeRanges": [{
"start": "00:00:21.3990000",
"end": "00:00:24.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:00:21.3990000",
"end": "00:00:24.6000000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:00:22.4660000",
"end": "00:00:24.6000000"
}, {
"start": "00:00:28.8660000",
"end": "00:00:34.7300000"
}],
"adjustedTimeRanges": [{
"start": "00:00:22.4660000",
"end": "00:00:24.6000000"
}, {
"start": "00:00:28.8660000",
"end": "00:00:34.7300000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:00:25.6660000",
"end": "00:00:27.8000000"
}],
"adjustedTimeRanges": [{
"start": "00:00:25.6660000",
"end": "00:00:27.8000000"
}]
}]
}, {
"id": 4,
"lines": [{
"id": 9,
"timeRange": {
"start": "00:00:34.7300000",
"end": "00:00:35.0900000"
},
"adjustedTimeRange": {
"start": "00:00:34.7300000",
"end": "00:00:35.0900000"
},
"participantId": 2,
"text": "I'm",
"isIncluded": true,
"confidence": 0.5
}, {
"id": 10,
"timeRange": {
"start": "00:00:35.0900000",
"end": "00:00:39.8500000"
},
"adjustedTimeRange": {
"start": "00:00:35.0900000",
"end": "00:00:39.8500000"
},
"participantId": 2,
"text": "gonna die die die yay but it happen.",
"isIncluded": true,
"confidence": 0.87475
}, {
"id": 11,
"timeRange": {
"start": "00:00:39.8500000",
"end": "00:00:42.8900000"
},
"adjustedTimeRange": {
"start": "00:00:39.8500000",
"end": "00:00:42.8900000"
},
"participantId": 2,
"text": "to my name Gabe are there he might",
"isIncluded": true,
"confidence": 0.7902944125000001
}, {
"id": 12,
"timeRange": {
"start": "00:00:42.8900000",
"end": "00:00:43.3500000"
},
"adjustedTimeRange": {
"start": "00:00:42.8900000",
"end": "00:00:43.3500000"
},
"participantId": 2,
"text": "have",
"isIncluded": true,
"confidence": 1.0
}, {
"id": 13,
"timeRange": {
"start": "00:00:43.3500000",
"end": "00:00:44.2600000"
},
"adjustedTimeRange": {
"start": "00:00:43.3500000",
"end": "00:00:44.2600000"
},
"participantId": 2,
"text": "other help.",
"isIncluded": true,
"confidence": 0.72289825
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.7700575,
"faces": [{
"id": 19617,
"thumbnailId": "05098f5a-3b68-456f-8a5a-f7ccea5b22d9",
"ranges": [{
"timeRange": {
"start": "00:00:34.8660000",
"end": "00:00:44.2600000"
},
"adjustedTimeRange": {
"start": "00:00:34.8660000",
"end": "00:00:44.2600000"
}
}]
}, {
"id": 4663,
"thumbnailId": "d5ba47bb-da3b-4a39-a844-247671a5fbb4",
"ranges": [{
"timeRange": {
"start": "00:00:34.7300000",
"end": "00:00:38.0990000"
},
"adjustedTimeRange": {
"start": "00:00:34.7300000",
"end": "00:00:38.0990000"
}
}]
}, {
"id": 2635,
"thumbnailId": "88595de1-a5dd-4c47-9bbd-1ad6372ee9aa",
"ranges": [{
"timeRange": {
"start": "00:00:39.0990000",
"end": "00:00:44.2600000"
},
"adjustedTimeRange": {
"start": "00:00:39.0990000",
"end": "00:00:44.2600000"
}
}]
}],
"ocrs": [{
"timeRange": {
"start": "00:00:44",
"end": "00:00:46"
},
"adjustedTimeRange": {
"start": "00:00:44",
"end": "00:00:44.2600000"
},
"lines": [{
"id": 2,
"width": 0,
"height": 0,
"language": "French",
"textData": "jayala",
"confidence": 0.459
}, {
"id": 3,
"width": 0,
"height": 0,
"language": "French",
"textData": "Fyalalitha d",
"confidence": 0.48209090909090913
}, {
"id": 4,
"width": 0,
"height": 0,
"language": "French",
"textData": "Ai",
"confidence": 0.447
}, {
"id": 5,
"width": 0,
"height": 0,
"language": "French",
"textData": "tzztnculation",
"confidence": 0.342
}]
}],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:00:34.7300000",
"end": "00:00:38.2800000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:00:39.8500000",
"end": "00:00:44.2600000"
}
}]
}],
"scenes": [{
"id": 1,
"timeRange": {
"start": "00:00:34.7300000",
"end": "00:00:44.2600000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "5c6fd721-c691-4727-8ee7-cbb79ed0bc64",
"shots": [{
"id": 2,
"timeRange": {
"start": "00:00:34.7300000",
"end": "00:00:44.2600000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "02794dc8-3c49-4eba-be9d-f8229eccf9cd"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:00:34.7300000",
"end": "00:00:37.4000000"
}, {
"start": "00:00:38.4660000",
"end": "00:00:40.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:00:34.7300000",
"end": "00:00:37.4000000"
}, {
"start": "00:00:38.4660000",
"end": "00:00:40.6000000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:00:34.7300000",
"end": "00:00:37.4000000"
}],
"adjustedTimeRanges": [{
"start": "00:00:34.7300000",
"end": "00:00:37.4000000"
}]
}, {
"id": 7,
"name": "wall",
"timeRanges": [{
"start": "00:00:37.3990000",
"end": "00:00:40.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:00:37.3990000",
"end": "00:00:40.6000000"
}]
}]
}, {
"id": 5,
"lines": [{
"id": 14,
"timeRange": {
"start": "00:00:44.2600000",
"end": "00:00:46.9600000"
},
"adjustedTimeRange": {
"start": "00:00:44.2600000",
"end": "00:00:46.9600000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "affa6f63-d038-4468-8fe5-dae9cf585d2c",
"ranges": [{
"timeRange": {
"start": "00:00:44.2600000",
"end": "00:00:46.9600000"
},
"adjustedTimeRange": {
"start": "00:00:44.2600000",
"end": "00:00:46.9600000"
}
}]
}, {
"id": 2635,
"thumbnailId": "2776eb6b-52d6-4d6e-99a4-03925fcb78cb",
"ranges": [{
"timeRange": {
"start": "00:00:44.2600000",
"end": "00:00:46.1660000"
},
"adjustedTimeRange": {
"start": "00:00:44.2600000",
"end": "00:00:46.1660000"
}
}]
}],
"ocrs": [{
"timeRange": {
"start": "00:00:46",
"end": "00:00:48"
},
"adjustedTimeRange": {
"start": "00:00:46",
"end": "00:00:46.9600000"
},
"lines": [{
"id": 7,
"width": 0,
"height": 0,
"language": "English",
"textData": "jayalalitha ding",
"confidence": 0.5388125
}, {
"id": 8,
"width": 0,
"height": 0,
"language": "English",
"textData": "her matriculation",
"confidence": 0.9035625
}]
}],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:00:44.2600000",
"end": "00:00:44.2600000"
}
}]
}],
"scenes": [{
"id": 1,
"timeRange": {
"start": "00:00:44.2600000",
"end": "00:00:46.9600000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "5c6fd721-c691-4727-8ee7-cbb79ed0bc64",
"shots": [{
"id": 2,
"timeRange": {
"start": "00:00:44.2600000",
"end": "00:00:46.9600000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "02794dc8-3c49-4eba-be9d-f8229eccf9cd"
}]
}],
"annotations": []
}, {
"id": 6,
"lines": [{
"id": 15,
"timeRange": {
"start": "00:00:46.9600000",
"end": "00:00:51.2500000"
},
"adjustedTimeRange": {
"start": "00:00:46.9600000",
"end": "00:00:51.2500000"
},
"participantId": 2,
"text": "I mean not open man.",
"isIncluded": true,
"confidence": 0.75679999999999992
}, {
"id": 16,
"timeRange": {
"start": "00:00:51.2500000",
"end": "00:00:54.2200000"
},
"adjustedTimeRange": {
"start": "00:00:51.2500000",
"end": "00:00:54.2200000"
},
"participantId": 2,
"text": "money in order cool man I'm gonna?",
"isIncluded": true,
"confidence": 0.6347012428571428
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.7508914,
"faces": [{
"id": 19617,
"thumbnailId": "e3a24b99-29d3-483c-9371-766034ae48d9",
"ranges": [{
"timeRange": {
"start": "00:00:46.9600000",
"end": "00:00:54.2200000"
},
"adjustedTimeRange": {
"start": "00:00:46.9600000",
"end": "00:00:54.2200000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:00:46.9600000",
"end": "00:00:49.6600000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:00:51.2500000",
"end": "00:00:54.2200000"
}
}]
}],
"scenes": [{
"id": 1,
"timeRange": {
"start": "00:00:46.9600000",
"end": "00:00:54.2200000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "5c6fd721-c691-4727-8ee7-cbb79ed0bc64",
"shots": [{
"id": 2,
"timeRange": {
"start": "00:00:46.9600000",
"end": "00:00:54.2200000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "02794dc8-3c49-4eba-be9d-f8229eccf9cd"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:00:49.1330000",
"end": "00:00:54.2200000"
}],
"adjustedTimeRanges": [{
"start": "00:00:49.1330000",
"end": "00:00:54.2200000"
}]
}]
}, {
"id": 7,
"lines": [{
"id": 17,
"timeRange": {
"start": "00:00:54.2200000",
"end": "00:00:57.0700000"
},
"adjustedTimeRange": {
"start": "00:00:54.2200000",
"end": "00:00:57.0700000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "986426a4-1a05-452e-b9d7-2810399841f7",
"ranges": [{
"timeRange": {
"start": "00:00:54.2200000",
"end": "00:00:57.0700000"
},
"adjustedTimeRange": {
"start": "00:00:54.2200000",
"end": "00:00:57.0700000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:00:54.2200000",
"end": "00:00:54.2200000"
}
}]
}],
"scenes": [{
"id": 1,
"timeRange": {
"start": "00:00:54.2200000",
"end": "00:00:57.0700000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "5c6fd721-c691-4727-8ee7-cbb79ed0bc64",
"shots": [{
"id": 2,
"timeRange": {
"start": "00:00:54.2200000",
"end": "00:00:57.0700000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "02794dc8-3c49-4eba-be9d-f8229eccf9cd"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:00:54.2200000",
"end": "00:00:57.0700000"
}],
"adjustedTimeRanges": [{
"start": "00:00:54.2200000",
"end": "00:00:57.0700000"
}]
}]
}, {
"id": 8,
"lines": [{
"id": 18,
"timeRange": {
"start": "00:00:57.0700000",
"end": "00:01:02.7100000"
},
"adjustedTimeRange": {
"start": "00:00:57.0700000",
"end": "00:01:02.7100000"
},
"participantId": 2,
"text": "And I really have to leave then we save me.",
"isIncluded": true,
"confidence": 0.8109
}, {
"id": 19,
"timeRange": {
"start": "00:01:02.7100000",
"end": "00:01:05.1000000"
},
"adjustedTimeRange": {
"start": "00:01:02.7100000",
"end": "00:01:05.1000000"
},
"participantId": 2,
"text": "Well I mean or the phone number.",
"isIncluded": true,
"confidence": 0.62332477142857134
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0619002581,
"faces": [{
"id": 19617,
"thumbnailId": "9fa8429e-4110-40c3-b475-61a1c0f4db37",
"ranges": [{
"timeRange": {
"start": "00:00:57.0700000",
"end": "00:01:05.1000000"
},
"adjustedTimeRange": {
"start": "00:00:57.0700000",
"end": "00:01:05.1000000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:00:57.0700000",
"end": "00:01:00.8900000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:01:02.7100000",
"end": "00:01:05.1000000"
}
}]
}],
"scenes": [{
"id": 1,
"timeRange": {
"start": "00:00:57.0700000",
"end": "00:01:03.5660000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "5c6fd721-c691-4727-8ee7-cbb79ed0bc64",
"shots": [{
"id": 2,
"timeRange": {
"start": "00:00:57.0700000",
"end": "00:01:03.5660000"
},
"keyFrame": "00:00:48",
"keyFrameThumbnailId": "02794dc8-3c49-4eba-be9d-f8229eccf9cd"
}]
}, {
"id": 2,
"timeRange": {
"start": "00:01:03.5660000",
"end": "00:01:05.1000000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:03.5660000",
"end": "00:01:05.1000000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:00:57.0700000",
"end": "00:01:04.0660000"
}],
"adjustedTimeRanges": [{
"start": "00:00:57.0700000",
"end": "00:01:04.0660000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:01:01.9330000",
"end": "00:01:03"
}],
"adjustedTimeRanges": [{
"start": "00:01:01.9330000",
"end": "00:01:03"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:00:59.7990000",
"end": "00:01:00.8660000"
}],
"adjustedTimeRanges": [{
"start": "00:00:59.7990000",
"end": "00:01:00.8660000"
}]
}, {
"id": 8,
"name": "woman",
"timeRanges": [{
"start": "00:01:00.8660000",
"end": "00:01:03"
}],
"adjustedTimeRanges": [{
"start": "00:01:00.8660000",
"end": "00:01:03"
}]
}]
}, {
"id": 9,
"lines": [{
"id": 20,
"timeRange": {
"start": "00:01:05.1000000",
"end": "00:01:07.7600000"
},
"adjustedTimeRange": {
"start": "00:01:05.1000000",
"end": "00:01:07.7600000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "c056c4cf-171d-4a53-b53e-a8464b12d837",
"ranges": [{
"timeRange": {
"start": "00:01:05.1000000",
"end": "00:01:07.7600000"
},
"adjustedTimeRange": {
"start": "00:01:05.1000000",
"end": "00:01:07.7600000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:05.1000000",
"end": "00:01:05.1000000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:05.1000000",
"end": "00:01:07.7600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:05.1000000",
"end": "00:01:07.7600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:07.2660000",
"end": "00:01:07.7600000"
}],
"adjustedTimeRanges": [{
"start": "00:01:07.2660000",
"end": "00:01:07.7600000"
}]
}, {
"id": 9,
"name": "clothing",
"timeRanges": [{
"start": "00:01:07.2660000",
"end": "00:01:07.7600000"
}],
"adjustedTimeRanges": [{
"start": "00:01:07.2660000",
"end": "00:01:07.7600000"
}]
}]
}, {
"id": 10,
"lines": [{
"id": 21,
"timeRange": {
"start": "00:01:07.7600000",
"end": "00:01:11.6200000"
},
"adjustedTimeRange": {
"start": "00:01:07.7600000",
"end": "00:01:11.6200000"
},
"participantId": 2,
"text": "Then they were elected Warriors game then we stayed he H.",
"isIncluded": true,
"confidence": 0.77381818181818185
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.5,
"faces": [{
"id": 19617,
"thumbnailId": "c363ec31-55d7-4e50-b40f-8f091113f762",
"ranges": [{
"timeRange": {
"start": "00:01:07.7600000",
"end": "00:01:11.6200000"
},
"adjustedTimeRange": {
"start": "00:01:07.7600000",
"end": "00:01:11.6200000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:07.7600000",
"end": "00:01:11.6200000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:07.7600000",
"end": "00:01:11.6200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:07.7600000",
"end": "00:01:11.6200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:07.7600000",
"end": "00:01:11.6200000"
}],
"adjustedTimeRanges": [{
"start": "00:01:07.7600000",
"end": "00:01:11.6200000"
}]
}, {
"id": 9,
"name": "clothing",
"timeRanges": [{
"start": "00:01:07.7600000",
"end": "00:01:08.3330000"
}],
"adjustedTimeRanges": [{
"start": "00:01:07.7600000",
"end": "00:01:08.3330000"
}]
}]
}, {
"id": 11,
"lines": [{
"id": 22,
"timeRange": {
"start": "00:01:11.6200000",
"end": "00:01:15.0200000"
},
"adjustedTimeRange": {
"start": "00:01:11.6200000",
"end": "00:01:15.0200000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "444692ac-53a2-4ec4-90bf-d0e32ea4425f",
"ranges": [{
"timeRange": {
"start": "00:01:11.6200000",
"end": "00:01:15.0200000"
},
"adjustedTimeRange": {
"start": "00:01:11.6200000",
"end": "00:01:15.0200000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:11.6200000",
"end": "00:01:11.6200000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:11.6200000",
"end": "00:01:15.0200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:11.6200000",
"end": "00:01:15.0200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:11.6200000",
"end": "00:01:15.0200000"
}],
"adjustedTimeRanges": [{
"start": "00:01:11.6200000",
"end": "00:01:15.0200000"
}]
}, {
"id": 10,
"name": "outdoor",
"timeRanges": [{
"start": "00:01:14.7330000",
"end": "00:01:15.0200000"
}],
"adjustedTimeRanges": [{
"start": "00:01:14.7330000",
"end": "00:01:15.0200000"
}]
}]
}, {
"id": 12,
"lines": [{
"id": 23,
"timeRange": {
"start": "00:01:15.0200000",
"end": "00:01:15.8900000"
},
"adjustedTimeRange": {
"start": "00:01:15.0200000",
"end": "00:01:15.8900000"
},
"participantId": 4,
"text": "Yeah yea.",
"isIncluded": true,
"confidence": 0.26343275
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.821058631,
"faces": [{
"id": 19617,
"thumbnailId": "8bdce31e-5035-415b-a83d-e1a32d00cec0",
"ranges": [{
"timeRange": {
"start": "00:01:15.0200000",
"end": "00:01:15.8900000"
},
"adjustedTimeRange": {
"start": "00:01:15.0200000",
"end": "00:01:15.8900000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:15.0200000",
"end": "00:01:15.8900000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:15.0200000",
"end": "00:01:15.8900000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:15.0200000",
"end": "00:01:15.8900000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:15.0200000",
"end": "00:01:15.8900000"
}],
"adjustedTimeRanges": [{
"start": "00:01:15.0200000",
"end": "00:01:15.8900000"
}]
}, {
"id": 10,
"name": "outdoor",
"timeRanges": [{
"start": "00:01:15.0200000",
"end": "00:01:15.8000000"
}],
"adjustedTimeRanges": [{
"start": "00:01:15.0200000",
"end": "00:01:15.8000000"
}]
}]
}, {
"id": 13,
"lines": [{
"id": 24,
"timeRange": {
"start": "00:01:15.8900000",
"end": "00:01:18.8600000"
},
"adjustedTimeRange": {
"start": "00:01:15.8900000",
"end": "00:01:18.8600000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "6415eab4-2a52-4132-b9d0-214367b42fcd",
"ranges": [{
"timeRange": {
"start": "00:01:15.8900000",
"end": "00:01:18.8600000"
},
"adjustedTimeRange": {
"start": "00:01:15.8900000",
"end": "00:01:18.8600000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:15.8900000",
"end": "00:01:15.8900000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:15.8900000",
"end": "00:01:18.8600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:15.8900000",
"end": "00:01:18.8600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:15.8900000",
"end": "00:01:18.8600000"
}],
"adjustedTimeRanges": [{
"start": "00:01:15.8900000",
"end": "00:01:18.8600000"
}]
}]
}, {
"id": 14,
"lines": [{
"id": 25,
"timeRange": {
"start": "00:01:18.8600000",
"end": "00:01:19.2600000"
},
"adjustedTimeRange": {
"start": "00:01:18.8600000",
"end": "00:01:19.2600000"
},
"participantId": 3,
"text": "Coming my",
"isIncluded": true,
"confidence": 0.65
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.9062793,
"faces": [{
"id": 19617,
"thumbnailId": "88c87849-c5b1-485a-a7e2-bc7abdc1f292",
"ranges": [{
"timeRange": {
"start": "00:01:18.8600000",
"end": "00:01:19.2600000"
},
"adjustedTimeRange": {
"start": "00:01:18.8600000",
"end": "00:01:19.2600000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:18.8600000",
"end": "00:01:19.2600000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:18.8600000",
"end": "00:01:19.2600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:18.8600000",
"end": "00:01:19.2600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:18.8600000",
"end": "00:01:19.2600000"
}],
"adjustedTimeRanges": [{
"start": "00:01:18.8600000",
"end": "00:01:19.2600000"
}]
}]
}, {
"id": 15,
"lines": [{
"id": 26,
"timeRange": {
"start": "00:01:19.2600000",
"end": "00:01:20.0700000"
},
"adjustedTimeRange": {
"start": "00:01:19.2600000",
"end": "00:01:20.0700000"
},
"participantId": 2,
"text": "name Dave",
"isIncluded": true,
"confidence": 0.59355445
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.880262136,
"faces": [{
"id": 19617,
"thumbnailId": "427dadbc-17a4-46e7-85aa-f98221dedd7d",
"ranges": [{
"timeRange": {
"start": "00:01:19.2600000",
"end": "00:01:20.0700000"
},
"adjustedTimeRange": {
"start": "00:01:19.2600000",
"end": "00:01:20.0700000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:19.2600000",
"end": "00:01:20.0700000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:19.2600000",
"end": "00:01:20.0700000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:19.2600000",
"end": "00:01:20.0700000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:19.2600000",
"end": "00:01:20.0700000"
}],
"adjustedTimeRanges": [{
"start": "00:01:19.2600000",
"end": "00:01:20.0700000"
}]
}]
}, {
"id": 16,
"lines": [{
"id": 27,
"timeRange": {
"start": "00:01:20.0700000",
"end": "00:01:22.7200000"
},
"adjustedTimeRange": {
"start": "00:01:20.0700000",
"end": "00:01:22.7200000"
},
"participantId": 4,
"text": "other Hey buttercup buttercup.",
"isIncluded": true,
"confidence": 0.829
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.891067445,
"faces": [{
"id": 19617,
"thumbnailId": "08c0eae9-9645-461a-a6af-fe1a8f5b0a25",
"ranges": [{
"timeRange": {
"start": "00:01:20.0700000",
"end": "00:01:22.7200000"
},
"adjustedTimeRange": {
"start": "00:01:20.0700000",
"end": "00:01:22.7200000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:20.0700000",
"end": "00:01:22.7200000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:20.0700000",
"end": "00:01:22.7200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:20.0700000",
"end": "00:01:22.7200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:20.0700000",
"end": "00:01:22.2000000"
}],
"adjustedTimeRanges": [{
"start": "00:01:20.0700000",
"end": "00:01:22.2000000"
}]
}]
}, {
"id": 17,
"lines": [{
"id": 28,
"timeRange": {
"start": "00:01:22.7200000",
"end": "00:01:46.8400000"
},
"adjustedTimeRange": {
"start": "00:01:22.7200000",
"end": "00:01:46.8400000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "b827e71f-f363-4369-91f7-163f9cb7d3c8",
"ranges": [{
"timeRange": {
"start": "00:01:22.7200000",
"end": "00:01:38.6330000"
},
"adjustedTimeRange": {
"start": "00:01:22.7200000",
"end": "00:01:38.6330000"
}
}, {
"timeRange": {
"start": "00:01:44.6330000",
"end": "00:01:46.8400000"
},
"adjustedTimeRange": {
"start": "00:01:44.6330000",
"end": "00:01:46.8400000"
}
}]
}, {
"id": 4663,
"thumbnailId": "1c0d4b79-688f-4b80-b99e-43d2e991e92e",
"ranges": [{
"timeRange": {
"start": "00:01:42.6990000",
"end": "00:01:46.8400000"
},
"adjustedTimeRange": {
"start": "00:01:42.6990000",
"end": "00:01:46.8400000"
}
}]
}, {
"id": 4442,
"thumbnailId": "860ba854-0756-469d-9eec-f61e05f3959b",
"ranges": [{
"timeRange": {
"start": "00:01:31.6660000",
"end": "00:01:36.8660000"
},
"adjustedTimeRange": {
"start": "00:01:31.6660000",
"end": "00:01:36.8660000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:22.7200000",
"end": "00:01:22.7200000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:22.7200000",
"end": "00:01:46.8400000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:22.7200000",
"end": "00:01:46.8400000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:23.2660000",
"end": "00:01:26.4660000"
}, {
"start": "00:01:33.9330000",
"end": "00:01:37.1330000"
}, {
"start": "00:01:38.1990000",
"end": "00:01:40.3330000"
}, {
"start": "00:01:41.3990000",
"end": "00:01:46.8400000"
}],
"adjustedTimeRanges": [{
"start": "00:01:23.2660000",
"end": "00:01:26.4660000"
}, {
"start": "00:01:33.9330000",
"end": "00:01:37.1330000"
}, {
"start": "00:01:38.1990000",
"end": "00:01:40.3330000"
}, {
"start": "00:01:41.3990000",
"end": "00:01:46.8400000"
}]
}, {
"id": 8,
"name": "woman",
"timeRanges": [{
"start": "00:01:33.9330000",
"end": "00:01:37.1330000"
}],
"adjustedTimeRanges": [{
"start": "00:01:33.9330000",
"end": "00:01:37.1330000"
}]
}, {
"id": 9,
"name": "clothing",
"timeRanges": [{
"start": "00:01:23.2660000",
"end": "00:01:26.4660000"
}],
"adjustedTimeRanges": [{
"start": "00:01:23.2660000",
"end": "00:01:26.4660000"
}]
}, {
"id": 10,
"name": "outdoor",
"timeRanges": [{
"start": "00:01:33.9330000",
"end": "00:01:37.1330000"
}],
"adjustedTimeRanges": [{
"start": "00:01:33.9330000",
"end": "00:01:37.1330000"
}]
}]
}, {
"id": 18,
"lines": [{
"id": 29,
"timeRange": {
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
},
"adjustedTimeRange": {
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
},
"participantId": 1,
"text": "but",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.7528944,
"faces": [{
"id": 19617,
"thumbnailId": "126312cd-b19a-4c8d-aaa2-0ff9aa2311b7",
"ranges": [{
"timeRange": {
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
},
"adjustedTimeRange": {
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
}
}]
}, {
"id": 4663,
"thumbnailId": "1c0d4b79-688f-4b80-b99e-43d2e991e92e",
"ranges": [{
"timeRange": {
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
},
"adjustedTimeRange": {
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
}],
"adjustedTimeRanges": [{
"start": "00:01:46.8400000",
"end": "00:01:47.6200000"
}]
}]
}, {
"id": 19,
"lines": [{
"id": 30,
"timeRange": {
"start": "00:01:47.6200000",
"end": "00:01:53.1500000"
},
"adjustedTimeRange": {
"start": "00:01:47.6200000",
"end": "00:01:53.1500000"
},
"participantId": 2,
"text": "will be easy being given me any better tell you that he has been sold another girl.",
"isIncluded": true,
"confidence": 0.7202683470588237
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.864084363,
"faces": [{
"id": 19617,
"thumbnailId": "147f00aa-5dfb-46e0-a9d1-70f4aebc3f48",
"ranges": [{
"timeRange": {
"start": "00:01:47.6200000",
"end": "00:01:53.1500000"
},
"adjustedTimeRange": {
"start": "00:01:47.6200000",
"end": "00:01:53.1500000"
}
}]
}, {
"id": 4663,
"thumbnailId": "e59de4e6-93a0-4363-8cbe-88102f9730e7",
"ranges": [{
"timeRange": {
"start": "00:01:47.6200000",
"end": "00:01:49.6990000"
},
"adjustedTimeRange": {
"start": "00:01:47.6200000",
"end": "00:01:49.6990000"
}
}]
}, {
"id": 4442,
"thumbnailId": "7fb61288-c31c-4031-9b44-4229ab707128",
"ranges": [{
"timeRange": {
"start": "00:01:50.1990000",
"end": "00:01:53.1500000"
},
"adjustedTimeRange": {
"start": "00:01:50.1990000",
"end": "00:01:53.1500000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:47.6200000",
"end": "00:01:53.1500000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:47.6200000",
"end": "00:01:53.1500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:47.6200000",
"end": "00:01:53.1500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:47.6200000",
"end": "00:01:53.1500000"
}],
"adjustedTimeRanges": [{
"start": "00:01:47.6200000",
"end": "00:01:53.1500000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:01:47.7990000",
"end": "00:01:48.8660000"
}],
"adjustedTimeRanges": [{
"start": "00:01:47.7990000",
"end": "00:01:48.8660000"
}]
}, {
"id": 10,
"name": "outdoor",
"timeRanges": [{
"start": "00:01:48.8660000",
"end": "00:01:53.1330000"
}],
"adjustedTimeRanges": [{
"start": "00:01:48.8660000",
"end": "00:01:53.1330000"
}]
}]
}, {
"id": 20,
"lines": [{
"id": 31,
"timeRange": {
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
},
"adjustedTimeRange": {
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "3ebd1e03-913e-4393-861d-d4db14c51325",
"ranges": [{
"timeRange": {
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
},
"adjustedTimeRange": {
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
}
}]
}, {
"id": 5321,
"thumbnailId": "a540dff4-3de4-49c5-bd7e-4a09899f4869",
"ranges": [{
"timeRange": {
"start": "00:01:54.2660000",
"end": "00:01:55.3100000"
},
"adjustedTimeRange": {
"start": "00:01:54.2660000",
"end": "00:01:55.3100000"
}
}]
}, {
"id": 5312,
"thumbnailId": "579f032c-faf1-4a09-93c4-c37fd8928af8",
"ranges": [{
"timeRange": {
"start": "00:01:54.0990000",
"end": "00:01:55.3100000"
},
"adjustedTimeRange": {
"start": "00:01:54.0990000",
"end": "00:01:55.3100000"
}
}]
}, {
"id": 4442,
"thumbnailId": "c7bebad7-d56f-402a-8bd3-0d6249edb6a7",
"ranges": [{
"timeRange": {
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
},
"adjustedTimeRange": {
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:53.1500000",
"end": "00:01:53.1500000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
}],
"adjustedTimeRanges": [{
"start": "00:01:53.1500000",
"end": "00:01:55.3100000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:01:54.1990000",
"end": "00:01:55.2660000"
}],
"adjustedTimeRanges": [{
"start": "00:01:54.1990000",
"end": "00:01:55.2660000"
}]
}]
}, {
"id": 21,
"lines": [{
"id": 32,
"timeRange": {
"start": "00:01:55.3100000",
"end": "00:01:55.7000000"
},
"adjustedTimeRange": {
"start": "00:01:55.3100000",
"end": "00:01:55.7000000"
},
"participantId": 2,
"text": "Please make",
"isIncluded": true,
"confidence": 0.75
}, {
"id": 33,
"timeRange": {
"start": "00:01:55.7000000",
"end": "00:02:02.2000000"
},
"adjustedTimeRange": {
"start": "00:01:55.7000000",
"end": "00:02:02.2000000"
},
"participantId": 2,
"text": "300 total maligore school several months don't know you don't blood and I'm going.",
"isIncluded": true,
"confidence": 0.81169087857142852
}, {
"id": 34,
"timeRange": {
"start": "00:02:02.2000000",
"end": "00:02:06.6700000"
},
"adjustedTimeRange": {
"start": "00:02:02.2000000",
"end": "00:02:06.6700000"
},
"participantId": 2,
"text": "The evil don't be In the easy.",
"isIncluded": true,
"confidence": 0.78051147142857147
}, {
"id": 35,
"timeRange": {
"start": "00:02:06.6700000",
"end": "00:02:09.4700000"
},
"adjustedTimeRange": {
"start": "00:02:06.6700000",
"end": "00:02:09.4700000"
},
"participantId": 2,
"text": "mood for you leave they didn't order and I'm very.",
"isIncluded": true,
"confidence": 0.73903420999999991
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0996170342,
"faces": [{
"id": 19617,
"thumbnailId": "2b0668e1-7a55-4198-96c5-6c0290b94a92",
"ranges": [{
"timeRange": {
"start": "00:01:55.3100000",
"end": "00:02:09.4700000"
},
"adjustedTimeRange": {
"start": "00:01:55.3100000",
"end": "00:02:09.4700000"
}
}]
}, {
"id": 5321,
"thumbnailId": "2837045a-e0e3-4842-9ace-4165dbfb4869",
"ranges": [{
"timeRange": {
"start": "00:01:55.3100000",
"end": "00:02:00.7330000"
},
"adjustedTimeRange": {
"start": "00:01:55.3100000",
"end": "00:02:00.7330000"
}
}]
}, {
"id": 5312,
"thumbnailId": "ef6ef345-0601-43e8-a599-8d4169d55d07",
"ranges": [{
"timeRange": {
"start": "00:01:55.3100000",
"end": "00:02:00.6990000"
},
"adjustedTimeRange": {
"start": "00:01:55.3100000",
"end": "00:02:00.6990000"
}
}]
}, {
"id": 6186,
"thumbnailId": "205b99f7-9eb6-4872-a57f-e516423d2f6e",
"ranges": [{
"timeRange": {
"start": "00:02:08.7990000",
"end": "00:02:09.4700000"
},
"adjustedTimeRange": {
"start": "00:02:08.7990000",
"end": "00:02:09.4700000"
}
}]
}, {
"id": 5733,
"thumbnailId": "a7502449-2427-4d13-a4fa-cfe7073030ea",
"ranges": [{
"timeRange": {
"start": "00:02:01.2330000",
"end": "00:02:09.4700000"
},
"adjustedTimeRange": {
"start": "00:02:01.2330000",
"end": "00:02:09.4700000"
}
}]
}, {
"id": 4442,
"thumbnailId": "51a6d63c-6355-41c7-9d87-f611c7c331df",
"ranges": [{
"timeRange": {
"start": "00:01:55.3100000",
"end": "00:02:02.8990000"
},
"adjustedTimeRange": {
"start": "00:01:55.3100000",
"end": "00:02:02.8990000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:01:55.3100000",
"end": "00:02:09.4700000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:01:55.3100000",
"end": "00:02:09.4700000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:01:55.3100000",
"end": "00:02:09.4700000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:01:55.3100000",
"end": "00:02:09.4700000"
}],
"adjustedTimeRanges": [{
"start": "00:01:55.3100000",
"end": "00:02:09.4700000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:01:56.3330000",
"end": "00:01:59.5330000"
}, {
"start": "00:02:08.0660000",
"end": "00:02:09.4700000"
}],
"adjustedTimeRanges": [{
"start": "00:01:56.3330000",
"end": "00:01:59.5330000"
}, {
"start": "00:02:08.0660000",
"end": "00:02:09.4700000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:01:56.3330000",
"end": "00:01:59.5330000"
}, {
"start": "00:02:08.0660000",
"end": "00:02:09.4700000"
}],
"adjustedTimeRanges": [{
"start": "00:01:56.3330000",
"end": "00:01:59.5330000"
}, {
"start": "00:02:08.0660000",
"end": "00:02:09.4700000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:02:03.7990000",
"end": "00:02:07"
}],
"adjustedTimeRanges": [{
"start": "00:02:03.7990000",
"end": "00:02:07"
}]
}, {
"id": 8,
"name": "woman",
"timeRanges": [{
"start": "00:02:02.7330000",
"end": "00:02:03.8000000"
}],
"adjustedTimeRanges": [{
"start": "00:02:02.7330000",
"end": "00:02:03.8000000"
}]
}, {
"id": 10,
"name": "outdoor",
"timeRanges": [{
"start": "00:02:00.5990000",
"end": "00:02:03.8000000"
}, {
"start": "00:02:08.0660000",
"end": "00:02:09.4700000"
}],
"adjustedTimeRanges": [{
"start": "00:02:00.5990000",
"end": "00:02:03.8000000"
}, {
"start": "00:02:08.0660000",
"end": "00:02:09.4700000"
}]
}, {
"id": 11,
"name": "tree",
"timeRanges": [{
"start": "00:02:08.0660000",
"end": "00:02:09.4700000"
}],
"adjustedTimeRanges": [{
"start": "00:02:08.0660000",
"end": "00:02:09.4700000"
}]
}]
}, {
"id": 22,
"lines": [{
"id": 36,
"timeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
},
"adjustedTimeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "fea7e308-f02d-479b-8204-e1330c1656b0",
"ranges": [{
"timeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
},
"adjustedTimeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
}
}]
}, {
"id": 6186,
"thumbnailId": "76b04416-0a27-4eb6-8765-21c46e19f578",
"ranges": [{
"timeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
},
"adjustedTimeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
}
}]
}, {
"id": 5733,
"thumbnailId": "c3342326-d82d-43b7-832e-944cdb4eb354",
"ranges": [{
"timeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
},
"adjustedTimeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:02:09.4700000",
"end": "00:02:09.4700000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
}],
"adjustedTimeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:12.1500000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:10.2000000"
}, {
"start": "00:02:11.2660000",
"end": "00:02:12.1500000"
}],
"adjustedTimeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:10.2000000"
}, {
"start": "00:02:11.2660000",
"end": "00:02:12.1500000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:11.2660000"
}],
"adjustedTimeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:11.2660000"
}]
}, {
"id": 10,
"name": "outdoor",
"timeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:11.2660000"
}],
"adjustedTimeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:11.2660000"
}]
}, {
"id": 11,
"name": "tree",
"timeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:11.2660000"
}],
"adjustedTimeRanges": [{
"start": "00:02:09.4700000",
"end": "00:02:11.2660000"
}]
}, {
"id": 12,
"name": "white",
"timeRanges": [{
"start": "00:02:11.2660000",
"end": "00:02:12.1500000"
}],
"adjustedTimeRanges": [{
"start": "00:02:11.2660000",
"end": "00:02:12.1500000"
}]
}]
}, {
"id": 23,
"lines": [{
"id": 37,
"timeRange": {
"start": "00:02:12.1500000",
"end": "00:02:20.6700000"
},
"adjustedTimeRange": {
"start": "00:02:12.1500000",
"end": "00:02:20.6700000"
},
"participantId": 2,
"text": "Full big clivar trouble Molly goes heukelom bahuguna you don't bluhdorn angry.",
"isIncluded": true,
"confidence": 0.85796593333333337
}, {
"id": 38,
"timeRange": {
"start": "00:02:20.6700000",
"end": "00:02:26.2900000"
},
"adjustedTimeRange": {
"start": "00:02:20.6700000",
"end": "00:02:26.2900000"
},
"participantId": 2,
"text": "One I'm not gonna want my God no.",
"isIncluded": true,
"confidence": 0.71025
}, {
"id": 39,
"timeRange": {
"start": "00:02:26.2900000",
"end": "00:02:29.9700000"
},
"adjustedTimeRange": {
"start": "00:02:26.2900000",
"end": "00:02:29.9700000"
},
"participantId": 2,
"text": "Bhumis my roommate 4.",
"isIncluded": true,
"confidence": 0.65025
}, {
"id": 40,
"timeRange": {
"start": "00:02:29.9700000",
"end": "00:02:43.8900000"
},
"adjustedTimeRange": {
"start": "00:02:29.9700000",
"end": "00:02:43.8900000"
},
"participantId": 2,
"text": "010 my God will never forget I owe me mother you will make or did he not have some coffee and I gave arsina mongolie to mongaup even 38.",
"isIncluded": true,
"confidence": 0.85122857586206879
}, {
"id": 41,
"timeRange": {
"start": "00:02:43.8900000",
"end": "00:02:52.3500000"
},
"adjustedTimeRange": {
"start": "00:02:43.8900000",
"end": "00:02:52.3500000"
},
"participantId": 2,
"text": "I'll be an all you have you are again I'm I'm gonna get along gonna be easy to mangala he wondered how",
"isIncluded": true,
"confidence": 0.88672727272727281
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.1518093,
"faces": [{
"id": 19617,
"thumbnailId": "9e5a4ade-b895-41ea-8c01-7af0079f1549",
"ranges": [{
"timeRange": {
"start": "00:02:12.1500000",
"end": "00:02:12.3330000"
},
"adjustedTimeRange": {
"start": "00:02:12.1500000",
"end": "00:02:12.3330000"
}
}, {
"timeRange": {
"start": "00:02:12.8660000",
"end": "00:02:23.6330000"
},
"adjustedTimeRange": {
"start": "00:02:12.8660000",
"end": "00:02:23.6330000"
}
}, {
"timeRange": {
"start": "00:02:28.0990000",
"end": "00:02:38.5330000"
},
"adjustedTimeRange": {
"start": "00:02:28.0990000",
"end": "00:02:38.5330000"
}
}, {
"timeRange": {
"start": "00:02:42.6990000",
"end": "00:02:52.0660000"
},
"adjustedTimeRange": {
"start": "00:02:42.6990000",
"end": "00:02:52.0660000"
}
}]
}, {
"id": 6758,
"thumbnailId": "3da6d77e-6ca6-4706-9e42-444a3ffe796e",
"ranges": [{
"timeRange": {
"start": "00:02:20.9330000",
"end": "00:02:27.3990000"
},
"adjustedTimeRange": {
"start": "00:02:20.9330000",
"end": "00:02:27.3990000"
}
}]
}, {
"id": 7229,
"thumbnailId": "bf41907d-c72b-4fcd-a6fb-d8f112c6459b",
"ranges": [{
"timeRange": {
"start": "00:02:27.4660000",
"end": "00:02:38.4330000"
},
"adjustedTimeRange": {
"start": "00:02:27.4660000",
"end": "00:02:38.4330000"
}
}]
}, {
"id": 7224,
"thumbnailId": "f5d5d843-e7cb-48a9-ae07-5c4dd2797601",
"ranges": [{
"timeRange": {
"start": "00:02:27.7330000",
"end": "00:02:38.0330000"
},
"adjustedTimeRange": {
"start": "00:02:27.7330000",
"end": "00:02:38.0330000"
}
}]
}, {
"id": 10128,
"thumbnailId": "a4506e87-5f09-4609-b895-52f49203043b",
"ranges": [{
"timeRange": {
"start": "00:02:34.9330000",
"end": "00:02:44.8990000"
},
"adjustedTimeRange": {
"start": "00:02:34.9330000",
"end": "00:02:44.8990000"
}
}]
}, {
"id": 9068,
"thumbnailId": "816573ad-4541-4f0a-ac82-7e6bbcaca33f",
"ranges": [{
"timeRange": {
"start": "00:02:43.3990000",
"end": "00:02:48.2330000"
},
"adjustedTimeRange": {
"start": "00:02:43.3990000",
"end": "00:02:48.2330000"
}
}]
}, {
"id": 6186,
"thumbnailId": "9d316b44-7db0-4c7b-a3b7-8dfd6fc63dff",
"ranges": [{
"timeRange": {
"start": "00:02:12.1500000",
"end": "00:02:14.2660000"
},
"adjustedTimeRange": {
"start": "00:02:12.1500000",
"end": "00:02:14.2660000"
}
}]
}, {
"id": 8299,
"thumbnailId": "3b70c604-2ffc-4bf9-8096-fdbb1bcf4a5a",
"ranges": [{
"timeRange": {
"start": "00:02:34.9990000",
"end": "00:02:46.2330000"
},
"adjustedTimeRange": {
"start": "00:02:34.9990000",
"end": "00:02:46.2330000"
}
}]
}, {
"id": 6693,
"thumbnailId": "6fb5f412-9de3-49c6-93f6-61cad9043bea",
"ranges": [{
"timeRange": {
"start": "00:02:20.3660000",
"end": "00:02:27.3990000"
},
"adjustedTimeRange": {
"start": "00:02:20.3660000",
"end": "00:02:27.3990000"
}
}]
}, {
"id": 8213,
"thumbnailId": "28d83dc3-3637-4d1f-9cb6-25c55b634f09",
"ranges": [{
"timeRange": {
"start": "00:02:34.7330000",
"end": "00:02:44.8990000"
},
"adjustedTimeRange": {
"start": "00:02:34.7330000",
"end": "00:02:44.8990000"
}
}]
}, {
"id": 9881,
"thumbnailId": "3ef2d246-99b6-4868-b194-082bc2955f11",
"ranges": [{
"timeRange": {
"start": "00:02:51.3660000",
"end": "00:02:52.3500000"
},
"adjustedTimeRange": {
"start": "00:02:51.3660000",
"end": "00:02:52.3500000"
}
}]
}, {
"id": 6647,
"thumbnailId": "b3732958-e287-4d8d-8147-3478f33aa5f4",
"ranges": [{
"timeRange": {
"start": "00:02:20.0660000",
"end": "00:02:27.0990000"
},
"adjustedTimeRange": {
"start": "00:02:20.0660000",
"end": "00:02:27.0990000"
}
}]
}, {
"id": 5733,
"thumbnailId": "53f466c6-fec1-41a9-a749-7f92f98347cd",
"ranges": [{
"timeRange": {
"start": "00:02:12.1500000",
"end": "00:02:12.2660000"
},
"adjustedTimeRange": {
"start": "00:02:12.1500000",
"end": "00:02:12.2660000"
}
}, {
"timeRange": {
"start": "00:02:27.5660000",
"end": "00:02:38.3990000"
},
"adjustedTimeRange": {
"start": "00:02:27.5660000",
"end": "00:02:38.3990000"
}
}]
}, {
"id": 9114,
"thumbnailId": "6a83dd78-f856-4772-9281-30e62f08db7a",
"ranges": [{
"timeRange": {
"start": "00:02:18.4660000",
"end": "00:02:27.6330000"
},
"adjustedTimeRange": {
"start": "00:02:18.4660000",
"end": "00:02:27.6330000"
}
}, {
"timeRange": {
"start": "00:02:35.6660000",
"end": "00:02:39.1660000"
},
"adjustedTimeRange": {
"start": "00:02:35.6660000",
"end": "00:02:39.1660000"
}
}, {
"timeRange": {
"start": "00:02:43.0330000",
"end": "00:02:50.1330000"
},
"adjustedTimeRange": {
"start": "00:02:43.0330000",
"end": "00:02:50.1330000"
}
}]
}, {
"id": 9049,
"thumbnailId": "4c7f46a7-0eb7-4512-8344-c9c3ca0241bd",
"ranges": [{
"timeRange": {
"start": "00:02:34.8660000",
"end": "00:02:41.7330000"
},
"adjustedTimeRange": {
"start": "00:02:34.8660000",
"end": "00:02:41.7330000"
}
}, {
"timeRange": {
"start": "00:02:42.8990000",
"end": "00:02:46.2660000"
},
"adjustedTimeRange": {
"start": "00:02:42.8990000",
"end": "00:02:46.2660000"
}
}]
}, {
"id": 6663,
"thumbnailId": "d40806e9-92c5-4764-a2f9-27c6762f6f33",
"ranges": [{
"timeRange": {
"start": "00:02:20.1660000",
"end": "00:02:27.1990000"
},
"adjustedTimeRange": {
"start": "00:02:20.1660000",
"end": "00:02:27.1990000"
}
}]
}],
"ocrs": [{
"timeRange": {
"start": "00:02:24",
"end": "00:05:00"
},
"adjustedTimeRange": {
"start": "00:02:24",
"end": "00:02:52.3500000"
},
"lines": [{
"id": 11,
"width": 0,
"height": 0,
"language": "Italian",
"textData": "JayalalithaChildhÒod.blo@spot.com",
"confidence": 0.3675
}]
}],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:02:12.1500000",
"end": "00:02:18.7500000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:02:20.6700000",
"end": "00:02:24.3800000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:02:26.2900000",
"end": "00:02:28.2500000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:02:29.9700000",
"end": "00:02:42.1200000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:02:43.8900000",
"end": "00:02:52.3500000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:02:12.1500000",
"end": "00:02:52.3500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:02:12.1500000",
"end": "00:02:52.3500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:02:12.1500000",
"end": "00:02:14.4660000"
}, {
"start": "00:02:15.5330000",
"end": "00:02:23"
}, {
"start": "00:02:30.4660000",
"end": "00:02:36.8660000"
}, {
"start": "00:02:45.3990000",
"end": "00:02:52.3500000"
}],
"adjustedTimeRanges": [{
"start": "00:02:12.1500000",
"end": "00:02:14.4660000"
}, {
"start": "00:02:15.5330000",
"end": "00:02:23"
}, {
"start": "00:02:30.4660000",
"end": "00:02:36.8660000"
}, {
"start": "00:02:45.3990000",
"end": "00:02:52.3500000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:02:12.1500000",
"end": "00:02:14.4660000"
}, {
"start": "00:02:30.4660000",
"end": "00:02:36.8660000"
}, {
"start": "00:02:45.3990000",
"end": "00:02:48.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:02:12.1500000",
"end": "00:02:14.4660000"
}, {
"start": "00:02:30.4660000",
"end": "00:02:36.8660000"
}, {
"start": "00:02:45.3990000",
"end": "00:02:48.6000000"
}]
}, {
"id": 4,
"name": "group",
"timeRanges": [{
"start": "00:02:45.3990000",
"end": "00:02:48.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:02:45.3990000",
"end": "00:02:48.6000000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:02:30.4660000",
"end": "00:02:36.8660000"
}, {
"start": "00:02:51.7990000",
"end": "00:02:52.3500000"
}],
"adjustedTimeRanges": [{
"start": "00:02:30.4660000",
"end": "00:02:36.8660000"
}, {
"start": "00:02:51.7990000",
"end": "00:02:52.3500000"
}]
}, {
"id": 7,
"name": "wall",
"timeRanges": [{
"start": "00:02:45.3990000",
"end": "00:02:48.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:02:45.3990000",
"end": "00:02:48.6000000"
}]
}, {
"id": 12,
"name": "white",
"timeRanges": [{
"start": "00:02:12.1500000",
"end": "00:02:12.3330000"
}],
"adjustedTimeRanges": [{
"start": "00:02:12.1500000",
"end": "00:02:12.3330000"
}]
}, {
"id": 13,
"name": "bed",
"timeRanges": [{
"start": "00:02:25.1330000",
"end": "00:02:26.2000000"
}],
"adjustedTimeRanges": [{
"start": "00:02:25.1330000",
"end": "00:02:26.2000000"
}]
}, {
"id": 14,
"name": "people",
"timeRanges": [{
"start": "00:02:47.5330000",
"end": "00:02:48.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:02:47.5330000",
"end": "00:02:48.6000000"
}]
}, {
"id": 15,
"name": "man",
"timeRanges": [{
"start": "00:02:48.5990000",
"end": "00:02:51.8000000"
}],
"adjustedTimeRanges": [{
"start": "00:02:48.5990000",
"end": "00:02:51.8000000"
}]
}]
}, {
"id": 24,
"lines": [{
"id": 42,
"timeRange": {
"start": "00:02:52.3500000",
"end": "00:02:55.9500000"
},
"adjustedTimeRange": {
"start": "00:02:52.3500000",
"end": "00:02:55.9500000"
},
"participantId": 4,
"text": "you got thought I'd are you a boy did have fun.",
"isIncluded": true,
"confidence": 0.91727272727272724
}, {
"id": 43,
"timeRange": {
"start": "00:02:55.9500000",
"end": "00:03:00.1500000"
},
"adjustedTimeRange": {
"start": "00:02:55.9500000",
"end": "00:03:00.1500000"
},
"participantId": 4,
"text": "David am but it cover it.",
"isIncluded": true,
"confidence": 0.48229793333333332
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.9141783,
"faces": [{
"id": 10253,
"thumbnailId": "ad2fcb20-ea58-44c0-8a1f-0a7c4b483849",
"ranges": [{
"timeRange": {
"start": "00:02:57.8330000",
"end": "00:03:00.1500000"
},
"adjustedTimeRange": {
"start": "00:02:57.8330000",
"end": "00:03:00.1500000"
}
}]
}, {
"id": 10128,
"thumbnailId": "4105be48-7694-4711-ac27-6cc10e19dc33",
"ranges": [{
"timeRange": {
"start": "00:02:57.4660000",
"end": "00:03:00.1500000"
},
"adjustedTimeRange": {
"start": "00:02:57.4660000",
"end": "00:03:00.1500000"
}
}]
}, {
"id": 10108,
"thumbnailId": "9fd39de7-0f90-4ae6-95b3-8230485a40ed",
"ranges": [{
"timeRange": {
"start": "00:02:58.9990000",
"end": "00:03:00.1500000"
},
"adjustedTimeRange": {
"start": "00:02:58.9990000",
"end": "00:03:00.1500000"
}
}]
}, {
"id": 9881,
"thumbnailId": "a3932238-2a84-4ae2-9701-bb2bfcb35589",
"ranges": [{
"timeRange": {
"start": "00:02:52.3500000",
"end": "00:03:00.1500000"
},
"adjustedTimeRange": {
"start": "00:02:52.3500000",
"end": "00:03:00.1500000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:02:52.3500000",
"end": "00:03:00.1500000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:02:52.3500000",
"end": "00:03:00.1500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:02:52.3500000",
"end": "00:03:00.1500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:02:52.3500000",
"end": "00:03:00.1500000"
}],
"adjustedTimeRanges": [{
"start": "00:02:52.3500000",
"end": "00:03:00.1500000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:02:52.8660000",
"end": "00:02:59.2660000"
}],
"adjustedTimeRanges": [{
"start": "00:02:52.8660000",
"end": "00:02:59.2660000"
}]
}, {
"id": 4,
"name": "group",
"timeRanges": [{
"start": "00:02:59.2660000",
"end": "00:03:00.1500000"
}],
"adjustedTimeRanges": [{
"start": "00:02:59.2660000",
"end": "00:03:00.1500000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:02:52.3500000",
"end": "00:02:59.2660000"
}],
"adjustedTimeRanges": [{
"start": "00:02:52.3500000",
"end": "00:02:59.2660000"
}]
}, {
"id": 15,
"name": "man",
"timeRanges": [{
"start": "00:02:52.8660000",
"end": "00:02:59.2660000"
}],
"adjustedTimeRanges": [{
"start": "00:02:52.8660000",
"end": "00:02:59.2660000"
}]
}]
}, {
"id": 25,
"lines": [{
"id": 44,
"timeRange": {
"start": "00:03:00.1500000",
"end": "00:03:19.6300000"
},
"adjustedTimeRange": {
"start": "00:03:00.1500000",
"end": "00:03:19.6300000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "ce2de4ef-738b-4d95-9893-958594e08baa",
"ranges": [{
"timeRange": {
"start": "00:03:05.7990000",
"end": "00:03:08.9990000"
},
"adjustedTimeRange": {
"start": "00:03:05.7990000",
"end": "00:03:08.9990000"
}
}, {
"timeRange": {
"start": "00:03:08.9990000",
"end": "00:03:15.9330000"
},
"adjustedTimeRange": {
"start": "00:03:08.9990000",
"end": "00:03:15.9330000"
}
}]
}, {
"id": 10253,
"thumbnailId": "d66876e9-7dde-4c6b-bbed-1933d5200ae8",
"ranges": [{
"timeRange": {
"start": "00:03:00.1500000",
"end": "00:03:08.3660000"
},
"adjustedTimeRange": {
"start": "00:03:00.1500000",
"end": "00:03:08.3660000"
}
}]
}, {
"id": 10128,
"thumbnailId": "cebb4503-9d76-4fac-9ca7-38345bfbd65a",
"ranges": [{
"timeRange": {
"start": "00:03:00.1500000",
"end": "00:03:08.3990000"
},
"adjustedTimeRange": {
"start": "00:03:00.1500000",
"end": "00:03:08.3990000"
}
}]
}, {
"id": 10108,
"thumbnailId": "6043a254-cfe7-4551-bffc-bec28541f8c2",
"ranges": [{
"timeRange": {
"start": "00:03:00.1500000",
"end": "00:03:08.3990000"
},
"adjustedTimeRange": {
"start": "00:03:00.1500000",
"end": "00:03:08.3990000"
}
}]
}, {
"id": 9881,
"thumbnailId": "32c3cb06-1457-4530-8d60-834927ac340c",
"ranges": [{
"timeRange": {
"start": "00:03:00.1500000",
"end": "00:03:01.3330000"
},
"adjustedTimeRange": {
"start": "00:03:00.1500000",
"end": "00:03:01.3330000"
}
}]
}, {
"id": 9114,
"thumbnailId": "6a83dd78-f856-4772-9281-30e62f08db7a",
"ranges": [{
"timeRange": {
"start": "00:03:17.3990000",
"end": "00:03:19.6300000"
},
"adjustedTimeRange": {
"start": "00:03:17.3990000",
"end": "00:03:19.6300000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:00.1500000",
"end": "00:03:00.1500000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:00.1500000",
"end": "00:03:19.6300000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:00.1500000",
"end": "00:03:19.6300000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:00.1500000",
"end": "00:03:13.1330000"
}, {
"start": "00:03:14.1990000",
"end": "00:03:19.6300000"
}],
"adjustedTimeRanges": [{
"start": "00:03:00.1500000",
"end": "00:03:13.1330000"
}, {
"start": "00:03:14.1990000",
"end": "00:03:19.6300000"
}]
}, {
"id": 4,
"name": "group",
"timeRanges": [{
"start": "00:03:00.1500000",
"end": "00:03:00.3330000"
}, {
"start": "00:03:06.7330000",
"end": "00:03:07.8000000"
}],
"adjustedTimeRanges": [{
"start": "00:03:00.1500000",
"end": "00:03:00.3330000"
}, {
"start": "00:03:06.7330000",
"end": "00:03:07.8000000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:03:14.1990000",
"end": "00:03:19.5330000"
}],
"adjustedTimeRanges": [{
"start": "00:03:14.1990000",
"end": "00:03:19.5330000"
}]
}, {
"id": 8,
"name": "woman",
"timeRanges": [{
"start": "00:03:08.8660000",
"end": "00:03:11"
}],
"adjustedTimeRanges": [{
"start": "00:03:08.8660000",
"end": "00:03:11"
}]
}, {
"id": 14,
"name": "people",
"timeRanges": [{
"start": "00:03:06.7330000",
"end": "00:03:07.8000000"
}],
"adjustedTimeRanges": [{
"start": "00:03:06.7330000",
"end": "00:03:07.8000000"
}]
}]
}, {
"id": 26,
"lines": [{
"id": 45,
"timeRange": {
"start": "00:03:19.6300000",
"end": "00:03:24.4400000"
},
"adjustedTimeRange": {
"start": "00:03:19.6300000",
"end": "00:03:24.4400000"
},
"participantId": 2,
"text": "No learnable novom feed and I mean double nardon I'm good and evil.",
"isIncluded": true,
"confidence": 0.77624480000000007
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.236176938,
"faces": [{
"id": 9114,
"thumbnailId": "6a83dd78-f856-4772-9281-30e62f08db7a",
"ranges": [{
"timeRange": {
"start": "00:03:19.6300000",
"end": "00:03:22.7330000"
},
"adjustedTimeRange": {
"start": "00:03:19.6300000",
"end": "00:03:22.7330000"
}
}, {
"timeRange": {
"start": "00:03:23.6330000",
"end": "00:03:24.4400000"
},
"adjustedTimeRange": {
"start": "00:03:23.6330000",
"end": "00:03:24.4400000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:19.6300000",
"end": "00:03:24.4400000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:19.6300000",
"end": "00:03:24.4400000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:19.6300000",
"end": "00:03:24.4400000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:19.6300000",
"end": "00:03:21.6660000"
}, {
"start": "00:03:23.7990000",
"end": "00:03:24.4400000"
}],
"adjustedTimeRanges": [{
"start": "00:03:19.6300000",
"end": "00:03:21.6660000"
}, {
"start": "00:03:23.7990000",
"end": "00:03:24.4400000"
}]
}]
}, {
"id": 27,
"lines": [{
"id": 46,
"timeRange": {
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
},
"adjustedTimeRange": {
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 12225,
"thumbnailId": "104e0f18-3cfc-4d95-ac86-4f6230c06fa1",
"ranges": [{
"timeRange": {
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
},
"adjustedTimeRange": {
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
}
}]
}, {
"id": 9114,
"thumbnailId": "e3aa141b-4509-462d-bbeb-1fc2d08b59d3",
"ranges": [{
"timeRange": {
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
},
"adjustedTimeRange": {
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
}
}]
}, {
"id": 12197,
"thumbnailId": "79189eb8-8965-4440-8ace-9aadb38f3a7a",
"ranges": [{
"timeRange": {
"start": "00:03:24.5330000",
"end": "00:03:27.4300000"
},
"adjustedTimeRange": {
"start": "00:03:24.5330000",
"end": "00:03:27.4300000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:24.4400000",
"end": "00:03:24.4400000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
}],
"adjustedTimeRanges": [{
"start": "00:03:24.4400000",
"end": "00:03:27.4300000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}],
"adjustedTimeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}]
}, {
"id": 4,
"name": "group",
"timeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}],
"adjustedTimeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}],
"adjustedTimeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}]
}, {
"id": 7,
"name": "wall",
"timeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}],
"adjustedTimeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}]
}, {
"id": 16,
"name": "ceiling",
"timeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}],
"adjustedTimeRanges": [{
"start": "00:03:26.9990000",
"end": "00:03:27.4300000"
}]
}]
}, {
"id": 28,
"lines": [{
"id": 47,
"timeRange": {
"start": "00:03:27.4300000",
"end": "00:03:28.1900000"
},
"adjustedTimeRange": {
"start": "00:03:27.4300000",
"end": "00:03:28.1900000"
},
"participantId": 2,
"text": "Bloom",
"isIncluded": true,
"confidence": 0.5
}, {
"id": 48,
"timeRange": {
"start": "00:03:28.1900000",
"end": "00:03:34.0500000"
},
"adjustedTimeRange": {
"start": "00:03:28.1900000",
"end": "00:03:34.0500000"
},
"participantId": 2,
"text": "unecom myline wrapped up in the final 43105 or you could come",
"isIncluded": true,
"confidence": 0.82740489166666664
}, {
"id": 49,
"timeRange": {
"start": "00:03:34.0500000",
"end": "00:03:36.3300000"
},
"adjustedTimeRange": {
"start": "00:03:34.0500000",
"end": "00:03:36.3300000"
},
"participantId": 2,
"text": "on now",
"isIncluded": true,
"confidence": 1.0
}, {
"id": 50,
"timeRange": {
"start": "00:03:36.3300000",
"end": "00:03:40.3500000"
},
"adjustedTimeRange": {
"start": "00:03:36.3300000",
"end": "00:03:40.3500000"
},
"participantId": 2,
"text": "learn about that one PM 19 double mauroner long.",
"isIncluded": true,
"confidence": 0.94444444444444442
}, {
"id": 51,
"timeRange": {
"start": "00:03:40.3500000",
"end": "00:03:41.0600000"
},
"adjustedTimeRange": {
"start": "00:03:40.3500000",
"end": "00:03:41.0600000"
},
"participantId": 2,
"text": "Maybe but it.",
"isIncluded": true,
"confidence": 0.38966666666666666
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.818748,
"faces": [{
"id": 19617,
"thumbnailId": "cb7c8fb6-af0d-44cb-96da-0df7f37b9a64",
"ranges": [{
"timeRange": {
"start": "00:03:36.0330000",
"end": "00:03:40.8660000"
},
"adjustedTimeRange": {
"start": "00:03:36.0330000",
"end": "00:03:40.8660000"
}
}]
}, {
"id": 12225,
"thumbnailId": "fbdbca2c-c6ad-48d0-90ca-d22707b9fb52",
"ranges": [{
"timeRange": {
"start": "00:03:27.4300000",
"end": "00:03:30.0330000"
},
"adjustedTimeRange": {
"start": "00:03:27.4300000",
"end": "00:03:30.0330000"
}
}]
}, {
"id": 9114,
"thumbnailId": "b2ece1ba-4070-46a1-b769-883a1f966082",
"ranges": [{
"timeRange": {
"start": "00:03:27.4300000",
"end": "00:03:30.0330000"
},
"adjustedTimeRange": {
"start": "00:03:27.4300000",
"end": "00:03:30.0330000"
}
}]
}, {
"id": 12197,
"thumbnailId": "3f662022-954b-4969-91a5-cc45f8a06631",
"ranges": [{
"timeRange": {
"start": "00:03:27.4300000",
"end": "00:03:29.9990000"
},
"adjustedTimeRange": {
"start": "00:03:27.4300000",
"end": "00:03:29.9990000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:27.4300000",
"end": "00:03:41.0600000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:27.4300000",
"end": "00:03:41.0600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:27.4300000",
"end": "00:03:41.0600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:32.3330000"
}, {
"start": "00:03:33.3990000",
"end": "00:03:36.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:32.3330000"
}, {
"start": "00:03:33.3990000",
"end": "00:03:36.6000000"
}]
}, {
"id": 2,
"name": "holding",
"timeRanges": [{
"start": "00:03:34.4660000",
"end": "00:03:35.5330000"
}],
"adjustedTimeRanges": [{
"start": "00:03:34.4660000",
"end": "00:03:35.5330000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:29.1330000"
}],
"adjustedTimeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:29.1330000"
}]
}, {
"id": 4,
"name": "group",
"timeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:29.1330000"
}],
"adjustedTimeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:29.1330000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:03:30.1990000",
"end": "00:03:33.4000000"
}],
"adjustedTimeRanges": [{
"start": "00:03:30.1990000",
"end": "00:03:33.4000000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:28.0660000"
}],
"adjustedTimeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:28.0660000"
}]
}, {
"id": 7,
"name": "wall",
"timeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:29.1330000"
}],
"adjustedTimeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:29.1330000"
}]
}, {
"id": 15,
"name": "man",
"timeRanges": [{
"start": "00:03:30.1990000",
"end": "00:03:33.4000000"
}],
"adjustedTimeRanges": [{
"start": "00:03:30.1990000",
"end": "00:03:33.4000000"
}]
}, {
"id": 16,
"name": "ceiling",
"timeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:28.0660000"
}],
"adjustedTimeRanges": [{
"start": "00:03:27.4300000",
"end": "00:03:28.0660000"
}]
}]
}, {
"id": 29,
"lines": [{
"id": 52,
"timeRange": {
"start": "00:03:41.0600000",
"end": "00:03:44.1400000"
},
"adjustedTimeRange": {
"start": "00:03:41.0600000",
"end": "00:03:44.1400000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:41.0600000",
"end": "00:03:41.0600000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:41.0600000",
"end": "00:03:44.1400000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:41.0600000",
"end": "00:03:44.1400000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:41.9330000",
"end": "00:03:44.1400000"
}],
"adjustedTimeRanges": [{
"start": "00:03:41.9330000",
"end": "00:03:44.1400000"
}]
}]
}, {
"id": 30,
"lines": [{
"id": 53,
"timeRange": {
"start": "00:03:44.1400000",
"end": "00:03:45.2700000"
},
"adjustedTimeRange": {
"start": "00:03:44.1400000",
"end": "00:03:45.2700000"
},
"participantId": 2,
"text": "lyndra",
"isIncluded": true,
"confidence": 0.2
}, {
"id": 54,
"timeRange": {
"start": "00:03:45.2700000",
"end": "00:03:49.0300000"
},
"adjustedTimeRange": {
"start": "00:03:45.2700000",
"end": "00:03:49.0300000"
},
"participantId": 2,
"text": "tucked in Redmond airport 3100 thousand one.",
"isIncluded": true,
"confidence": 0.63572788571428573
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.5,
"faces": [{
"id": 13110,
"thumbnailId": "c2303334-c881-4039-b440-06a597501bf2",
"ranges": [{
"timeRange": {
"start": "00:03:46.3990000",
"end": "00:03:49.0300000"
},
"adjustedTimeRange": {
"start": "00:03:46.3990000",
"end": "00:03:49.0300000"
}
}]
}, {
"id": 9114,
"thumbnailId": "f88da407-f3df-4609-8aff-fb82d9011f38",
"ranges": [{
"timeRange": {
"start": "00:03:46.5330000",
"end": "00:03:49.0300000"
},
"adjustedTimeRange": {
"start": "00:03:46.5330000",
"end": "00:03:49.0300000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:44.1400000",
"end": "00:03:49.0300000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:44.1400000",
"end": "00:03:49.0300000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:44.1400000",
"end": "00:03:49.0300000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:44.1400000",
"end": "00:03:49.0300000"
}],
"adjustedTimeRanges": [{
"start": "00:03:44.1400000",
"end": "00:03:49.0300000"
}]
}]
}, {
"id": 31,
"lines": [{
"id": 55,
"timeRange": {
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
},
"adjustedTimeRange": {
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 13110,
"thumbnailId": "02a9cc24-d305-4a39-9d06-3657407e6f0c",
"ranges": [{
"timeRange": {
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
},
"adjustedTimeRange": {
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
}
}]
}, {
"id": 13391,
"thumbnailId": "2a9d15d2-d009-4adb-a61e-be4568804eae",
"ranges": [{
"timeRange": {
"start": "00:03:50.0330000",
"end": "00:03:52.5100000"
},
"adjustedTimeRange": {
"start": "00:03:50.0330000",
"end": "00:03:52.5100000"
}
}]
}, {
"id": 9114,
"thumbnailId": "34ae88f3-2c5b-48ca-964a-8bef64de4d53",
"ranges": [{
"timeRange": {
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
},
"adjustedTimeRange": {
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:49.0300000",
"end": "00:03:49.0300000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
}],
"adjustedTimeRanges": [{
"start": "00:03:49.0300000",
"end": "00:03:52.5100000"
}]
}, {
"id": 14,
"name": "people",
"timeRanges": [{
"start": "00:03:49.3990000",
"end": "00:03:51.5330000"
}],
"adjustedTimeRanges": [{
"start": "00:03:49.3990000",
"end": "00:03:51.5330000"
}]
}]
}, {
"id": 32,
"lines": [{
"id": 56,
"timeRange": {
"start": "00:03:52.5100000",
"end": "00:03:55.3800000"
},
"adjustedTimeRange": {
"start": "00:03:52.5100000",
"end": "00:03:55.3800000"
},
"participantId": 2,
"text": "Here they could be did go early vanilla.",
"isIncluded": true,
"confidence": 0.84525000000000006
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.7353393,
"faces": [{
"id": 13110,
"thumbnailId": "e8ebca3d-9203-48fe-86e2-cbb5d81f15b3",
"ranges": [{
"timeRange": {
"start": "00:03:52.5100000",
"end": "00:03:53.4330000"
},
"adjustedTimeRange": {
"start": "00:03:52.5100000",
"end": "00:03:53.4330000"
}
}]
}, {
"id": 13391,
"thumbnailId": "fe5b9ab0-104d-4776-8a7f-503ac570d6dc",
"ranges": [{
"timeRange": {
"start": "00:03:52.5100000",
"end": "00:03:55.3800000"
},
"adjustedTimeRange": {
"start": "00:03:52.5100000",
"end": "00:03:55.3800000"
}
}]
}, {
"id": 9114,
"thumbnailId": "ca23ff2b-aaf9-4296-a992-45078c5de06c",
"ranges": [{
"timeRange": {
"start": "00:03:52.5100000",
"end": "00:03:53.0660000"
},
"adjustedTimeRange": {
"start": "00:03:52.5100000",
"end": "00:03:53.0660000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:52.5100000",
"end": "00:03:55.3800000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:52.5100000",
"end": "00:03:55.3800000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:52.5100000",
"end": "00:03:55.3800000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:52.5100000",
"end": "00:03:52.6000000"
}, {
"start": "00:03:53.6660000",
"end": "00:03:55.3800000"
}],
"adjustedTimeRanges": [{
"start": "00:03:52.5100000",
"end": "00:03:52.6000000"
}, {
"start": "00:03:53.6660000",
"end": "00:03:55.3800000"
}]
}, {
"id": 17,
"name": "text",
"timeRanges": [{
"start": "00:03:52.5990000",
"end": "00:03:55.3800000"
}],
"adjustedTimeRanges": [{
"start": "00:03:52.5990000",
"end": "00:03:55.3800000"
}]
}]
}, {
"id": 33,
"lines": [{
"id": 57,
"timeRange": {
"start": "00:03:55.3800000",
"end": "00:03:58.4600000"
},
"adjustedTimeRange": {
"start": "00:03:55.3800000",
"end": "00:03:58.4600000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "7281c9e6-7c94-438a-8c78-58c7261e4662",
"ranges": [{
"timeRange": {
"start": "00:03:55.8660000",
"end": "00:03:58.4600000"
},
"adjustedTimeRange": {
"start": "00:03:55.8660000",
"end": "00:03:58.4600000"
}
}]
}, {
"id": 13391,
"thumbnailId": "3c07fb28-8dd2-4444-94af-9ec5218aec5b",
"ranges": [{
"timeRange": {
"start": "00:03:55.3800000",
"end": "00:03:58.4600000"
},
"adjustedTimeRange": {
"start": "00:03:55.3800000",
"end": "00:03:58.4600000"
}
}]
}, {
"id": 13872,
"thumbnailId": "3baf7405-f976-480f-b75d-ee3e659dbb8e",
"ranges": [{
"timeRange": {
"start": "00:03:57.6660000",
"end": "00:03:58.4600000"
},
"adjustedTimeRange": {
"start": "00:03:57.6660000",
"end": "00:03:58.4600000"
}
}]
}, {
"id": 13832,
"thumbnailId": "caae8ed2-2039-4459-aab3-f6d3ec2419c8",
"ranges": [{
"timeRange": {
"start": "00:03:57.4990000",
"end": "00:03:58.4600000"
},
"adjustedTimeRange": {
"start": "00:03:57.4990000",
"end": "00:03:58.4600000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:55.3800000",
"end": "00:03:55.3800000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:55.3800000",
"end": "00:03:58.4600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:55.3800000",
"end": "00:03:58.4600000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:55.3800000",
"end": "00:03:55.8000000"
}, {
"start": "00:03:56.8660000",
"end": "00:03:58.4600000"
}],
"adjustedTimeRanges": [{
"start": "00:03:55.3800000",
"end": "00:03:55.8000000"
}, {
"start": "00:03:56.8660000",
"end": "00:03:58.4600000"
}]
}, {
"id": 17,
"name": "text",
"timeRanges": [{
"start": "00:03:55.3800000",
"end": "00:03:55.8000000"
}],
"adjustedTimeRanges": [{
"start": "00:03:55.3800000",
"end": "00:03:55.8000000"
}]
}, {
"id": 18,
"name": "black",
"timeRanges": [{
"start": "00:03:56.8660000",
"end": "00:03:57.9330000"
}],
"adjustedTimeRanges": [{
"start": "00:03:56.8660000",
"end": "00:03:57.9330000"
}]
}]
}, {
"id": 34,
"lines": [{
"id": 58,
"timeRange": {
"start": "00:03:58.4600000",
"end": "00:04:03.6200000"
},
"adjustedTimeRange": {
"start": "00:03:58.4600000",
"end": "00:04:03.6200000"
},
"participantId": 2,
"text": "I'm going to monitor your money even look at it.",
"isIncluded": true,
"confidence": 0.72826838
}, {
"id": 59,
"timeRange": {
"start": "00:04:03.6200000",
"end": "00:04:04.4000000"
},
"adjustedTimeRange": {
"start": "00:04:03.6200000",
"end": "00:04:04.4000000"
},
"participantId": 2,
"text": "Maybe they could",
"isIncluded": true,
"confidence": 0.83333333333333337
}, {
"id": 60,
"timeRange": {
"start": "00:04:04.4000000",
"end": "00:04:14.3800000"
},
"adjustedTimeRange": {
"start": "00:04:04.4000000",
"end": "00:04:14.3800000"
},
"participantId": 2,
"text": "be bored even today I will bend over let him an email and he was here come home anytime yet almost there we were young vessel that way like he",
"isIncluded": true,
"confidence": 0.9625
}, {
"id": 61,
"timeRange": {
"start": "00:04:14.3800000",
"end": "00:04:20.7400000"
},
"adjustedTimeRange": {
"start": "00:04:14.3800000",
"end": "00:04:20.7400000"
},
"participantId": 2,
"text": "he had all moved an entire come out here lying in the food level OK.",
"isIncluded": true,
"confidence": 0.96053333333333335
}, {
"id": 62,
"timeRange": {
"start": "00:04:20.7400000",
"end": "00:04:23.3500000"
},
"adjustedTimeRange": {
"start": "00:04:20.7400000",
"end": "00:04:23.3500000"
},
"participantId": 2,
"text": "One dead lion but will never repeat",
"isIncluded": true,
"confidence": 0.5414416
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.239514023,
"faces": [{
"id": 19617,
"thumbnailId": "7281c9e6-7c94-438a-8c78-58c7261e4662",
"ranges": [{
"timeRange": {
"start": "00:03:58.4600000",
"end": "00:03:59.6990000"
},
"adjustedTimeRange": {
"start": "00:03:58.4600000",
"end": "00:03:59.6990000"
}
}, {
"timeRange": {
"start": "00:03:59.6990000",
"end": "00:04:06.6990000"
},
"adjustedTimeRange": {
"start": "00:03:59.6990000",
"end": "00:04:06.6990000"
}
}, {
"timeRange": {
"start": "00:04:09.2330000",
"end": "00:04:15.6660000"
},
"adjustedTimeRange": {
"start": "00:04:09.2330000",
"end": "00:04:15.6660000"
}
}, {
"timeRange": {
"start": "00:04:16.2330000",
"end": "00:04:23.0330000"
},
"adjustedTimeRange": {
"start": "00:04:16.2330000",
"end": "00:04:23.0330000"
}
}]
}, {
"id": 15122,
"thumbnailId": "eb20d091-5322-4664-85f3-74996fa58210",
"ranges": [{
"timeRange": {
"start": "00:04:16.3990000",
"end": "00:04:23.3500000"
},
"adjustedTimeRange": {
"start": "00:04:16.3990000",
"end": "00:04:23.3500000"
}
}]
}, {
"id": 14393,
"thumbnailId": "c93f6483-5d49-4599-9062-75694cf86f18",
"ranges": [{
"timeRange": {
"start": "00:04:05.3330000",
"end": "00:04:10.8330000"
},
"adjustedTimeRange": {
"start": "00:04:05.3330000",
"end": "00:04:10.8330000"
}
}]
}, {
"id": 13391,
"thumbnailId": "c79f2daf-eb39-4c6e-abd8-ba7eef675edd",
"ranges": [{
"timeRange": {
"start": "00:03:58.4600000",
"end": "00:04:00.8330000"
},
"adjustedTimeRange": {
"start": "00:03:58.4600000",
"end": "00:04:00.8330000"
}
}]
}, {
"id": 13872,
"thumbnailId": "f9d7319c-2068-45fc-a8f2-16f4e9ca6842",
"ranges": [{
"timeRange": {
"start": "00:03:58.4600000",
"end": "00:04:04.7660000"
},
"adjustedTimeRange": {
"start": "00:03:58.4600000",
"end": "00:04:04.7660000"
}
}]
}, {
"id": 15308,
"thumbnailId": "d8d28a6e-28f1-4554-a21e-bb9d0bf836b0",
"ranges": [{
"timeRange": {
"start": "00:04:20.5660000",
"end": "00:04:23.3500000"
},
"adjustedTimeRange": {
"start": "00:04:20.5660000",
"end": "00:04:23.3500000"
}
}]
}, {
"id": 9114,
"thumbnailId": "fd53cb46-32f2-40dd-9c03-9ef813bcff1b",
"ranges": [{
"timeRange": {
"start": "00:04:06.0660000",
"end": "00:04:13.7660000"
},
"adjustedTimeRange": {
"start": "00:04:06.0660000",
"end": "00:04:13.7660000"
}
}]
}, {
"id": 14691,
"thumbnailId": "0b2edbcd-53fc-4fa9-a55b-11c18b792cd0",
"ranges": [{
"timeRange": {
"start": "00:04:08.8660000",
"end": "00:04:15.8660000"
},
"adjustedTimeRange": {
"start": "00:04:08.8660000",
"end": "00:04:15.8660000"
}
}]
}, {
"id": 13832,
"thumbnailId": "8cc1f434-f99a-4c82-a0d1-7dd8e05e4494",
"ranges": [{
"timeRange": {
"start": "00:03:58.4600000",
"end": "00:04:07.7330000"
},
"adjustedTimeRange": {
"start": "00:03:58.4600000",
"end": "00:04:07.7330000"
}
}]
}, {
"id": 14920,
"thumbnailId": "c6277235-0998-4483-bf6c-369c7e643cc6",
"ranges": [{
"timeRange": {
"start": "00:04:12.9990000",
"end": "00:04:19.4660000"
},
"adjustedTimeRange": {
"start": "00:04:12.9990000",
"end": "00:04:19.4660000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:03:58.4600000",
"end": "00:04:01.7900000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:04:03.6200000",
"end": "00:04:23.3500000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:03:58.4600000",
"end": "00:04:23.3500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:03:58.4600000",
"end": "00:04:23.3500000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:03:58.4600000",
"end": "00:03:59"
}, {
"start": "00:04:00.0660000",
"end": "00:04:23.3500000"
}],
"adjustedTimeRanges": [{
"start": "00:03:58.4600000",
"end": "00:03:59"
}, {
"start": "00:04:00.0660000",
"end": "00:04:23.3500000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:04:07.5330000",
"end": "00:04:10.7330000"
}, {
"start": "00:04:14.9990000",
"end": "00:04:18.2000000"
}],
"adjustedTimeRanges": [{
"start": "00:04:07.5330000",
"end": "00:04:10.7330000"
}, {
"start": "00:04:14.9990000",
"end": "00:04:18.2000000"
}]
}, {
"id": 4,
"name": "group",
"timeRanges": [{
"start": "00:04:08.5990000",
"end": "00:04:10.7330000"
}],
"adjustedTimeRanges": [{
"start": "00:04:08.5990000",
"end": "00:04:10.7330000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:04:00.0660000",
"end": "00:04:03.2660000"
}, {
"start": "00:04:07.5330000",
"end": "00:04:10.7330000"
}, {
"start": "00:04:22.4660000",
"end": "00:04:23.3500000"
}],
"adjustedTimeRanges": [{
"start": "00:04:00.0660000",
"end": "00:04:03.2660000"
}, {
"start": "00:04:07.5330000",
"end": "00:04:10.7330000"
}, {
"start": "00:04:22.4660000",
"end": "00:04:23.3500000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:04:04.3330000",
"end": "00:04:07.5330000"
}, {
"start": "00:04:22.4660000",
"end": "00:04:23.3500000"
}],
"adjustedTimeRanges": [{
"start": "00:04:04.3330000",
"end": "00:04:07.5330000"
}, {
"start": "00:04:22.4660000",
"end": "00:04:23.3500000"
}]
}, {
"id": 7,
"name": "wall",
"timeRanges": [{
"start": "00:04:01.1330000",
"end": "00:04:03.2660000"
}],
"adjustedTimeRanges": [{
"start": "00:04:01.1330000",
"end": "00:04:03.2660000"
}]
}, {
"id": 8,
"name": "woman",
"timeRanges": [{
"start": "00:04:03.2660000",
"end": "00:04:04.3330000"
}, {
"start": "00:04:06.4660000",
"end": "00:04:07.5330000"
}],
"adjustedTimeRanges": [{
"start": "00:04:03.2660000",
"end": "00:04:04.3330000"
}, {
"start": "00:04:06.4660000",
"end": "00:04:07.5330000"
}]
}, {
"id": 15,
"name": "man",
"timeRanges": [{
"start": "00:04:00.0660000",
"end": "00:04:03.2660000"
}],
"adjustedTimeRanges": [{
"start": "00:04:00.0660000",
"end": "00:04:03.2660000"
}]
}, {
"id": 19,
"name": "wedding",
"timeRanges": [{
"start": "00:04:03.2660000",
"end": "00:04:04.3330000"
}],
"adjustedTimeRanges": [{
"start": "00:04:03.2660000",
"end": "00:04:04.3330000"
}]
}]
}, {
"id": 35,
"lines": [{
"id": 63,
"timeRange": {
"start": "00:04:23.3500000",
"end": "00:04:28.6800000"
},
"adjustedTimeRange": {
"start": "00:04:23.3500000",
"end": "00:04:28.6800000"
},
"participantId": 4,
"text": "I'm going hard AF why do you have a recovery.",
"isIncluded": true,
"confidence": 0.87144290000000013
}, {
"id": 64,
"timeRange": {
"start": "00:04:28.6800000",
"end": "00:04:32.8200000"
},
"adjustedTimeRange": {
"start": "00:04:28.6800000",
"end": "00:04:32.8200000"
},
"participantId": 4,
"text": "Can be like me David am water government?",
"isIncluded": true,
"confidence": 0.71255010000000008
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.748061,
"faces": [{
"id": 19617,
"thumbnailId": "7281c9e6-7c94-438a-8c78-58c7261e4662",
"ranges": [{
"timeRange": {
"start": "00:04:31.2330000",
"end": "00:04:32.8200000"
},
"adjustedTimeRange": {
"start": "00:04:31.2330000",
"end": "00:04:32.8200000"
}
}]
}, {
"id": 16450,
"thumbnailId": "bd5dd91f-6f08-4fb2-afb2-2c271bd57efc",
"ranges": [{
"timeRange": {
"start": "00:04:28.1990000",
"end": "00:04:32.8200000"
},
"adjustedTimeRange": {
"start": "00:04:28.1990000",
"end": "00:04:32.8200000"
}
}]
}, {
"id": 15807,
"thumbnailId": "3cb58225-aac3-4168-8f42-8f7fc2aa7854",
"ranges": [{
"timeRange": {
"start": "00:04:31.3990000",
"end": "00:04:32.8200000"
},
"adjustedTimeRange": {
"start": "00:04:31.3990000",
"end": "00:04:32.8200000"
}
}]
}, {
"id": 15514,
"thumbnailId": "999c683e-3238-46f2-ac56-e6b976af7df2",
"ranges": [{
"timeRange": {
"start": "00:04:28.2660000",
"end": "00:04:32.8200000"
},
"adjustedTimeRange": {
"start": "00:04:28.2660000",
"end": "00:04:32.8200000"
}
}]
}, {
"id": 15308,
"thumbnailId": "0a62a6a3-33b9-437c-8371-91317f96acb9",
"ranges": [{
"timeRange": {
"start": "00:04:23.3500000",
"end": "00:04:27.4990000"
},
"adjustedTimeRange": {
"start": "00:04:23.3500000",
"end": "00:04:27.4990000"
}
}]
}, {
"id": 9114,
"thumbnailId": "6a83dd78-f856-4772-9281-30e62f08db7a",
"ranges": [{
"timeRange": {
"start": "00:04:31.1660000",
"end": "00:04:32.8200000"
},
"adjustedTimeRange": {
"start": "00:04:31.1660000",
"end": "00:04:32.8200000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:04:23.3500000",
"end": "00:04:32.8200000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:04:23.3500000",
"end": "00:04:32.8200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:04:23.3500000",
"end": "00:04:32.8200000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:04:23.3500000",
"end": "00:04:26.7330000"
}, {
"start": "00:04:29.9330000",
"end": "00:04:32.8200000"
}],
"adjustedTimeRanges": [{
"start": "00:04:23.3500000",
"end": "00:04:26.7330000"
}, {
"start": "00:04:29.9330000",
"end": "00:04:32.8200000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:04:23.3500000",
"end": "00:04:25.6660000"
}],
"adjustedTimeRanges": [{
"start": "00:04:23.3500000",
"end": "00:04:25.6660000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:04:23.3500000",
"end": "00:04:26.7330000"
}, {
"start": "00:04:29.9330000",
"end": "00:04:32.8200000"
}],
"adjustedTimeRanges": [{
"start": "00:04:23.3500000",
"end": "00:04:26.7330000"
}, {
"start": "00:04:29.9330000",
"end": "00:04:32.8200000"
}]
}, {
"id": 16,
"name": "ceiling",
"timeRanges": [{
"start": "00:04:23.5330000",
"end": "00:04:24.6000000"
}],
"adjustedTimeRanges": [{
"start": "00:04:23.5330000",
"end": "00:04:24.6000000"
}]
}, {
"id": 20,
"name": "cake",
"timeRanges": [{
"start": "00:04:30.9990000",
"end": "00:04:32.8200000"
}],
"adjustedTimeRanges": [{
"start": "00:04:30.9990000",
"end": "00:04:32.8200000"
}]
}]
}, {
"id": 36,
"lines": [{
"id": 65,
"timeRange": {
"start": "00:04:32.8200000",
"end": "00:04:46.2100000"
},
"adjustedTimeRange": {
"start": "00:04:32.8200000",
"end": "00:04:46.2100000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "48547db9-0f67-4767-a31c-fdb0fe925c83",
"ranges": [{
"timeRange": {
"start": "00:04:32.8200000",
"end": "00:04:44.0990000"
},
"adjustedTimeRange": {
"start": "00:04:32.8200000",
"end": "00:04:44.0990000"
}
}]
}, {
"id": 16450,
"thumbnailId": "01a914a2-37ef-46a9-b759-c4891656af98",
"ranges": [{
"timeRange": {
"start": "00:04:32.8200000",
"end": "00:04:34.2990000"
},
"adjustedTimeRange": {
"start": "00:04:32.8200000",
"end": "00:04:34.2990000"
}
}, {
"timeRange": {
"start": "00:04:42.4660000",
"end": "00:04:46.2100000"
},
"adjustedTimeRange": {
"start": "00:04:42.4660000",
"end": "00:04:46.2100000"
}
}]
}, {
"id": 16482,
"thumbnailId": "737ab009-1bc3-4caa-aba7-a1e37893d3e8",
"ranges": [{
"timeRange": {
"start": "00:04:38.5330000",
"end": "00:04:46.2100000"
},
"adjustedTimeRange": {
"start": "00:04:38.5330000",
"end": "00:04:46.2100000"
}
}]
}, {
"id": 15807,
"thumbnailId": "e11de744-bdf0-432b-a024-0ac5fb518a64",
"ranges": [{
"timeRange": {
"start": "00:04:32.8200000",
"end": "00:04:38.4990000"
},
"adjustedTimeRange": {
"start": "00:04:32.8200000",
"end": "00:04:38.4990000"
}
}]
}, {
"id": 15514,
"thumbnailId": "9365a9d3-440a-43e7-b4d5-427cf94b99c7",
"ranges": [{
"timeRange": {
"start": "00:04:32.8200000",
"end": "00:04:34.8330000"
},
"adjustedTimeRange": {
"start": "00:04:32.8200000",
"end": "00:04:34.8330000"
}
}]
}, {
"id": 16116,
"thumbnailId": "0d512717-2785-4fae-ba68-98b6b33c35b3",
"ranges": [{
"timeRange": {
"start": "00:04:38.8330000",
"end": "00:04:44.3660000"
},
"adjustedTimeRange": {
"start": "00:04:38.8330000",
"end": "00:04:44.3660000"
}
}]
}, {
"id": 9114,
"thumbnailId": "6a83dd78-f856-4772-9281-30e62f08db7a",
"ranges": [{
"timeRange": {
"start": "00:04:32.8200000",
"end": "00:04:34.5660000"
},
"adjustedTimeRange": {
"start": "00:04:32.8200000",
"end": "00:04:34.5660000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:04:32.8200000",
"end": "00:04:32.8200000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:04:32.8200000",
"end": "00:04:46.2100000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:04:32.8200000",
"end": "00:04:46.2100000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:04:32.8200000",
"end": "00:04:46.2100000"
}],
"adjustedTimeRanges": [{
"start": "00:04:32.8200000",
"end": "00:04:46.2100000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:04:32.8200000",
"end": "00:04:33.1330000"
}, {
"start": "00:04:41.6660000",
"end": "00:04:42.7330000"
}, {
"start": "00:04:44.8660000",
"end": "00:04:46.2100000"
}],
"adjustedTimeRanges": [{
"start": "00:04:32.8200000",
"end": "00:04:33.1330000"
}, {
"start": "00:04:41.6660000",
"end": "00:04:42.7330000"
}, {
"start": "00:04:44.8660000",
"end": "00:04:46.2100000"
}]
}, {
"id": 15,
"name": "man",
"timeRanges": [{
"start": "00:04:33.1330000",
"end": "00:04:34.2000000"
}],
"adjustedTimeRanges": [{
"start": "00:04:33.1330000",
"end": "00:04:34.2000000"
}]
}, {
"id": 20,
"name": "cake",
"timeRanges": [{
"start": "00:04:32.8200000",
"end": "00:04:33.1330000"
}],
"adjustedTimeRanges": [{
"start": "00:04:32.8200000",
"end": "00:04:33.1330000"
}]
}]
}, {
"id": 37,
"lines": [{
"id": 66,
"timeRange": {
"start": "00:04:46.2100000",
"end": "00:04:54.1200000"
},
"adjustedTimeRange": {
"start": "00:04:46.2100000",
"end": "00:04:54.1200000"
},
"participantId": 2,
"text": "I need only by you know morning game you can come on Cartier D 3 double room other day.",
"isIncluded": true,
"confidence": 0.86313675789473676
}, {
"id": 67,
"timeRange": {
"start": "00:04:54.1200000",
"end": "00:05:00.0940000"
},
"adjustedTimeRange": {
"start": "00:04:54.1200000",
"end": "00:05:00.0940000"
},
"participantId": 2,
"text": "Only collardi .7 power even I'm going to let her room are very.",
"isIncluded": true,
"confidence": 0.7255461769230771
}, {
"id": 68,
"timeRange": {
"start": "00:05:00.0940000",
"end": "00:05:04.2840000"
},
"adjustedTimeRange": {
"start": "00:05:00.0940000",
"end": "00:05:04.2840000"
},
"participantId": 2,
"text": "God.",
"isIncluded": true,
"confidence": 0.2204409
}, {
"id": 69,
"timeRange": {
"start": "00:05:04.2840000",
"end": "00:05:07.4440000"
},
"adjustedTimeRange": {
"start": "00:05:04.2840000",
"end": "00:05:07.4440000"
},
"participantId": 2,
"text": "need to come on God clearly a double room",
"isIncluded": true,
"confidence": 0.72281481111111112
}, {
"id": 70,
"timeRange": {
"start": "00:05:07.4440000",
"end": "00:05:10.7040000"
},
"adjustedTimeRange": {
"start": "00:05:07.4440000",
"end": "00:05:10.7040000"
},
"participantId": 2,
"text": "other day?",
"isIncluded": true,
"confidence": 1.0
}, {
"id": 71,
"timeRange": {
"start": "00:05:10.7040000",
"end": "00:05:16.8040000"
},
"adjustedTimeRange": {
"start": "00:05:10.7040000",
"end": "00:05:16.8040000"
},
"participantId": 2,
"text": "depart for them follow name and I'm going I'm sorry could you not see you mother day.",
"isIncluded": true,
"confidence": 0.77102074117647068
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.5,
"faces": [{
"id": 19617,
"thumbnailId": "46147793-e265-4f5f-89fd-c437cbeecc89",
"ranges": [{
"timeRange": {
"start": "00:04:46.2330000",
"end": "00:04:53.5660000"
},
"adjustedTimeRange": {
"start": "00:04:46.2330000",
"end": "00:04:53.5660000"
}
}, {
"timeRange": {
"start": "00:04:55.9660000",
"end": "00:05:11.7870000"
},
"adjustedTimeRange": {
"start": "00:04:55.9660000",
"end": "00:05:11.7870000"
}
}, {
"timeRange": {
"start": "00:05:11.7870000",
"end": "00:05:16.0200000"
},
"adjustedTimeRange": {
"start": "00:05:11.7870000",
"end": "00:05:16.0200000"
}
}, {
"timeRange": {
"start": "00:05:16.4530000",
"end": "00:05:16.8040000"
},
"adjustedTimeRange": {
"start": "00:05:16.4530000",
"end": "00:05:16.8040000"
}
}]
}, {
"id": 17504,
"thumbnailId": "606e0d99-b76e-4217-a3e4-9aa2294b4251",
"ranges": [{
"timeRange": {
"start": "00:04:54.2990000",
"end": "00:05:00.0660000"
},
"adjustedTimeRange": {
"start": "00:04:54.2990000",
"end": "00:05:00.0660000"
}
}]
}, {
"id": 18677,
"thumbnailId": "ce10ab05-260d-475c-8f44-ae5e299f5e68",
"ranges": [{
"timeRange": {
"start": "00:05:01.5540000",
"end": "00:05:08.6200000"
},
"adjustedTimeRange": {
"start": "00:05:01.5540000",
"end": "00:05:08.6200000"
}
}]
}, {
"id": 16450,
"thumbnailId": "20c54de2-dcf1-4d66-a940-272ffa7fa7ef",
"ranges": [{
"timeRange": {
"start": "00:04:46.2100000",
"end": "00:04:49.7990000"
},
"adjustedTimeRange": {
"start": "00:04:46.2100000",
"end": "00:04:49.7990000"
}
}]
}, {
"id": 16482,
"thumbnailId": "a4a2ee7c-40dd-4dff-8c7f-cb830250cb92",
"ranges": [{
"timeRange": {
"start": "00:04:46.2100000",
"end": "00:04:48.1330000"
},
"adjustedTimeRange": {
"start": "00:04:46.2100000",
"end": "00:04:48.1330000"
}
}]
}, {
"id": 16786,
"thumbnailId": "5f0c466f-2b37-4e39-bc51-017a7fbff700",
"ranges": [{
"timeRange": {
"start": "00:04:47.9660000",
"end": "00:04:53.0660000"
},
"adjustedTimeRange": {
"start": "00:04:47.9660000",
"end": "00:04:53.0660000"
}
}]
}, {
"id": 16827,
"thumbnailId": "07939eef-849d-4eab-8ce1-c04e8d0905cb",
"ranges": [{
"timeRange": {
"start": "00:04:46.6990000",
"end": "00:04:53.3990000"
},
"adjustedTimeRange": {
"start": "00:04:46.6990000",
"end": "00:04:53.3990000"
}
}]
}, {
"id": 16794,
"thumbnailId": "210489bc-53f8-4a0d-8a53-efaca87f639e",
"ranges": [{
"timeRange": {
"start": "00:04:46.5660000",
"end": "00:04:52.3330000"
},
"adjustedTimeRange": {
"start": "00:04:46.5660000",
"end": "00:04:52.3330000"
}
}]
}, {
"id": 18514,
"thumbnailId": "05f65f67-62d9-4f79-a374-355362f3501c",
"ranges": [{
"timeRange": {
"start": "00:05:00.1210000",
"end": "00:05:04.8200000"
},
"adjustedTimeRange": {
"start": "00:05:00.1210000",
"end": "00:05:04.8200000"
}
}]
}, {
"id": 18696,
"thumbnailId": "e856e3af-f335-4034-84ba-a9e175990fb4",
"ranges": [{
"timeRange": {
"start": "00:05:01.8210000",
"end": "00:05:07.4200000"
},
"adjustedTimeRange": {
"start": "00:05:01.8210000",
"end": "00:05:07.4200000"
}
}]
}, {
"id": 9114,
"thumbnailId": "63e6c970-4c80-4d46-900a-e7e360f98aa5",
"ranges": [{
"timeRange": {
"start": "00:04:46.4330000",
"end": "00:04:53.2330000"
},
"adjustedTimeRange": {
"start": "00:04:46.4330000",
"end": "00:04:53.2330000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:04:46.2100000",
"end": "00:04:52.1200000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:04:54.1200000",
"end": "00:05:02.7440000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:05:04.2840000",
"end": "00:05:08.8440000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:05:10.7040000",
"end": "00:05:16.8040000"
}
}]
}],
"scenes": [{
"id": 2,
"timeRange": {
"start": "00:04:46.2100000",
"end": "00:04:55.9660000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "d032bc01-ff77-4833-9a8c-cacee6a6135a",
"shots": [{
"id": 3,
"timeRange": {
"start": "00:04:46.2100000",
"end": "00:04:55.9660000"
},
"keyFrame": "00:02:59.2330000",
"keyFrameThumbnailId": "4c30f890-dfa7-4b06-a11c-abf5d09be07b"
}]
}, {
"id": 3,
"timeRange": {
"start": "00:04:55.9660000",
"end": "00:04:59.9660000"
},
"keyFrame": "00:04:59.1670000",
"keyFrameThumbnailId": "f7615e9b-d456-4280-9c2b-8a36f8395e75",
"shots": [{
"id": 4,
"timeRange": {
"start": "00:04:55.9660000",
"end": "00:04:59.9660000"
},
"keyFrame": "00:04:59.1670000",
"keyFrameThumbnailId": "3ee1bdb6-ce4c-45ce-a9d2-4ba9bf362c62"
}]
}, {
"id": 4,
"timeRange": {
"start": "00:04:59.9660000",
"end": "00:05:00.0330000"
},
"keyFrame": "00:04:59.9330000",
"keyFrameThumbnailId": "789de104-1ffe-461f-b972-d6577e2e9bea",
"shots": [{
"id": 5,
"timeRange": {
"start": "00:04:59.9660000",
"end": "00:05:00.0330000"
},
"keyFrame": "00:04:59.9330000",
"keyFrameThumbnailId": "168e99c7-7a8b-454e-ad08-6a4b50f4b3a7"
}]
}, {
"id": 5,
"timeRange": {
"start": "00:05:00.0540000",
"end": "00:05:16.8040000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "60cbc9fe-f1fe-46f9-8cc1-ac2d5975549f",
"shots": [{
"id": 6,
"timeRange": {
"start": "00:05:00.0540000",
"end": "00:05:16.8040000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "4a5fefd8-2575-4ade-ac4e-989aa5a880a2"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:04:46.2100000",
"end": "00:04:55.5330000"
}, {
"start": "00:04:56.5990000",
"end": "00:04:59.8000000"
}, {
"start": "00:05:00.1200000",
"end": "00:05:16.8040000"
}],
"adjustedTimeRanges": [{
"start": "00:04:46.2100000",
"end": "00:04:55.5330000"
}, {
"start": "00:04:56.5990000",
"end": "00:04:59.8000000"
}, {
"start": "00:05:00.1200000",
"end": "00:05:16.8040000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:04:53.3990000",
"end": "00:04:55.5330000"
}, {
"start": "00:05:00.1200000",
"end": "00:05:03.3200000"
}],
"adjustedTimeRanges": [{
"start": "00:04:53.3990000",
"end": "00:04:55.5330000"
}, {
"start": "00:05:00.1200000",
"end": "00:05:03.3200000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:04:46.2100000",
"end": "00:04:49.1330000"
}, {
"start": "00:04:51.2660000",
"end": "00:04:52.3330000"
}, {
"start": "00:05:04.3870000",
"end": "00:05:15.0540000"
}],
"adjustedTimeRanges": [{
"start": "00:04:46.2100000",
"end": "00:04:49.1330000"
}, {
"start": "00:04:51.2660000",
"end": "00:04:52.3330000"
}, {
"start": "00:05:04.3870000",
"end": "00:05:15.0540000"
}]
}, {
"id": 7,
"name": "wall",
"timeRanges": [{
"start": "00:04:53.3990000",
"end": "00:04:55.5330000"
}],
"adjustedTimeRanges": [{
"start": "00:04:53.3990000",
"end": "00:04:55.5330000"
}]
}, {
"id": 15,
"name": "man",
"timeRanges": [{
"start": "00:05:08.6530000",
"end": "00:05:10.7870000"
}],
"adjustedTimeRanges": [{
"start": "00:05:08.6530000",
"end": "00:05:10.7870000"
}]
}, {
"id": 16,
"name": "ceiling",
"timeRanges": [{
"start": "00:05:03.3200000",
"end": "00:05:07.5870000"
}],
"adjustedTimeRanges": [{
"start": "00:05:03.3200000",
"end": "00:05:07.5870000"
}]
}, {
"id": 21,
"name": "crowd",
"timeRanges": [{
"start": "00:05:15.0530000",
"end": "00:05:16.8040000"
}],
"adjustedTimeRanges": [{
"start": "00:05:15.0530000",
"end": "00:05:16.8040000"
}]
}]
}, {
"id": 38,
"lines": [{
"id": 72,
"timeRange": {
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
},
"adjustedTimeRange": {
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "7281c9e6-7c94-438a-8c78-58c7261e4662",
"ranges": [{
"timeRange": {
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
},
"adjustedTimeRange": {
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:05:16.8040000",
"end": "00:05:16.8040000"
}
}]
}],
"scenes": [{
"id": 5,
"timeRange": {
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "60cbc9fe-f1fe-46f9-8cc1-ac2d5975549f",
"shots": [{
"id": 6,
"timeRange": {
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "4a5fefd8-2575-4ade-ac4e-989aa5a880a2"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
}],
"adjustedTimeRanges": [{
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
}]
}, {
"id": 21,
"name": "crowd",
"timeRanges": [{
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
}],
"adjustedTimeRanges": [{
"start": "00:05:16.8040000",
"end": "00:05:18.9140000"
}]
}]
}, {
"id": 39,
"lines": [{
"id": 73,
"timeRange": {
"start": "00:05:18.9140000",
"end": "00:05:21.6740000"
},
"adjustedTimeRange": {
"start": "00:05:18.9140000",
"end": "00:05:21.6740000"
},
"participantId": 2,
"text": "are you my name is Adam phone",
"isIncluded": true,
"confidence": 0.646
}, {
"id": 74,
"timeRange": {
"start": "00:05:21.6740000",
"end": "00:05:22.1140000"
},
"adjustedTimeRange": {
"start": "00:05:21.6740000",
"end": "00:05:22.1140000"
},
"participantId": 2,
"text": "mother?",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.820877433,
"faces": [{
"id": 19617,
"thumbnailId": "7281c9e6-7c94-438a-8c78-58c7261e4662",
"ranges": [{
"timeRange": {
"start": "00:05:18.9140000",
"end": "00:05:22.1140000"
},
"adjustedTimeRange": {
"start": "00:05:18.9140000",
"end": "00:05:22.1140000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:05:18.9140000",
"end": "00:05:22.1140000"
}
}]
}],
"scenes": [{
"id": 5,
"timeRange": {
"start": "00:05:18.9140000",
"end": "00:05:22.1140000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "60cbc9fe-f1fe-46f9-8cc1-ac2d5975549f",
"shots": [{
"id": 6,
"timeRange": {
"start": "00:05:18.9140000",
"end": "00:05:22.1140000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "4a5fefd8-2575-4ade-ac4e-989aa5a880a2"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:05:18.9140000",
"end": "00:05:22.1140000"
}],
"adjustedTimeRanges": [{
"start": "00:05:18.9140000",
"end": "00:05:22.1140000"
}]
}, {
"id": 4,
"name": "group",
"timeRanges": [{
"start": "00:05:21.4530000",
"end": "00:05:22.1140000"
}],
"adjustedTimeRanges": [{
"start": "00:05:21.4530000",
"end": "00:05:22.1140000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:05:19.3200000",
"end": "00:05:21.4540000"
}],
"adjustedTimeRanges": [{
"start": "00:05:19.3200000",
"end": "00:05:21.4540000"
}]
}, {
"id": 21,
"name": "crowd",
"timeRanges": [{
"start": "00:05:18.9140000",
"end": "00:05:19.3200000"
}],
"adjustedTimeRanges": [{
"start": "00:05:18.9140000",
"end": "00:05:19.3200000"
}]
}]
}, {
"id": 40,
"lines": [{
"id": 75,
"timeRange": {
"start": "00:05:22.1140000",
"end": "00:05:27.0940000"
},
"adjustedTimeRange": {
"start": "00:05:22.1140000",
"end": "00:05:27.0940000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "0d002a55-79aa-4669-b61c-4238afe23268",
"ranges": [{
"timeRange": {
"start": "00:05:22.1140000",
"end": "00:05:27.0940000"
},
"adjustedTimeRange": {
"start": "00:05:22.1140000",
"end": "00:05:27.0940000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:05:22.1140000",
"end": "00:05:22.1140000"
}
}]
}],
"scenes": [{
"id": 5,
"timeRange": {
"start": "00:05:22.1140000",
"end": "00:05:27.0940000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "60cbc9fe-f1fe-46f9-8cc1-ac2d5975549f",
"shots": [{
"id": 6,
"timeRange": {
"start": "00:05:22.1140000",
"end": "00:05:22.4200000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "4a5fefd8-2575-4ade-ac4e-989aa5a880a2"
}, {
"id": 7,
"timeRange": {
"start": "00:05:22.4200000",
"end": "00:05:27.0940000"
},
"keyFrame": "00:05:33.1210000",
"keyFrameThumbnailId": "b1242350-afe7-4404-b681-b43b32b934c1"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:05:22.1140000",
"end": "00:05:22.5200000"
}, {
"start": "00:05:23.5870000",
"end": "00:05:27.0940000"
}],
"adjustedTimeRanges": [{
"start": "00:05:22.1140000",
"end": "00:05:22.5200000"
}, {
"start": "00:05:23.5870000",
"end": "00:05:27.0940000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:05:24.6530000",
"end": "00:05:25.7200000"
}],
"adjustedTimeRanges": [{
"start": "00:05:24.6530000",
"end": "00:05:25.7200000"
}]
}, {
"id": 4,
"name": "group",
"timeRanges": [{
"start": "00:05:22.1140000",
"end": "00:05:22.5200000"
}],
"adjustedTimeRanges": [{
"start": "00:05:22.1140000",
"end": "00:05:22.5200000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:05:23.5870000",
"end": "00:05:25.7200000"
}, {
"start": "00:05:26.7870000",
"end": "00:05:27.0940000"
}],
"adjustedTimeRanges": [{
"start": "00:05:23.5870000",
"end": "00:05:25.7200000"
}, {
"start": "00:05:26.7870000",
"end": "00:05:27.0940000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:05:24.6530000",
"end": "00:05:25.7200000"
}, {
"start": "00:05:26.7870000",
"end": "00:05:27.0940000"
}],
"adjustedTimeRanges": [{
"start": "00:05:24.6530000",
"end": "00:05:25.7200000"
}, {
"start": "00:05:26.7870000",
"end": "00:05:27.0940000"
}]
}, {
"id": 9,
"name": "clothing",
"timeRanges": [{
"start": "00:05:22.5200000",
"end": "00:05:23.5870000"
}],
"adjustedTimeRanges": [{
"start": "00:05:22.5200000",
"end": "00:05:23.5870000"
}]
}]
}, {
"id": 41,
"lines": [{
"id": 76,
"timeRange": {
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
},
"adjustedTimeRange": {
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
},
"participantId": 2,
"text": "Wanna",
"isIncluded": true,
"confidence": 0.5
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.13529563,
"faces": [{
"id": 19617,
"thumbnailId": "1d0290fe-2614-4695-8263-de0d1cb65ea4",
"ranges": [{
"timeRange": {
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
},
"adjustedTimeRange": {
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
}
}]
}],
"scenes": [{
"id": 5,
"timeRange": {
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "60cbc9fe-f1fe-46f9-8cc1-ac2d5975549f",
"shots": [{
"id": 7,
"timeRange": {
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
},
"keyFrame": "00:05:33.1210000",
"keyFrameThumbnailId": "b1242350-afe7-4404-b681-b43b32b934c1"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
}],
"adjustedTimeRanges": [{
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
}],
"adjustedTimeRanges": [{
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
}],
"adjustedTimeRanges": [{
"start": "00:05:27.0940000",
"end": "00:05:27.7540000"
}]
}]
}, {
"id": 42,
"lines": [{
"id": 77,
"timeRange": {
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
},
"adjustedTimeRange": {
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [{
"id": 19617,
"thumbnailId": "83b3dfb2-29b9-49cb-9e70-5e16f2c1d711",
"ranges": [{
"timeRange": {
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
},
"adjustedTimeRange": {
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:05:27.7540000",
"end": "00:05:29.4640000"
}
}]
}],
"scenes": [{
"id": 5,
"timeRange": {
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "60cbc9fe-f1fe-46f9-8cc1-ac2d5975549f",
"shots": [{
"id": 7,
"timeRange": {
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
},
"keyFrame": "00:05:33.1210000",
"keyFrameThumbnailId": "b1242350-afe7-4404-b681-b43b32b934c1"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
}],
"adjustedTimeRanges": [{
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:05:27.7540000",
"end": "00:05:28.9200000"
}],
"adjustedTimeRanges": [{
"start": "00:05:27.7540000",
"end": "00:05:28.9200000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
}],
"adjustedTimeRanges": [{
"start": "00:05:27.7540000",
"end": "00:05:30.4640000"
}]
}]
}, {
"id": 43,
"lines": [{
"id": 78,
"timeRange": {
"start": "00:05:30.4640000",
"end": "00:05:30.5040000"
},
"adjustedTimeRange": {
"start": "00:05:30.4640000",
"end": "00:05:30.5040000"
},
"participantId": 2,
"text": "we",
"isIncluded": true,
"confidence": 1.0
}, {
"id": 79,
"timeRange": {
"start": "00:05:30.5040000",
"end": "00:05:40.8240000"
},
"adjustedTimeRange": {
"start": "00:05:30.5040000",
"end": "00:05:40.8240000"
},
"participantId": 2,
"text": "finally found him for Monday wow and I think of any woman program late so I want to work in a yellow wood think I didn't Google and dinner every",
"isIncluded": true,
"confidence": 0.7684874266666667
}, {
"id": 80,
"timeRange": {
"start": "00:05:40.8240000",
"end": "00:05:45.1340000"
},
"adjustedTimeRange": {
"start": "00:05:40.8240000",
"end": "00:05:45.1340000"
},
"participantId": 2,
"text": "mother in law only wargin I am how old are you?",
"isIncluded": true,
"confidence": 0.95454545454545459
}, {
"id": 81,
"timeRange": {
"start": "00:05:45.1340000",
"end": "00:05:51.8040000"
},
"adjustedTimeRange": {
"start": "00:05:45.1340000",
"end": "00:05:51.8040000"
},
"participantId": 2,
"text": "We learned in a timely my girly doing googling it in a thermal mug ready tongue got hard again",
"isIncluded": true,
"confidence": 0.92990741052631576
}, {
"id": 82,
"timeRange": {
"start": "00:05:51.8040000",
"end": "00:05:54.5740000"
},
"adjustedTimeRange": {
"start": "00:05:51.8040000",
"end": "00:05:54.5740000"
},
"participantId": 2,
"text": "yay.",
"isIncluded": true,
"confidence": 1.0
}, {
"id": 83,
"timeRange": {
"start": "00:05:54.5740000",
"end": "00:05:58.0340000"
},
"adjustedTimeRange": {
"start": "00:05:54.5740000",
"end": "00:05:58.0340000"
},
"participantId": 2,
"text": "mean my name mean davaadorj",
"isIncluded": true,
"confidence": 0.7681324
}, {
"id": 84,
"timeRange": {
"start": "00:05:58.0340000",
"end": "00:05:59.0440000"
},
"adjustedTimeRange": {
"start": "00:05:58.0340000",
"end": "00:05:59.0440000"
},
"participantId": 2,
"text": "a",
"isIncluded": true,
"confidence": 1.0
}, {
"id": 85,
"timeRange": {
"start": "00:05:59.0440000",
"end": "00:05:59.9340000"
},
"adjustedTimeRange": {
"start": "00:05:59.0440000",
"end": "00:05:59.9340000"
},
"participantId": 2,
"text": "might have a couple minutes.",
"isIncluded": true,
"confidence": 0.4
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.880322933,
"faces": [{
"id": 19617,
"thumbnailId": "f39bf9d3-b7fd-430a-9ce7-59f7eda11bcd",
"ranges": [{
"timeRange": {
"start": "00:05:30.4640000",
"end": "00:05:38.7870000"
},
"adjustedTimeRange": {
"start": "00:05:30.4640000",
"end": "00:05:38.7870000"
}
}]
}, {
"id": 20054,
"thumbnailId": "6489adef-76c1-402d-8017-44d931ba982b",
"ranges": [{
"timeRange": {
"start": "00:05:36.6870000",
"end": "00:05:41.3530000"
},
"adjustedTimeRange": {
"start": "00:05:36.6870000",
"end": "00:05:41.3530000"
}
}]
}],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:05:30.4640000",
"end": "00:05:52.9740000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:05:54.5740000",
"end": "00:05:59.9340000"
}
}]
}],
"scenes": [{
"id": 5,
"timeRange": {
"start": "00:05:30.4640000",
"end": "00:05:41.3530000"
},
"keyFrame": "00:05:10.9540000",
"keyFrameThumbnailId": "60cbc9fe-f1fe-46f9-8cc1-ac2d5975549f",
"shots": [{
"id": 7,
"timeRange": {
"start": "00:05:30.4640000",
"end": "00:05:41.3530000"
},
"keyFrame": "00:05:33.1210000",
"keyFrameThumbnailId": "b1242350-afe7-4404-b681-b43b32b934c1"
}]
}],
"annotations": [{
"id": 1,
"name": "person",
"timeRanges": [{
"start": "00:05:30.4640000",
"end": "00:05:37.4540000"
}],
"adjustedTimeRanges": [{
"start": "00:05:30.4640000",
"end": "00:05:37.4540000"
}]
}, {
"id": 3,
"name": "posing",
"timeRanges": [{
"start": "00:05:34.2530000",
"end": "00:05:37.4540000"
}],
"adjustedTimeRanges": [{
"start": "00:05:34.2530000",
"end": "00:05:37.4540000"
}]
}, {
"id": 5,
"name": "standing",
"timeRanges": [{
"start": "00:05:32.1200000",
"end": "00:05:37.4540000"
}],
"adjustedTimeRanges": [{
"start": "00:05:32.1200000",
"end": "00:05:37.4540000"
}]
}, {
"id": 6,
"name": "indoor",
"timeRanges": [{
"start": "00:05:30.4640000",
"end": "00:05:37.4540000"
}],
"adjustedTimeRanges": [{
"start": "00:05:30.4640000",
"end": "00:05:37.4540000"
}]
}, {
"id": 22,
"name": "young",
"timeRanges": [{
"start": "00:05:33.1870000",
"end": "00:05:34.2540000"
}],
"adjustedTimeRanges": [{
"start": "00:05:33.1870000",
"end": "00:05:34.2540000"
}]
}]
}, {
"id": 44,
"lines": [{
"id": 86,
"timeRange": {
"start": "00:05:59.9340000",
"end": "00:06:02.3540000"
},
"adjustedTimeRange": {
"start": "00:05:59.9340000",
"end": "00:06:02.3540000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:05:59.9340000",
"end": "00:05:59.9340000"
}
}]
}],
"scenes": [],
"annotations": []
}, {
"id": 45,
"lines": [{
"id": 87,
"timeRange": {
"start": "00:06:02.3540000",
"end": "00:06:03.8740000"
},
"adjustedTimeRange": {
"start": "00:06:02.3540000",
"end": "00:06:03.8740000"
},
"participantId": 2,
"text": "Mamino new phone",
"isIncluded": true,
"confidence": 0.34033333333333332
}, {
"id": 88,
"timeRange": {
"start": "00:06:03.8740000",
"end": "00:06:04.3240000"
},
"adjustedTimeRange": {
"start": "00:06:03.8740000",
"end": "00:06:04.3240000"
},
"participantId": 2,
"text": "number.",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.912160635,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:06:02.3540000",
"end": "00:06:04.3240000"
}
}]
}],
"scenes": [],
"annotations": []
}, {
"id": 46,
"lines": [{
"id": 89,
"timeRange": {
"start": "00:06:04.3240000",
"end": "00:06:06.4840000"
},
"adjustedTimeRange": {
"start": "00:06:04.3240000",
"end": "00:06:06.4840000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:06:04.3240000",
"end": "00:06:04.3240000"
}
}]
}],
"scenes": [],
"annotations": []
}, {
"id": 47,
"lines": [{
"id": 90,
"timeRange": {
"start": "00:06:06.4840000",
"end": "00:06:09.8040000"
},
"adjustedTimeRange": {
"start": "00:06:06.4840000",
"end": "00:06:09.8040000"
},
"participantId": 2,
"text": "Royal money in order cool man I'm done",
"isIncluded": true,
"confidence": 0.80654685
}, {
"id": 91,
"timeRange": {
"start": "00:06:09.8040000",
"end": "00:06:12.6840000"
},
"adjustedTimeRange": {
"start": "00:06:09.8040000",
"end": "00:06:12.6840000"
},
"participantId": 2,
"text": "Hey in",
"isIncluded": true,
"confidence": 0.70100000000000007
}, {
"id": 92,
"timeRange": {
"start": "00:06:12.6840000",
"end": "00:06:17.7640000"
},
"adjustedTimeRange": {
"start": "00:06:12.6840000",
"end": "00:06:17.7640000"
},
"participantId": 2,
"text": "the room left you with him then we save me.",
"isIncluded": true,
"confidence": 0.89920000000000011
}, {
"id": 93,
"timeRange": {
"start": "00:06:17.7640000",
"end": "00:06:20.3340000"
},
"adjustedTimeRange": {
"start": "00:06:17.7640000",
"end": "00:06:20.3340000"
},
"participantId": 2,
"text": "Thunder.",
"isIncluded": true,
"confidence": 0.11
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.8269265,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:06:06.4840000",
"end": "00:06:16.1740000"
}
}, {
"type": 4,
"timeRange": {
"start": "00:06:17.7640000",
"end": "00:06:18.9840000"
}
}]
}],
"scenes": [],
"annotations": []
}, {
"id": 48,
"lines": [{
"id": 94,
"timeRange": {
"start": "00:06:20.3340000",
"end": "00:06:23.4840000"
},
"adjustedTimeRange": {
"start": "00:06:20.3340000",
"end": "00:06:23.4840000"
},
"participantId": 5,
"text": "you ever felt like?",
"isIncluded": true,
"confidence": 0.641
}, {
"id": 95,
"timeRange": {
"start": "00:06:23.4840000",
"end": "00:06:24.2140000"
},
"adjustedTimeRange": {
"start": "00:06:23.4840000",
"end": "00:06:24.2140000"
},
"participantId": 5,
"text": "Coming money.",
"isIncluded": true,
"confidence": 0.55699999999999994
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.142910659,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:06:20.3340000",
"end": "00:06:24.2140000"
}
}]
}],
"scenes": [],
"annotations": []
}, {
"id": 49,
"lines": [{
"id": 96,
"timeRange": {
"start": "00:06:24.2140000",
"end": "00:06:27.1840000"
},
"adjustedTimeRange": {
"start": "00:06:24.2140000",
"end": "00:06:27.1840000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:06:24.2140000",
"end": "00:06:24.2140000"
}
}]
}],
"scenes": [],
"annotations": []
}, {
"id": 50,
"lines": [{
"id": 97,
"timeRange": {
"start": "00:06:27.1840000",
"end": "00:06:28.6640000"
},
"adjustedTimeRange": {
"start": "00:06:27.1840000",
"end": "00:06:28.6640000"
},
"participantId": 5,
"text": "But it got it covered.",
"isIncluded": true,
"confidence": 0.57644708
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.831487,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:06:27.1840000",
"end": "00:06:28.6640000"
}
}]
}],
"scenes": [],
"annotations": []
}, {
"id": 51,
"lines": [{
"id": 98,
"timeRange": {
"start": "00:06:28.6640000",
"end": "00:06:31.6540000"
},
"adjustedTimeRange": {
"start": "00:06:28.6640000",
"end": "00:06:31.6540000"
},
"participantId": -2,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.0,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:06:28.6640000",
"end": "00:06:28.6640000"
}
}]
}],
"scenes": [],
"annotations": []
}, {
"id": 52,
"lines": [{
"id": 99,
"timeRange": {
"start": "00:06:31.6540000",
"end": "00:06:34.8440000"
},
"adjustedTimeRange": {
"start": "00:06:31.6540000",
"end": "00:06:34.8440000"
},
"participantId": 5,
"text": "It would have let me go and have a.",
"isIncluded": true,
"confidence": 0.812888888888889
}, {
"id": 100,
"timeRange": {
"start": "00:06:34.8440000",
"end": "00:06:37"
},
"adjustedTimeRange": {
"start": "00:06:34.8440000",
"end": "00:06:37"
},
"participantId": 5,
"text": "",
"isIncluded": true,
"confidence": 1.0
}],
"sentimentIds": [],
"thumbnailsIds": [],
"sentiment": 0.1354495,
"faces": [],
"ocrs": [],
"audioEffectInstances": [{
"type": 4,
"ranges": [{
"type": 4,
"timeRange": {
"start": "00:06:31.6540000",
"end": "00:06:34.8440000"
}
}]
}],
"scenes": [],
"annotations": []
}],
"topics": [{
"id": 0,
"name": "phone number",
"stem": "phone number",
"words": ["phone number"],
"rank": 4.0
}, {
"id": 1,
"name": "double room",
"stem": "double room",
"words": ["double room"],
"rank": 3.666666666666667
}, {
"id": 2,
"name": "room",
"stem": "room",
"words": ["room"],
"rank": 1.6666666666666667
}, {
"id": 3,
"name": "money",
"stem": "money",
"words": ["money"],
"rank": 1.5
}],
"brands": [{
"id": 1,
"name": "Google",
"wikiId": "Google",
"wikiUrl": "http://en.wikipedia.org/wiki/Google",
"description": "Google is an American multinational technology company specializing in Internet-related services and products. These include online advertising technologies, search, cloud computing, and software. Most of its profits are derived from AdWords, an online advertising service that places advertising near the list of search results.",
"confidence": 0.564,
"tags": [],
"transcriptTimeRanges": [{
"start": "00:05:30.5040000",
"end": "00:05:40.8240000"
}],
"transcriptAdjustedTimeRanges": [{
"start": "00:05:30.5040000",
"end": "00:05:40.8240000"
}],
"ocrTimeRanges": [],
"ocrAdjustedTimeRanges": []
}],
"faces": [{
"id": 19617,
"bingId": "fc09d25c-0c7c-13c0-e4cd-1f5f7d125b36",
"name": "Jayalalithaa",
"thumbnailId": "7281c9e6-7c94-438a-8c78-58c7261e4662",
"description": "Jayaram Jayalalithaa was an Indian actress and politician who served six terms as the Chief Minister of Tamil Nadu for over fourteen years between 1991 and 2016.",
"title": "Indian Politician",
"imageUrl": "https://www.bing.com/th?id=Af06db7240c8dad3b2fb285b753c05e1e&c=12&rs=1&qlt=80&cdv=1&pid=16.2",
"confidence": 0.99999797344207764,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 17504,
"bingId": "d6973c1f-14df-4d61-ed88-9733dd5e8122",
"name": "Mamata Banerjee",
"thumbnailId": "c4c71204-cf63-45a4-9aa1-4f52e1a5467a",
"description": "Mamata Banerjee is a poet, painter, miscellanist and an Indian politician who has been the 8th Chief Minister of West Bengal since 2011. She is the first woman to hold the office. She founded the party All India Trinamool Congress in 1997 after separating from the Indian National Congress, and …",
"title": "Former Minister of Railways",
"imageUrl": "https://www.bing.com/th?id=A85d42524663ee6fdbb6bcc0eb4642ab6&c=12&rs=1&qlt=80&cdv=1&pid=16.2",
"confidence": 0.99418288469314575,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 4663,
"bingId": null,
"name": "Unknown #2",
"thumbnailId": "1c0d4b79-688f-4b80-b99e-43d2e991e92e",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 18677,
"bingId": null,
"name": "Unknown #3",
"thumbnailId": "ce10ab05-260d-475c-8f44-ae5e299f5e68",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 16450,
"bingId": null,
"name": "Unknown #4",
"thumbnailId": "84708501-fcbe-49c3-ab04-7025427e4b48",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 16482,
"bingId": null,
"name": "Unknown #5",
"thumbnailId": "a4a2ee7c-40dd-4dff-8c7f-cb830250cb92",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 16786,
"bingId": null,
"name": "Unknown #7",
"thumbnailId": "3617a8c1-4a38-44e6-897e-3b029790166c",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 13110,
"bingId": null,
"name": "Unknown #8",
"thumbnailId": "9c66b205-2691-41ac-b987-fe64d0fceea9",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 20054,
"bingId": null,
"name": "Unknown #9",
"thumbnailId": "aa889671-f640-4ab4-ba5a-d09aac16b13f",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 15122,
"bingId": null,
"name": "Unknown #10",
"thumbnailId": "853b59a5-ff26-4e29-8074-979f42a9bc29",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 5321,
"bingId": null,
"name": "Unknown #11",
"thumbnailId": "a540dff4-3de4-49c5-bd7e-4a09899f4869",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 16827,
"bingId": null,
"name": "Unknown #12",
"thumbnailId": "ce1c96fd-595f-4346-85a3-bea10af31435",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 5312,
"bingId": null,
"name": "Unknown #13",
"thumbnailId": "579f032c-faf1-4a09-93c4-c37fd8928af8",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 15807,
"bingId": null,
"name": "Unknown #14",
"thumbnailId": "3cb58225-aac3-4168-8f42-8f7fc2aa7854",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 6758,
"bingId": null,
"name": "Unknown #15",
"thumbnailId": "fd29ce4f-0733-40a1-a81c-664b3939e50a",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 14393,
"bingId": null,
"name": "Unknown #16",
"thumbnailId": "32cd4be6-ef89-4f1a-b68a-c317576e8dcd",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 7229,
"bingId": null,
"name": "Unknown #17",
"thumbnailId": "bf41907d-c72b-4fcd-a6fb-d8f112c6459b",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 16794,
"bingId": null,
"name": "Unknown #18",
"thumbnailId": "a671a626-9043-40fd-ae8c-c5ebe8a1522b",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 18514,
"bingId": null,
"name": "Unknown #19",
"thumbnailId": "4dd81afb-6b9a-406b-8f10-c6b733a73963",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 12225,
"bingId": null,
"name": "Unknown #20",
"thumbnailId": "662e5490-99ab-4ea3-9300-2755f41e9e28",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 15514,
"bingId": null,
"name": "Unknown #21",
"thumbnailId": "9365a9d3-440a-43e7-b4d5-427cf94b99c7",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 16116,
"bingId": null,
"name": "Unknown #22",
"thumbnailId": "7c020844-a4c3-49ec-8e10-8caee5134f98",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 1960,
"bingId": null,
"name": "Unknown #23",
"thumbnailId": "f9a9e1c0-20a4-4656-933b-a96e122b2ad5",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 13391,
"bingId": null,
"name": "Unknown #24",
"thumbnailId": "3c07fb28-8dd2-4444-94af-9ec5218aec5b",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 13872,
"bingId": null,
"name": "Unknown #25",
"thumbnailId": "3baf7405-f976-480f-b75d-ee3e659dbb8e",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 7224,
"bingId": null,
"name": "Unknown #26",
"thumbnailId": "f5d5d843-e7cb-48a9-ae07-5c4dd2797601",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 10253,
"bingId": null,
"name": "Unknown #27",
"thumbnailId": "eef635d8-601f-4184-9b49-8c0f8c83b170",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 10128,
"bingId": null,
"name": "Unknown #28",
"thumbnailId": "35b3c32c-18ba-4791-9249-4e7f6235b89f",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 1286,
"bingId": null,
"name": "Unknown #29",
"thumbnailId": "107105f4-95a3-4196-bf4b-6711bfd29df2",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 18696,
"bingId": null,
"name": "Unknown #30",
"thumbnailId": "30ac80a2-c980-40b4-b5ad-3cb49771f2b3",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 9068,
"bingId": null,
"name": "Unknown #31",
"thumbnailId": "723fb77e-8024-4a6d-910e-d4f1272e789c",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 6186,
"bingId": null,
"name": "Unknown #32",
"thumbnailId": "205b99f7-9eb6-4872-a57f-e516423d2f6e",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 15308,
"bingId": null,
"name": "Unknown #33",
"thumbnailId": "6f2854c1-dbc2-47b4-bd16-5ac9c7f6a681",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 8299,
"bingId": null,
"name": "Unknown #34",
"thumbnailId": "3b70c604-2ffc-4bf9-8096-fdbb1bcf4a5a",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 1398,
"bingId": null,
"name": "Unknown #35",
"thumbnailId": "7aae3ce5-67e9-40a4-b92c-e35061dcbafe",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 6693,
"bingId": null,
"name": "Unknown #36",
"thumbnailId": "3f696b87-775a-4c43-93f5-b2f922eb64f0",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 10108,
"bingId": null,
"name": "Unknown #37",
"thumbnailId": "22250d7d-0ac5-43e4-9f14-ea593ec964d7",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 8213,
"bingId": null,
"name": "Unknown #38",
"thumbnailId": "f2e1e9c1-802d-4ad0-8ecd-680071a3fc25",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 9881,
"bingId": null,
"name": "Unknown #39",
"thumbnailId": "32c3cb06-1457-4530-8d60-834927ac340c",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 6647,
"bingId": null,
"name": "Unknown #40",
"thumbnailId": "b3732958-e287-4d8d-8147-3478f33aa5f4",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 5733,
"bingId": null,
"name": "Unknown #41",
"thumbnailId": "011b137b-c5df-48ef-b99c-46ea9c78ee3b",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 2635,
"bingId": null,
"name": "Unknown #42",
"thumbnailId": "2776eb6b-52d6-4d6e-99a4-03925fcb78cb",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 4442,
"bingId": null,
"name": "Unknown #43",
"thumbnailId": "159937fc-bd86-4a64-a589-eeb161105c98",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 9114,
"bingId": null,
"name": "Unknown #44",
"thumbnailId": "6a83dd78-f856-4772-9281-30e62f08db7a",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 9049,
"bingId": null,
"name": "Unknown #45",
"thumbnailId": "8b840acc-133a-472a-a346-6769e18ecf4a",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 14691,
"bingId": null,
"name": "Unknown #46",
"thumbnailId": "dd8db656-3c92-4536-9e7d-d974c7d89851",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 13832,
"bingId": null,
"name": "Unknown #47",
"thumbnailId": "caae8ed2-2039-4459-aab3-f6d3ec2419c8",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 1611,
"bingId": null,
"name": "Unknown #48",
"thumbnailId": "01831910-a74e-4feb-9c83-45a601063fb8",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 1755,
"bingId": null,
"name": "Unknown #49",
"thumbnailId": "bac0cf66-dded-48bb-8563-154e1592a138",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 14920,
"bingId": null,
"name": "Unknown #51",
"thumbnailId": "b9efc854-ef3b-45c0-b3d3-40a1478016ea",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 12197,
"bingId": null,
"name": "Unknown #52",
"thumbnailId": "2a2cf3bd-b6d7-45ca-a0cd-28a6c9641e6f",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 6663,
"bingId": null,
"name": "Unknown #53",
"thumbnailId": "d40806e9-92c5-4764-a2f9-27c6762f6f33",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}, {
"id": 1150,
"bingId": null,
"name": "Unknown #54",
"thumbnailId": "6c651c22-5503-4766-9647-9152891bce74",
"description": null,
"title": null,
"imageUrl": null,
"confidence": 0.0,
"knownPersonId": "00000000-0000-0000-0000-000000000000"
}],
"participants": [{
"id": 1,
"name": "Speaker #1"
}, {
"id": 2,
"name": "Speaker #2"
}, {
"id": 3,
"name": "Speaker #3"
}, {
"id": 4,
"name": "Speaker #4"
}, {
"id": 5,
"name": "Speaker #5"
}],
"contentModeration": {
"adultClassifierValue": 0.00398,
"racyClassifierValue": 0.60572,
"bannedWordsCount": 0,
"bannedWordsRatio": 0.0,
"reviewRecommended": false,
"isAdult": false
},
"audioEffectsCategories": [{
"type": 4,
"key": "Speech"
}],
"framePatterns": [{
"patternType": "Black",
"timeRanges": [{
"start": "00:01:40.6000000",
"end": "00:01:40.6330000"
}, {
"start": "00:05:41.2330000",
"end": "00:06:37.2330000"
}]
}]
},
"thumbnailUrl": "https://www.videoindexer.ai/api/Thumbnail/86a059e4d2/16e9c0b8-aa3c-40b7-a157-9d3c2bbe473d",
"publishedUrl": "https://rodmandev.streaming.mediaservices.windows.net:443/d536dbed-7468-4fea-9c97-2305de61db15/jayalalitha.ism/manifest",
"publishedProxyUrl": null,
"viewToken": "Bearer=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1cm46bWljcm9zb2Z0OmF6dXJlOm1lZGlhc2VydmljZXM6Y29udGVudGtleWlkZW50aWZpZXIiOiI0N2E3ZWE0NS0xZTdhLTQwN2QtODk0MS05MmM3OTQ2ZTU1M2MiLCJpc3MiOiJodHRwczovL2JyZWFrZG93bi5tZSIsImF1ZCI6IkJyZWFrZG93blVzZXIiLCJleHAiOjE1MjE0NDQ4MjEsIm5iZiI6MTUyMTM1ODM2MX0.KxYsvRYHOSmboU5Ug2-j-IErZTWlLe7MoGCoi3Zm2xs",
"sourceLanguage": "en-US",
"language": "en-US",
"indexingPreset": "Default",
"linguisticModelId": "00000000-0000-0000-0000-000000000000"
}],
"social": {
"likedByUser": false,
"likes": 0,
"views": 0
}
}
eoa;
//print_r( search_match($json,"phone number","fm_news.vtt"));
    


?>