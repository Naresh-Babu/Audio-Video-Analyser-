<?php

    $json='{
  "accountId": "a76ef345-7cef-4367-9599-5c0eca019523",
  "id": "803bb1eae7",
  "partition": null,
  "name": "a",
  "description": null,
  "userName": "muhamed salih",
  "createTime": "2018-03-13T11:01:22.1600491+00:00",
  "organization": "",
  "privacyMode": "Public",
  "state": "Processed",
  "isOwned": true,
  "isEditable": false,
  "isBase": true,
  "durationInSeconds": 34,
  "summarizedInsights": {
    "name": "a",
    "shortId": "803bb1eae7",
    "privacyMode": 2,
    "duration": {
      "time": "00:00:34",
      "seconds": 34.0
    },
    "thumbnailUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/1b6fba49-84d5-4fb9-a115-03480941a233",
    "faces": [{
      "id": 1664,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.78929,
      "name": "surya",
      "description": null,
      "title": "actor",
      "thumbnailId": "38f7ce00-6b0a-471f-803e-ed4ce69ba80e",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/38f7ce00-6b0a-471f-803e-ed4ce69ba80e",
      "appearances": [{
        "startTime": "00:00:01.6640000",
        "endTime": "00:00:29.8600000",
        "startSeconds": 1.7,
        "endSeconds": 29.9
      }],
      "seenDuration": 28.2,
      "seenDurationRatio": 0.82941176470588229
    }, {
      "id": 1100,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #6",
      "description": null,
      "title": null,
      "thumbnailId": "e741906a-ac6c-461c-bdc8-9ea5f1dcf5cb",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/e741906a-ac6c-461c-bdc8-9ea5f1dcf5cb",
      "appearances": [{
        "startTime": "00:00:02.8960000",
        "endTime": "00:00:24.0670000",
        "startSeconds": 2.9,
        "endSeconds": 24.1
      }],
      "seenDuration": 21.200000000000003,
      "seenDurationRatio": 0.623529411764706
    }, {
      "id": 1433,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #2",
      "description": null,
      "title": null,
      "thumbnailId": "ab99f5be-a3ec-403e-9d02-1b68e2472759",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/ab99f5be-a3ec-403e-9d02-1b68e2472759",
      "appearances": [{
        "startTime": "00:00:20.2060000",
        "endTime": "00:00:27.0630000",
        "startSeconds": 20.2,
        "endSeconds": 27.1
      }],
      "seenDuration": 6.9000000000000021,
      "seenDurationRatio": 0.20294117647058829
    }, {
      "id": 1352,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #1",
      "description": null,
      "title": null,
      "thumbnailId": "e3acc40b-d5ef-47dd-a7e9-c98cc053f85b",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/e3acc40b-d5ef-47dd-a7e9-c98cc053f85b",
      "appearances": [{
        "startTime": "00:00:05.9910000",
        "endTime": "00:00:07.5890000",
        "startSeconds": 6.0,
        "endSeconds": 7.6
      }, {
        "startTime": "00:00:18.2420000",
        "endTime": "00:00:21.4380000",
        "startSeconds": 18.2,
        "endSeconds": 21.4
      }],
      "seenDuration": 4.7999999999999989,
      "seenDurationRatio": 0.14117647058823526
    }, {
      "id": 2046,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #9",
      "description": null,
      "title": null,
      "thumbnailId": "059cb21f-7528-489f-909f-71053aa4cb6a",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/059cb21f-7528-489f-909f-71053aa4cb6a",
      "appearances": [{
        "startTime": "00:00:25.7320000",
        "endTime": "00:00:29.3940000",
        "startSeconds": 25.7,
        "endSeconds": 29.4
      }],
      "seenDuration": 3.6999999999999993,
      "seenDurationRatio": 0.10882352941176468
    }, {
      "id": 1027,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #13",
      "description": null,
      "title": null,
      "thumbnailId": "dbf3a2e1-f384-4109-ad63-1d00355fb7f3",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/dbf3a2e1-f384-4109-ad63-1d00355fb7f3",
      "appearances": [{
        "startTime": "00:00:01.6980000",
        "endTime": "00:00:05.0590000",
        "startSeconds": 1.7,
        "endSeconds": 5.1
      }],
      "seenDuration": 3.3999999999999995,
      "seenDurationRatio": 0.099999999999999978
    }, {
      "id": 2054,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #15",
      "description": null,
      "title": null,
      "thumbnailId": "54a5fb36-a16b-4211-aafe-bed4b496d05a",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/54a5fb36-a16b-4211-aafe-bed4b496d05a",
      "appearances": [{
        "startTime": "00:00:26.2640000",
        "endTime": "00:00:29.4600000",
        "startSeconds": 26.3,
        "endSeconds": 29.5
      }],
      "seenDuration": 3.1999999999999993,
      "seenDurationRatio": 0.094117647058823514
    }, {
      "id": 1704,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #10",
      "description": null,
      "title": null,
      "thumbnailId": "52e39a87-8c69-4770-b7f7-e00adc34bb1d",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/52e39a87-8c69-4770-b7f7-e00adc34bb1d",
      "appearances": [{
        "startTime": "00:00:24.5330000",
        "endTime": "00:00:27.0300000",
        "startSeconds": 24.5,
        "endSeconds": 27.0
      }],
      "seenDuration": 2.5,
      "seenDurationRatio": 0.073529411764705885
    }, {
      "id": 1071,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #11",
      "description": null,
      "title": null,
      "thumbnailId": "038c7c13-4141-4f09-a120-fdbd3d8ae3b3",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/038c7c13-4141-4f09-a120-fdbd3d8ae3b3",
      "appearances": [{
        "startTime": "00:00:03.3620000",
        "endTime": "00:00:05.6250000",
        "startSeconds": 3.4,
        "endSeconds": 5.6
      }],
      "seenDuration": 2.1999999999999997,
      "seenDurationRatio": 0.064705882352941169
    }, {
      "id": 1795,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #5",
      "description": null,
      "title": null,
      "thumbnailId": "907f245a-6a53-4ade-bf26-3866fee28135",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/907f245a-6a53-4ade-bf26-3866fee28135",
      "appearances": [{
        "startTime": "00:00:24.8000000",
        "endTime": "00:00:26.5310000",
        "startSeconds": 24.8,
        "endSeconds": 26.5
      }],
      "seenDuration": 1.6999999999999993,
      "seenDurationRatio": 0.049999999999999982
    }, {
      "id": 2009,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #3",
      "description": null,
      "title": null,
      "thumbnailId": "fdc48857-710f-44e6-a5ce-14e3f92a9a68",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/fdc48857-710f-44e6-a5ce-14e3f92a9a68",
      "appearances": [{
        "startTime": "00:00:26.9300000",
        "endTime": "00:00:28.1290000",
        "startSeconds": 26.9,
        "endSeconds": 28.1
      }],
      "seenDuration": 1.2000000000000028,
      "seenDurationRatio": 0.035294117647058906
    }, {
      "id": 2041,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #7",
      "description": null,
      "title": null,
      "thumbnailId": "50b34345-4017-4489-b480-51349b453b59",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/50b34345-4017-4489-b480-51349b453b59",
      "appearances": [{
        "startTime": "00:00:26.9970000",
        "endTime": "00:00:28.1620000",
        "startSeconds": 27.0,
        "endSeconds": 28.2
      }],
      "seenDuration": 1.1999999999999993,
      "seenDurationRatio": 0.0352941176470588
    }, {
      "id": 1947,
      "shortId": "803bb1eae7",
      "bingId": null,
      "confidence": 0.0,
      "name": "Unknown #4",
      "description": null,
      "title": null,
      "thumbnailId": "c54ae7a9-5c39-45cb-b947-493150a007f7",
      "thumbnailFullUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/c54ae7a9-5c39-45cb-b947-493150a007f7",
      "appearances": [{
        "startTime": "00:00:26.2310000",
        "endTime": "00:00:26.9630000",
        "startSeconds": 26.2,
        "endSeconds": 27.0
      }],
      "seenDuration": 0.80000000000000071,
      "seenDurationRatio": 0.023529411764705903
    }],
    "topics": [{
"id": 0,
"name": "phone number",
"stem": "phone number",
"words": ["phone number"],
"rank": 4.0
}, {
"id": 1,
"name": "double room",
"stem": "double room",
"words": ["double room"],
"rank": 3.666666666666667
}, {
"id": 2,
"name": "room",
"stem": "room",
"words": ["room"],
"rank": 1.6666666666666667
}, {
"id": 3,
"name": "money",
"stem": "money",
"words": ["money"],
"rank": 1.5
}],
    "sentiments": [{
      "sentimentKey": "Neutral",
      "appearances": [{
        "startTime": "00:00:00",
        "endTime": "00:00:34",
        "startSeconds": 0.0,
        "endSeconds": 34.0
      }],
      "seenDurationRatio": 1.0
    }],
    "audioEffects": [],
    "annotations": [{
      "id": 1,
      "name": "person",
      "appearances": [{
        "startTime": "00:00:00.0660000",
        "endTime": "00:00:13.9140000",
        "startSeconds": 0.1,
        "endSeconds": 13.9
      }, {
        "startTime": "00:00:19.2400000",
        "endTime": "00:00:32.0230000",
        "startSeconds": 19.2,
        "endSeconds": 32.0
      }]
    }, {
      "id": 3,
      "name": "man",
      "appearances": [{
        "startTime": "00:00:29.8930000",
        "endTime": "00:00:30.9580000",
        "startSeconds": 29.9,
        "endSeconds": 31.0
      }]
    }, {
      "id": 2,
      "name": "indoor",
      "appearances": [{
        "startTime": "00:00:14.9790000",
        "endTime": "00:00:16.0440000",
        "startSeconds": 15.0,
        "endSeconds": 16.0
      }]
    }, {
      "id": 4,
      "name": "striped",
      "appearances": [{
        "startTime": "00:00:30.9580000",
        "endTime": "00:00:32.0230000",
        "startSeconds": 31.0,
        "endSeconds": 32.0
      }]
    }, {
      "id": 0,
      "name": "Black Frames",
      "appearances": [{
        "startTime": "00:00:31.3920000",
        "endTime": "00:00:31.4910000",
        "startSeconds": 31.4,
        "endSeconds": 31.5
      }]
    }],
    "brands": [{
      "id": 1,
"name": "Google",
"wikiId": "Google",
"wikiUrl": "http://en.wikipedia.org/wiki/Google",
"confidence": 0.564,
"description": "Google is an American multinational technology company specializing in Internet-related services and products. These include online advertising technologies, search, cloud computing, and software. Most of its profits are derived from AdWords, an online advertising service that places advertising near the list of search results.",
"appearances": [{
"startTime": "00:05:30.5040000",
"endTime": "00:05:40.8240000",
"startSeconds": 330.5,
"endSeconds": 340.8
}],
"seenDuration": 10.300000000000011
}],
    "statistics": {
      "correspondenceCount": 0,
      "speakerTalkToListenRatio": {},
      "speakerLongestMonolog": {},
      "speakerNumberOfFragments": {},
      "speakerWordCount": {}
    }
  },
  "breakdowns": [{
    "accountId": "a76ef345-7cef-4367-9599-5c0eca019523",
    "id": "803bb1eae7",
    "state": "Processed",
    "processingProgress": "100%",
    "failureCode": "General",
    "failureMessage": "",
    "externalId": null,
    "externalUrl": null,
    "metadata": null,
    "insights": {
      "transcriptBlocks": [{
        "id": 0,
        "lines": [{
          "id": 0,
          "timeRange": {
            "start": "00:00:00",
            "end": "00:00:34"
          },
          "adjustedTimeRange": {
            "start": "00:00:00",
            "end": "00:00:34"
          },
          "participantId": -1,
          "text": "",
          "isIncluded": true,
          "confidence": 1.0
        }],
        "sentimentIds": [],
        "thumbnailsIds": [],
        "sentiment": 0.0,
        "faces": [{
          "id": 1664,
          "thumbnailId": "37116c8f-847c-4c98-826e-7382dc643e13",
          "ranges": [{
            "timeRange": {
              "start": "00:00:01.6640000",
              "end": "00:00:05.5590000"
            },
            "adjustedTimeRange": {
              "start": "00:00:01.6640000",
              "end": "00:00:05.5590000"
            }
          }, {
            "timeRange": {
              "start": "00:00:07.3900000",
              "end": "00:00:07.9550000"
            },
            "adjustedTimeRange": {
              "start": "00:00:07.3900000",
              "end": "00:00:07.9550000"
            }
          }, {
            "timeRange": {
              "start": "00:00:08.4880000",
              "end": "00:00:12.2830000"
            },
            "adjustedTimeRange": {
              "start": "00:00:08.4880000",
              "end": "00:00:12.2830000"
            }
          }, {
            "timeRange": {
              "start": "00:00:15.8450000",
              "end": "00:00:16.4110000"
            },
            "adjustedTimeRange": {
              "start": "00:00:15.8450000",
              "end": "00:00:16.4110000"
            }
          }, {
            "timeRange": {
              "start": "00:00:16.7440000",
              "end": "00:00:29.4270000"
            },
            "adjustedTimeRange": {
              "start": "00:00:16.7440000",
              "end": "00:00:29.4270000"
            }
          }, {
            "timeRange": {
              "start": "00:00:29.8260000",
              "end": "00:00:29.8600000"
            },
            "adjustedTimeRange": {
              "start": "00:00:29.8260000",
              "end": "00:00:29.8600000"
            }
          }]
        }, {
          "id": 1352,
          "thumbnailId": "e760808d-8f1c-4b32-9d7a-3a185c14c236",
          "ranges": [{
            "timeRange": {
              "start": "00:00:05.9910000",
              "end": "00:00:07.5890000"
            },
            "adjustedTimeRange": {
              "start": "00:00:05.9910000",
              "end": "00:00:07.5890000"
            }
          }, {
            "timeRange": {
              "start": "00:00:18.2420000",
              "end": "00:00:21.4380000"
            },
            "adjustedTimeRange": {
              "start": "00:00:18.2420000",
              "end": "00:00:21.4380000"
            }
          }]
        }, {
          "id": 1433,
          "thumbnailId": "49e2fb53-469a-4a15-b233-b375fff8b64f",
          "ranges": [{
            "timeRange": {
              "start": "00:00:20.2060000",
              "end": "00:00:27.0630000"
            },
            "adjustedTimeRange": {
              "start": "00:00:20.2060000",
              "end": "00:00:27.0630000"
            }
          }]
        }, {
          "id": 2009,
          "thumbnailId": "2afc2e0f-b8dc-4d26-b345-03a87bf34ca7",
          "ranges": [{
            "timeRange": {
              "start": "00:00:26.9300000",
              "end": "00:00:28.1290000"
            },
            "adjustedTimeRange": {
              "start": "00:00:26.9300000",
              "end": "00:00:28.1290000"
            }
          }]
        }, {
          "id": 1947,
          "thumbnailId": "a9aefee8-86fd-4ff6-b8b9-87e33ca96376",
          "ranges": [{
            "timeRange": {
              "start": "00:00:26.2310000",
              "end": "00:00:26.9630000"
            },
            "adjustedTimeRange": {
              "start": "00:00:26.2310000",
              "end": "00:00:26.9630000"
            }
          }]
        }, {
          "id": 1795,
          "thumbnailId": "1a00e195-b8d9-49c6-956d-9b52fafbf3bc",
          "ranges": [{
            "timeRange": {
              "start": "00:00:24.8000000",
              "end": "00:00:26.5310000"
            },
            "adjustedTimeRange": {
              "start": "00:00:24.8000000",
              "end": "00:00:26.5310000"
            }
          }]
        }, {
          "id": 1100,
          "thumbnailId": "2f4b99cd-6590-4e3a-9052-a0b8682e5ef6",
          "ranges": [{
            "timeRange": {
              "start": "00:00:02.8960000",
              "end": "00:00:05.8920000"
            },
            "adjustedTimeRange": {
              "start": "00:00:02.8960000",
              "end": "00:00:05.8920000"
            }
          }, {
            "timeRange": {
              "start": "00:00:07.7560000",
              "end": "00:00:12.5490000"
            },
            "adjustedTimeRange": {
              "start": "00:00:07.7560000",
              "end": "00:00:12.5490000"
            }
          }, {
            "timeRange": {
              "start": "00:00:16.6770000",
              "end": "00:00:19.6730000"
            },
            "adjustedTimeRange": {
              "start": "00:00:16.6770000",
              "end": "00:00:19.6730000"
            }
          }, {
            "timeRange": {
              "start": "00:00:21.6040000",
              "end": "00:00:24.0670000"
            },
            "adjustedTimeRange": {
              "start": "00:00:21.6040000",
              "end": "00:00:24.0670000"
            }
          }]
        }, {
          "id": 2041,
          "thumbnailId": "c4ed24d9-1e8b-4a04-b6df-9122501d2c41",
          "ranges": [{
            "timeRange": {
              "start": "00:00:26.9970000",
              "end": "00:00:28.1620000"
            },
            "adjustedTimeRange": {
              "start": "00:00:26.9970000",
              "end": "00:00:28.1620000"
            }
          }]
        }, {
          "id": 2046,
          "thumbnailId": "158362fb-788b-441b-8eaa-533e4be54e21",
          "ranges": [{
            "timeRange": {
              "start": "00:00:25.7320000",
              "end": "00:00:29.3940000"
            },
            "adjustedTimeRange": {
              "start": "00:00:25.7320000",
              "end": "00:00:29.3940000"
            }
          }]
        }, {
          "id": 1704,
          "thumbnailId": "961cbed0-de1c-4b76-80e4-f6bb74899a99",
          "ranges": [{
            "timeRange": {
              "start": "00:00:24.5330000",
              "end": "00:00:27.0300000"
            },
            "adjustedTimeRange": {
              "start": "00:00:24.5330000",
              "end": "00:00:27.0300000"
            }
          }]
        }, {
          "id": 1071,
          "thumbnailId": "b3bf45ce-c5bb-432c-82f3-2f13cb8d97a2",
          "ranges": [{
            "timeRange": {
              "start": "00:00:03.3620000",
              "end": "00:00:05.6250000"
            },
            "adjustedTimeRange": {
              "start": "00:00:03.3620000",
              "end": "00:00:05.6250000"
            }
          }]
        }, {
          "id": 1027,
          "thumbnailId": "46795a15-7dde-4cd6-b577-feb809e0b12c",
          "ranges": [{
            "timeRange": {
              "start": "00:00:01.6980000",
              "end": "00:00:05.0590000"
            },
            "adjustedTimeRange": {
              "start": "00:00:01.6980000",
              "end": "00:00:05.0590000"
            }
          }]
        }, {
          "id": 2054,
          "thumbnailId": "96c81e6c-8b2a-473c-8533-5f3b8a403bfd",
          "ranges": [{
            "timeRange": {
              "start": "00:00:26.2640000",
              "end": "00:00:29.4600000"
            },
            "adjustedTimeRange": {
              "start": "00:00:26.2640000",
              "end": "00:00:29.4600000"
            }
          }]
        }],
        "ocrs": [],
        "audioEffectInstances": [{
          "type": 4,
          "ranges": []
        }],
        "scenes": [{
          "id": 0,
          "timeRange": {
            "start": "00:00:00",
            "end": "00:00:28.8610000"
          },
          "keyFrame": "00:00:19.2410000",
          "keyFrameThumbnailId": "c046430a-62f9-4ac6-bdd2-2840b376d48e",
          "shots": [{
            "id": 0,
            "timeRange": {
              "start": "00:00:00",
              "end": "00:00:05.5250000"
            },
            "keyFrame": "00:00:02.9290000",
            "keyFrameThumbnailId": "5c81edf6-8ee0-4bf4-a921-e616b70944f0"
          }, {
            "id": 1,
            "timeRange": {
              "start": "00:00:05.7250000",
              "end": "00:00:08.6880000"
            },
            "keyFrame": "00:00:07.2240000",
            "keyFrameThumbnailId": "d4bf2a65-c831-4ba1-90ed-23513f0f09fa"
          }, {
            "id": 2,
            "timeRange": {
              "start": "00:00:08.8880000",
              "end": "00:00:13.7480000"
            },
            "keyFrame": "00:00:11.5180000",
            "keyFrameThumbnailId": "25a7e2e1-29ab-4d35-b414-9407781c33bb"
          }, {
            "id": 3,
            "timeRange": {
              "start": "00:00:13.9480000",
              "end": "00:00:16.0110000"
            },
            "keyFrame": "00:00:14.9470000",
            "keyFrameThumbnailId": "5bd03872-6222-404f-a2a6-3509c8cff247"
          }, {
            "id": 4,
            "timeRange": {
              "start": "00:00:16.2110000",
              "end": "00:00:22.7030000"
            },
            "keyFrame": "00:00:19.2410000",
            "keyFrameThumbnailId": "8e1f93be-a5f0-4d9a-9668-70cc09079921"
          }, {
            "id": 5,
            "timeRange": {
              "start": "00:00:22.9360000",
              "end": "00:00:26.9640000"
            },
            "keyFrame": "00:00:24.9670000",
            "keyFrameThumbnailId": "773bc9d8-bf98-467b-b998-af2e6e210229"
          }, {
            "id": 6,
            "timeRange": {
              "start": "00:00:27.1630000",
              "end": "00:00:28.8610000"
            },
            "keyFrame": "00:00:27.9960000",
            "keyFrameThumbnailId": "3bac4305-aaeb-43fe-baf8-0cfcc3ac5f08"
          }]
        }, {
          "id": 1,
          "timeRange": {
            "start": "00:00:29.0940000",
            "end": "00:00:32.1900000"
          },
          "keyFrame": "00:00:30.6260000",
          "keyFrameThumbnailId": "f963f58d-39fc-44d8-8ce9-ad51ea8717d0",
          "shots": [{
            "id": 7,
            "timeRange": {
              "start": "00:00:29.0940000",
              "end": "00:00:32.1900000"
            },
            "keyFrame": "00:00:30.6260000",
            "keyFrameThumbnailId": "2dff97a2-2e39-4fbf-b5c0-7dd90556a0b2"
          }]
        }, {
          "id": 2,
          "timeRange": {
            "start": "00:00:32.1900000",
            "end": "00:00:33.3550000"
          },
          "keyFrame": "00:00:32.7560000",
          "keyFrameThumbnailId": "a75aefe3-9c06-4cec-b9f5-4c07f59aa966",
          "shots": [{
            "id": 8,
            "timeRange": {
              "start": "00:00:32.1900000",
              "end": "00:00:33.3550000"
            },
            "keyFrame": "00:00:32.7560000",
            "keyFrameThumbnailId": "c8bdafc7-88ca-40b6-a738-2eb85823bb9e"
          }]
        }, {
          "id": 3,
          "timeRange": {
            "start": "00:00:33.3550000",
            "end": "00:00:34"
          },
          "keyFrame": "00:00:33.9550000",
          "keyFrameThumbnailId": "85619150-0d53-4edb-840a-b206a1b51246",
          "shots": [{
            "id": 9,
            "timeRange": {
              "start": "00:00:33.3550000",
              "end": "00:00:34"
            },
            "keyFrame": "00:00:33.9550000",
            "keyFrameThumbnailId": "7f520aba-44b3-457e-93f7-4dce6e3c7aa7"
          }]
        }],
        "annotations": [{
          "id": 1,
          "name": "person",
          "timeRanges": [{
            "start": "00:00:00.0660000",
            "end": "00:00:02.1960000"
          }, {
            "start": "00:00:03.2620000",
            "end": "00:00:07.5220000"
          }, {
            "start": "00:00:07.5230000",
            "end": "00:00:11.7830000"
          }, {
            "start": "00:00:11.7840000",
            "end": "00:00:13.9140000"
          }, {
            "start": "00:00:19.2400000",
            "end": "00:00:20.3050000"
          }, {
            "start": "00:00:22.4360000",
            "end": "00:00:24.5660000"
          }, {
            "start": "00:00:25.6320000",
            "end": "00:00:28.8270000"
          }, {
            "start": "00:00:28.8280000",
            "end": "00:00:32.0230000"
          }],
          "adjustedTimeRanges": [{
            "start": "00:00:00.0660000",
            "end": "00:00:02.1960000"
          }, {
            "start": "00:00:03.2620000",
            "end": "00:00:07.5220000"
          }, {
            "start": "00:00:07.5230000",
            "end": "00:00:11.7830000"
          }, {
            "start": "00:00:11.7840000",
            "end": "00:00:13.9140000"
          }, {
            "start": "00:00:19.2400000",
            "end": "00:00:20.3050000"
          }, {
            "start": "00:00:22.4360000",
            "end": "00:00:24.5660000"
          }, {
            "start": "00:00:25.6320000",
            "end": "00:00:28.8270000"
          }, {
            "start": "00:00:28.8280000",
            "end": "00:00:32.0230000"
          }]
        }, {
          "id": 2,
          "name": "indoor",
          "timeRanges": [{
            "start": "00:00:14.9790000",
            "end": "00:00:16.0440000"
          }],
          "adjustedTimeRanges": [{
            "start": "00:00:14.9790000",
            "end": "00:00:16.0440000"
          }]
        }, {
          "id": 3,
          "name": "man",
          "timeRanges": [{
            "start": "00:00:29.8930000",
            "end": "00:00:30.9580000"
          }],
          "adjustedTimeRanges": [{
            "start": "00:00:29.8930000",
            "end": "00:00:30.9580000"
          }]
        }, {
          "id": 4,
          "name": "striped",
          "timeRanges": [{
            "start": "00:00:30.9580000",
            "end": "00:00:32.0230000"
          }],
          "adjustedTimeRanges": [{
            "start": "00:00:30.9580000",
            "end": "00:00:32.0230000"
          }]
        }]
      }],
      "topics": [],
      "brands": [],
      "faces": [{
        "id": 1664,
        "bingId": null,
        "name": "surya",
        "thumbnailId": "38f7ce00-6b0a-471f-803e-ed4ce69ba80e",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.78929,
        "knownPersonId": "502af8a9-1bcd-46e4-ba2c-fa3b66179ce0"
      }, {
        "id": 1352,
        "bingId": null,
        "name": "Unknown #1",
        "thumbnailId": "e3acc40b-d5ef-47dd-a7e9-c98cc053f85b",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 1433,
        "bingId": null,
        "name": "Unknown #2",
        "thumbnailId": "ab99f5be-a3ec-403e-9d02-1b68e2472759",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 2009,
        "bingId": null,
        "name": "Unknown #3",
        "thumbnailId": "fdc48857-710f-44e6-a5ce-14e3f92a9a68",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 1947,
        "bingId": null,
        "name": "Unknown #4",
        "thumbnailId": "c54ae7a9-5c39-45cb-b947-493150a007f7",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 1795,
        "bingId": null,
        "name": "Unknown #5",
        "thumbnailId": "907f245a-6a53-4ade-bf26-3866fee28135",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 1100,
        "bingId": null,
        "name": "Unknown #6",
        "thumbnailId": "e741906a-ac6c-461c-bdc8-9ea5f1dcf5cb",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 2041,
        "bingId": null,
        "name": "Unknown #7",
        "thumbnailId": "50b34345-4017-4489-b480-51349b453b59",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 2046,
        "bingId": null,
        "name": "Unknown #9",
        "thumbnailId": "059cb21f-7528-489f-909f-71053aa4cb6a",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 1704,
        "bingId": null,
        "name": "Unknown #10",
        "thumbnailId": "52e39a87-8c69-4770-b7f7-e00adc34bb1d",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 1071,
        "bingId": null,
        "name": "Unknown #11",
        "thumbnailId": "038c7c13-4141-4f09-a120-fdbd3d8ae3b3",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 2175,
        "bingId": null,
        "name": "Unknown #12",
        "thumbnailId": "d5314596-cf61-4990-aea9-278ec37e2ad5",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 1027,
        "bingId": null,
        "name": "Unknown #13",
        "thumbnailId": "dbf3a2e1-f384-4109-ad63-1d00355fb7f3",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }, {
        "id": 2054,
        "bingId": null,
        "name": "Unknown #15",
        "thumbnailId": "54a5fb36-a16b-4211-aafe-bed4b496d05a",
        "description": null,
        "title": null,
        "imageUrl": null,
        "confidence": 0.0,
        "knownPersonId": "00000000-0000-0000-0000-000000000000"
      }],
      "participants": [],
      "contentModeration": {
        "adultClassifierValue": 0.0,
        "racyClassifierValue": 0.0,
        "bannedWordsCount": 0,
        "bannedWordsRatio": 0.0,
        "reviewRecommended": false,
        "isAdult": false
      },
      "audioEffectsCategories": [],
      "framePatterns": [{
        "patternType": "Black",
        "timeRanges": [{
          "start": "00:00:31.3920000",
          "end": "00:00:31.4910000"
        }]
      }]
    },
    "thumbnailUrl": "https://www.videoindexer.ai/api/Thumbnail/803bb1eae7/1b6fba49-84d5-4fb9-a115-03480941a233",
    "publishedUrl": "https://rodmandev.streaming.mediaservices.windows.net:443/3ae62e68-157c-43c9-8603-cfb8352d35fc/a.ism/manifest",
    "publishedProxyUrl": null,
    "viewToken": "Bearer=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1cm46bWljcm9zb2Z0OmF6dXJlOm1lZGlhc2VydmljZXM6Y29udGVudGtleWlkZW50aWZpZXIiOiI0NGJkNTRkOC05MzQzLTRhMjgtOWQzMi0wNWQ3ZGU0NTZiNTciLCJpc3MiOiJodHRwczovL2JyZWFrZG93bi5tZSIsImF1ZCI6IkJyZWFrZG93blVzZXIiLCJleHAiOjE1MjEwOTMzNDAsIm5iZiI6MTUyMTAwNjg4MH0.BWxegAnhuztWg9L5qEfjs01xO4_AL_MBxf86fvaIWSo",
    "sourceLanguage": "en-US",
    "language": "en-US",
    "indexingPreset": "Default",
    "linguisticModelId": "00000000-0000-0000-0000-000000000000"
  }],
  "social": {
    "likedByUser": false,
    "likes": 0,
    "views": 0
  }
}';
        
    /*Accepts raw json data as input to categorize it and return a single category as string */
    function categorize($json) {
        $data=json_decode($json,true);
        $search_array=topic_getter($json);
        $search_array=array_merge($search_array,annotation_getter($json));
        $title=array();
        
        $faces=$data["summarizedInsights"]["faces"];
        foreach($faces as $current) {
            $title[]=$current["title"];
        }
        $search_array=array();
        $search_array+=$title;
        $search_array=array_unique($search_array);
        
        
        $categories=array("entertainment"=>"entertainment.txt","business"=>"business.txt","politics"=>"politics.txt","science and technology"=>"sci_and_tec.txt","weather"=>"weather.txt","sports"=>"sports.txt");
        $max_category="general";
        $max=1;
        foreach($categories as $category=>$file_name) {
            $cur_count=0;
            
            $tot_words=array();
            $file_handle = fopen($file_name, "r");

            while (!feof($file_handle)) {
                 $tot_words[] = substr(fgets($file_handle),0,-2);
            }
            fclose($file_handle);
            
            foreach($search_array as $cur_word) {
                
                if(in_array($cur_word,$tot_words)) {
                
                    
                    $cur_count+=1;
                    
                }
            }
            if ($max<$cur_count) {
                $max=$cur_count;
                $max_category=$category;
            }
            
        }
        
        return $max_category;
    }
    
    categorize($json);
?>